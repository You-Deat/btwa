
const { parentPort } = require("worker_threads");
const REGEX = {
  SQLi: /select[\s\S]*?from|insert[\s\S]*?into|delete[\s\S]*?from|drop[\s\S]*?table|' or '1'='1|sleep\(|benchmark\(|information_schema|--\s*$|;\s*--|\|\|.*?(?:or|and).*?=.*?=/i,
  XSS: /<script|javascript:|onerror=|onload=|alert\(|prompt\(|confirm\(|<img.*?src=|onmouseover=|onclick=|onkeyup=|eval\(|expression\(/i,
  PathTraversal: /\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e%5c|\.\.%2f|\.\.%5c/i,
  CmdInjection: /;\s*(rm|curl|wget|bash|sh|nc|nslookup|ping|python|perl|ruby)|\|\s*(sh|bash|nc|nslookup|ping)/i,
  SensitiveFile: /\/etc\/|\/proc\/|\/\.env|\/wp-config|\/config\.php|\/\.git\/|\/\.aws\/|\/\.ssh\/|\/\.bash_history/i,
  Scanner: /sqlmap|nmap|nikto|burp|dirbuster|gobuster|wpscan|masscan|zgrab|python-requests|curl|wget|scanner|httpx|katana/i,
};
parentPort.on("message", ({ id, full }) => {
  const attacks = [];
  for (const [type, regex] of Object.entries(REGEX)) {
    if (regex.test(full)) attacks.push(type);
  }
  parentPort.postMessage({ id, attacks });
});
