const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const util = require("util");
const execPromise = util.promisify(exec);
const { randomUA } = require("./prefik");

let ytdlpAvailable = false;
exec("yt-dlp --version", (error, stdout, stderr) => {
  if (!error) ytdlpAvailable = true;
});

const sampahDir = path.join(__dirname, '..', 'sampah');
if (!fs.existsSync(sampahDir)) fs.mkdirSync(sampahDir, { recursive: true });

async function instagramDownload(link, type) {
  const mediaType = type === 'mp3' ? 'audio' : 'video';
  if (ytdlpAvailable) {
    try {
      const id = Date.now();
      let outputTemplate, cmd;
      if (mediaType === 'audio') {
        outputTemplate = path.join(sampahDir, `temp_${id}_%(title)s.mp3`);
        cmd = `yt-dlp -f bestaudio --extract-audio --audio-format mp3 -o "${outputTemplate}" ${link}`;
      } else {
        outputTemplate = path.join(sampahDir, `temp_${id}_%(title)s.%(ext)s`);
        cmd = `yt-dlp -f "bestvideo+bestaudio" --merge-output-format mp4 -o "${outputTemplate}" ${link}`;
      }
      await execPromise(cmd, { timeout: 120000 });
      const files = fs.readdirSync(sampahDir).filter(f => f.startsWith(`temp_${id}_`));
      if (files.length === 0) return null;
      const filePath = path.join(sampahDir, files[0]);
      const buffer = fs.readFileSync(filePath);
      const title = files[0].replace(`temp_${id}_`, '').replace(/\.(mp3|mp4)$/, '');
      fs.unlinkSync(filePath);
      return { buffer, title, durationSec: 0 };
    } catch (e) {
      console.error("yt-dlp Instagram gagal:", e.message);
    }
  }

  const apis = [
    async () => {
      const { data } = await axios.get(`https://snapinsta.app/api/ajaxSearch`, {
        params: { q: link },
        headers: { 'User-Agent': randomUA(), 'X-Requested-With': 'XMLHttpRequest' },
        timeout: 20000
      });
      if (data && data.data) {
        const media = type === 'mp3' ? (data.data.audio || data.data.video) : data.data.video;
        if (media) return { url: media, title: data.data.title || "Instagram" };
      }
      throw new Error();
    },
    async () => {
      const { data } = await axios.get(`https://api.siputzx.my.id/api/downloader/ig`, {
        params: { url: link },
        timeout: 20000
      });
      if (data?.data?.url) return { url: data.data.url, title: data.data.title || "Instagram" };
      throw new Error();
    }
  ];

  for (const api of apis) {
    try {
      const res = await api();
      if (res.url) {
        const resp = await axios.get(res.url, { responseType: 'arraybuffer', timeout: 60000 });
        return { buffer: Buffer.from(resp.data), title: res.title, durationSec: 0 };
      }
    } catch (e) {}
  }
  return null;
}

module.exports = { instagramDownload };