const net = require("net");
const axios = require("axios");
const { SocksProxyAgent } = require("socks-proxy-agent");
const path = require("path");
const fs = require("fs");

function parseProxyList(buffer) {
    const text = buffer.toString("utf-8");
    const lines = text.split(/\r?\n/);
    const proxies = [];
    for (const line of lines) {
        let trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) continue;
        const match = trimmed.match(/^([0-9a-f:.]+):(\d+)$/i);
        if (match) {
            const host = match[1];
            const port = parseInt(match[2], 10);
            if (port > 0 && port < 65536) proxies.push({ host, port });
        }
    }
    return proxies;
}

async function testHttpProxyFast(host, port, timeout = 2000) {
    try {
        const res = await axios({
            method: 'head',
            url: 'https://httpbin.org/get',
            timeout,
            proxy: { protocol: 'http', host, port },
            validateStatus: () => true
        });
        return res.status === 200;
    } catch {
        return false;
    }
}

async function testSocks5ProxyFast(host, port, timeout = 2000) {
    try {
        const agent = new SocksProxyAgent(`socks5://${host}:${port}`);
        const res = await axios({
            method: 'head',
            url: 'https://httpbin.org/get',
            httpAgent: agent,
            httpsAgent: agent,
            timeout,
            validateStatus: () => true
        });
        return res.status === 200;
    } catch {
        return false;
    }
}

async function checkProtocol(proxy, timeout = 2000) {
    const { host, port } = proxy;
    const tcpOk = await new Promise((resolve) => {
        const socket = new net.Socket();
        const timer = setTimeout(() => { socket.destroy(); resolve(false); }, timeout);
        socket.once('connect', () => { clearTimeout(timer); socket.destroy(); resolve(true); });
        socket.once('error', () => { clearTimeout(timer); resolve(false); });
        socket.connect(port, host);
    });
    if (!tcpOk) return null;
    const tests = [
        testHttpProxyFast(host, port, timeout).then(ok => ok ? 'http' : null),
        testSocks5ProxyFast(host, port, timeout).then(ok => ok ? 'socks5' : null)
    ];
    const result = await Promise.any(tests).catch(() => null);
    return result ? `${host}:${port}` : null;
}

async function detectMajorityProtocol(proxies, sampleSize = 5, timeout = 2000) {
    const samples = proxies.slice(0, sampleSize);
    const results = await Promise.all(samples.map(p => checkProtocol(p, timeout)));
    let httpCount = 0;
    for (const r of results) if (r) httpCount++;
    return httpCount > 2 ? 'http' : (samples.length - httpCount > 2 ? 'socks5' : null);
}

async function checkTcpOnly(host, port, timeout = 1000) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        const timer = setTimeout(() => { socket.destroy(); resolve(false); }, timeout);
        socket.once('connect', () => { clearTimeout(timer); socket.destroy(); resolve(true); });
        socket.once('error', () => { clearTimeout(timer); resolve(false); });
        socket.connect(port, host);
    });
}

async function scanProxyList(proxies, concurrency = 500, timeout = 1000, onProgress = null, forceProtocol = null) {
    let protocolMode = forceProtocol;
    if (!protocolMode && proxies.length > 0) {
        protocolMode = await detectMajorityProtocol(proxies, 5, Math.min(timeout * 2, 3000));
    }
    const active = [];
    let processed = 0;
    const total = proxies.length;
    if (protocolMode) {
        for (let i = 0; i < total; i += concurrency) {
            const batch = proxies.slice(i, i + concurrency);
            const results = await Promise.all(batch.map(async (proxy) => {
                const ok = await checkTcpOnly(proxy.host, proxy.port, timeout);
                processed++;
                if (onProgress && (processed % 500 === 0 || processed === total)) {
                    onProgress(processed, total, active.length);
                }
                return ok ? `${proxy.host}:${proxy.port}` : null;
            }));
            const batchActive = results.filter(r => r !== null);
            active.push(...batchActive);
        }
    } else {
        for (let i = 0; i < total; i += concurrency) {
            const batch = proxies.slice(i, i + concurrency);
            const results = await Promise.all(batch.map(async (proxy) => {
                const result = await checkProtocol(proxy, timeout * 2);
                processed++;
                if (onProgress && (processed % 200 === 0 || processed === total)) {
                    onProgress(processed, total, active.length);
                }
                return result;
            }));
            const batchActive = results.filter(r => r !== null);
            active.push(...batchActive);
        }
    }
    return active;
}

function generateOutputFile(activeProxies, tmpDir) {
    const outputPath = path.join(tmpDir, `${Date.now()}.txt`);
    const content = activeProxies.join("\n");
    fs.writeFileSync(outputPath, content, "utf-8");
    return outputPath;
}

module.exports = { parseProxyList, scanProxyList, generateOutputFile };