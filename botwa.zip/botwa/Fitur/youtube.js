const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const util = require("util");
const execPromise = util.promisify(exec);
const { randomUA } = require("./prefik");

let ytdl = null;
try {
  ytdl = require("@distube/ytdl-core");
} catch (e) {
  try {
    ytdl = require("ytdl-core");
  } catch (e2) {}
}

let ytdlpAvailable = false;
exec("yt-dlp --version", (error) => {
  if (!error) ytdlpAvailable = true;
});

const sampahDir = path.join(__dirname, '..', 'sampah');
if (!fs.existsSync(sampahDir)) fs.mkdirSync(sampahDir, { recursive: true });

async function youtubeFallbackDownload(link, type) {
  const apis = [
    async () => {
      const resp = await axios.get(`https://ytdl.vercel.app/api/download?url=${encodeURIComponent(link)}&format=${type}`, {
        headers: { 'User-Agent': randomUA() },
        timeout: 15000
      });
      if (resp.data && resp.data.url) return { url: resp.data.url, title: resp.data.title || "YouTube Video" };
      throw new Error();
    },
    async () => {
      const resp = await axios.get(`https://api.vevioz.com/@api/button/${link}`, {
        headers: { 'User-Agent': randomUA() },
        timeout: 15000
      });
      const html = resp.data;
      const titleMatch = html.match(/<title>(.*?)<\/title>/);
      const title = titleMatch ? titleMatch[1].replace(" - YouTube", "") : "YouTube Video";
      const regex = /href="(https:\/\/[^"]+\.(?:mp4|mp3|webm)[^"]*)"/gi;
      const matches = [...html.matchAll(regex)];
      if (matches.length > 0) {
        let url;
        if (type === "mp3") {
          url = matches.find(m => m[1].includes('.mp3'))?.[1] || matches[matches.length-1][1];
        } else {
          url = matches[0][1];
        }
        return { url, title };
      }
      throw new Error();
    },
    async () => {
      const resp = await axios.get(`https://y2down.app/api/download`, {
        params: { url: link, format: type },
        headers: { 'User-Agent': randomUA() },
        timeout: 15000
      });
      if (resp.data && resp.data.url) return { url: resp.data.url, title: resp.data.title || "YouTube Video" };
      throw new Error();
    }
  ];
  for (const api of apis) {
    try {
      return await api();
    } catch (e) {}
  }
  return null;
}

async function youtubeDownload(link, type, quality = '720p') {
  if (ytdlpAvailable) {
    try {
      const id = Date.now();
      const outputTemplate = path.join(sampahDir, `temp_${id}_%(title)s.%(ext)s`);
      let cmd;
      if (type === 'mp3') {
        cmd = `yt-dlp -f bestaudio --extract-audio --audio-format mp3 -o "${outputTemplate}" ${link}`;
      } else {
        const height = parseInt(quality);
        cmd = `yt-dlp -f "bestvideo[ext=mp4][vcodec^=avc1][height<=${height}]+bestaudio[ext=m4a]/best[ext=mp4]" --merge-output-format mp4 -o "${outputTemplate}" ${link}`;
      }
      await execPromise(cmd, { timeout: 300000 });
      const files = fs.readdirSync(sampahDir).filter(f => f.startsWith(`temp_${id}_`));
      if (files.length === 0) throw new Error('No file generated');
      const filePath = path.join(sampahDir, files[0]);
      const buffer = fs.readFileSync(filePath);
      const title = files[0].replace(`temp_${id}_`, '').replace(/\.(mp3|mp4)$/, '');
      fs.unlinkSync(filePath);
      return { buffer, title, durationSec: 0 };
    } catch (e) {
      console.error("yt-dlp error:", e.message);
    }
  }

  if (ytdl) {
    try {
      const info = await ytdl.getInfo(link, {
        requestOptions: { headers: { 'User-Agent': randomUA() } }
      });
      const durationSec = parseInt(info.videoDetails.lengthSeconds);
      if (durationSec > 600) return { error: "durasi" };
      let chosenFormat;
      if (type === 'mp3') {
        chosenFormat = ytdl.chooseFormat(info.formats, { quality: 'highestaudio', filter: 'audioonly' });
        if (!chosenFormat) chosenFormat = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
      } else {
        chosenFormat = info.formats.find(f => f.hasVideo && f.hasAudio && f.codecs && f.codecs.includes('avc1') && f.codecs.includes('mp4a'));
        if (!chosenFormat) chosenFormat = info.formats.find(f => f.hasVideo && f.hasAudio && f.qualityLabel === quality);
        if (!chosenFormat) chosenFormat = info.formats.find(f => f.hasVideo && f.hasAudio);
        if (!chosenFormat) chosenFormat = ytdl.chooseFormat(info.formats, { quality: 'lowestvideo' });
      }
      if (!chosenFormat) return null;
      if (chosenFormat.contentLength) {
        const sizeMB = parseInt(chosenFormat.contentLength) / (1024 * 1024);
        if (sizeMB > 100) return { error: "ukuran" };
      }
      const stream = ytdl(link, { format: chosenFormat });
      const chunks = [];
      for await (const chunk of stream) chunks.push(chunk);
      const buffer = Buffer.concat(chunks);
      return { buffer, title: info.videoDetails.title, durationSec };
    } catch (e) {
      console.error("ytdl-core error:", e.message);
    }
  }

  const fallback = await youtubeFallbackDownload(link, type);
  if (fallback && fallback.url) {
    try {
      const resp = await axios.get(fallback.url, { responseType: 'arraybuffer', timeout: 60000 });
      return { buffer: Buffer.from(resp.data), title: fallback.title, durationSec: 0 };
    } catch (e) {}
  }
  return null;
}

module.exports = { youtubeDownload, youtubeFallbackDownload };