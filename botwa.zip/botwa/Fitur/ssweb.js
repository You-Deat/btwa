const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());

const fs = require("fs");
const axios = require("axios");
const https = require("https");
const http = require("http");
const dns = require("dns").promises;
const tls = require("tls");
const net = require("net");
const { execSync } = require("child_process");
const { sleep, randomUA } = require("./prefik");

const CONFIG = {
  REQUEST_TIMEOUT: 8000,
  BURST_CONCURRENCY: 40,
  BURST_DURATION: 5,
  SLOWLORIS_CONCURRENCY: 60,
  SLOWLORIS_DURATION: 4,
  LOAD_TEST_CONCURRENCY: 30,
  LOAD_TEST_DURATION: 4,
  RAPID_RESET_STREAMS: 50,
  WEBSOCKET_TEST_TIMEOUT: 5000,
  DNS_REFLECTION_TIMEOUT: 3000,
  THREAT_INTEL_APIS: {
    VIRUSTOTAL: process.env.VIRUSTOTAL_API_KEY || "",
    ABUSEIPDB: process.env.ABUSEIPDB_API_KEY || "",
    ALIENVAULT: process.env.ALIENVAULT_API_KEY || ""
  },
  SAFE_MODE: true,
  VERBOSE: false
};

function findChromium() {
  const paths = [
    "/data/data/com.termux/files/usr/bin/chromium-browser",
    "/usr/bin/chromium-browser",
    "chromium-browser"
  ];
  for (const p of paths) if (fs.existsSync(p)) return p;
  throw new Error("Chromium tidak ditemukan, install: pkg install chromium");
}

function parseDomain(url) {
  try { return new URL(url).hostname; } catch { return null; }
}

const WAF_SIGNATURES = [
  { name: "𝐂𝐥𝐨𝐮𝐝𝐟𝐥𝐚𝐫𝐞", headers: ["cf-ray","cf-cache-status","cf-connecting-ip"], body: ["cloudflare","attention required","just a moment"] },
  { name: "𝐀𝐰𝐬 𝐖𝐚𝐟", headers: ["x-amzn-requestid","x-amzn-waf"], body: ["request blocked","aws waf"] },
  { name: "𝐀𝐳𝐮𝐫𝐞 𝐅𝐫𝐨𝐧𝐭 𝐃𝐨𝐨𝐫", headers: ["x-azure-ref","x-azure-fdid"], body: ["azure","front door"] },
  { name: "𝐀𝐤𝐚𝐦𝐚𝐢 𝐊𝐨𝐧𝐚", headers: ["x-akamai-transformed","x-akamai-request-id"], body: ["akamai","kona"] },
  { name: "𝐈𝐦𝐩𝐞𝐫𝐯𝐚 𝐈𝐜𝐚𝐩𝐬𝐮𝐥𝐚", headers: ["x-iinfo","x-cdn"], body: ["incapsula","imperva"] },
  { name: "𝐅𝟓 𝐁𝐢𝐠-𝐈𝐩 𝐀𝐬𝐦", headers: ["x-wa-info","x-asm-version"], body: ["f5","asm"] },
  { name: "𝐅𝐨𝐫𝐭𝐢𝐧𝐞𝐭 𝐅𝐨𝐫𝐭𝐢𝐰𝐞𝐛", headers: ["x-fw-server","x-fw-debug"], body: ["fortiweb"] },
  { name: "𝐌𝐨𝐝𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-modsecurity"], body: ["mod_security","this request was blocked"] },
  { name: "𝐒𝐮𝐜𝐮𝐫𝐢", headers: ["x-sucuri-id","x-sucuri-cache"], body: ["sucuri"] },
  { name: "𝐅𝐚𝐬𝐭𝐥𝐲", headers: ["x-served-by","x-cache"], body: ["fastly"] },
  { name: "𝐆𝐨𝐨𝐠𝐥𝐞 𝐂𝐥𝐨𝐮𝐝 𝐀𝐫𝐦𝐨𝐫", headers: ["x-cloud-trace-context"], body: ["google","cloud armor"] },
  { name: "𝐒𝐭𝐚𝐜𝐤𝐏𝐚𝐭𝐡", headers: ["x-stackpath"], body: [] },
  { name: "𝐃𝐝𝐨𝐬-𝐆𝐮𝐚𝐫𝐝", headers: ["x-dg","x-ddos-guard"], body: ["ddos-guard"] },
  { name: "𝐕𝐨𝐱𝐢𝐥𝐢𝐭𝐲", headers: ["x-vx"], body: [] },
  { name: "𝐑𝐚𝐝𝐰𝐚𝐫𝐞 𝐀𝐩𝐩𝐖𝐚𝐥𝐥", headers: ["x-radware"], body: ["appwall"] },
  { name: "𝐁𝐚𝐫𝐫𝐚𝐜𝐮𝐝𝐚 𝐖𝐚𝐟", headers: ["x-barracuda"], body: ["barracuda"] },
  { name: "𝐂𝐢𝐭𝐫𝐢𝐱 𝐍𝐞𝐭𝐬𝐜𝐚𝐥𝐞𝐫", headers: ["x-citrix"], body: ["netscaler"] },
  { name: "𝐏𝐓 𝐀𝐩𝐩𝐥𝐢𝐜𝐚𝐭𝐢𝐨𝐧 𝐅𝐢𝐫𝐞𝐰𝐚𝐥𝐥", headers: ["x-ptaf"], body: [] },
  { name: "𝐑𝐞𝐛𝐥𝐚𝐳𝐞", headers: ["x-reblaze"], body: [] },
  { name: "𝐖𝐚𝐥𝐥𝐚𝐫𝐦", headers: ["x-wallarm"], body: ["wallarm"] },
  { name: "𝐒𝐢𝐠𝐧𝐚𝐥 𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐬", headers: ["x-signal-sciences","x-sigsci"], body: [] },
  { name: "𝐂𝐥𝐨𝐮𝐝𝐛𝐫𝐢𝐜", headers: ["x-cloudbric"], body: [] },
  { name: "𝐓𝐡𝐫𝐞𝐚𝐭𝐗", headers: ["x-threatx"], body: [] },
  { name: "𝐀𝐰𝐬 𝐒𝐡𝐢𝐞𝐥𝐝", headers: ["x-shield"], body: ["shield"] },
  { name: "𝐍𝐞𝐱𝐮𝐬𝐠𝐮𝐚𝐫𝐝", headers: ["x-nexusguard"], body: [] },
  { name: "𝐕𝐞𝐫𝐢𝐬𝐢𝐠𝐧 𝐃𝐃𝐨𝐒", headers: ["x-verisign"], body: [] },
  { name: "𝐅𝟓 𝐒𝐢𝐥𝐯𝐞𝐫𝐥𝐢𝐧𝐞", headers: ["x-silverline"], body: ["silverline"] },
  { name: "𝐍𝐒𝐅𝐨𝐜𝐮𝐬", headers: ["x-nsfocus"], body: ["nsfocus"] },
  { name: "𝐖𝐚𝐧𝐠𝐬𝐮", headers: ["x-ws-waf"], body: ["wangsu"] },
  { name: "𝐘𝐮𝐧𝐣𝐢𝐚", headers: ["x-yunjia"], body: ["yunjia"] },
  { name: "𝐒𝐚𝐟𝐞𝟑 𝐖𝐀𝐅", headers: ["x-safe3"], body: ["safe3"] },
  { name: "𝐖𝐞𝐛𝐊𝐧𝐢𝐠𝐡𝐭", headers: ["x-webknight"], body: ["webknight"] },
  { name: "𝐍𝐀𝐗𝐒𝐈", headers: ["x-naxsi"], body: ["naxsi"] },
  { name: "𝐂𝐃𝐍𝐞𝐭", headers: ["x-cdnnet"], body: ["cdnnet"] },
  { name: "𝐐𝐢𝐧𝐢𝐮 𝐖𝐀𝐅", headers: ["x-qiniu"], body: ["qiniu"] },
  { name: "𝐇𝐮𝐚𝐰𝐞𝐢 𝐂𝐥𝐨𝐮𝐝 𝐖𝐀𝐅", headers: ["x-huawei-waf"], body: ["huawei"] },
  { name: "𝐁𝐚𝐢𝐝𝐮 𝐖𝐀𝐅", headers: ["x-baidu-waf"], body: ["baidu"] },
  { name: "𝐀𝐥𝐢𝐛𝐚𝐛𝐚 𝐂𝐥𝐨𝐮𝐝 𝐖𝐀𝐅", headers: ["x-alibaba-waf"], body: ["aliyun","alibaba"] },
  { name: "𝐓𝐞𝐧𝐜𝐞𝐧𝐭 𝐂𝐥𝐨𝐮𝐝 𝐖𝐀𝐅", headers: ["x-tencent-waf"], body: ["tencent"] },
  { name: "𝐘𝐚𝐧𝐝𝐞𝐱 𝐖𝐀𝐅", headers: ["x-yandex-waf"], body: ["yandex"] },
  { name: "𝐖𝐨𝐫𝐝𝐟𝐞𝐧𝐜𝐞", headers: ["x-wordfence"], body: ["wordfence"] },
  { name: "𝐒𝐡𝐢𝐞𝐥𝐝 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-shield-security"], body: ["shield security"] },
  { name: "𝐁𝐮𝐥𝐥𝐞𝐭𝐏𝐫𝐨𝐨𝐟 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-bps"], body: ["bulletproof"] },
  { name: "𝐀𝐥𝐥 𝐈𝐧 𝐎𝐧𝐞 𝐖𝐏 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-aiowps"], body: ["aiowps"] },
  { name: "𝐖𝐏 𝐂𝐞𝐫𝐛𝐞𝐫", headers: ["x-cerber"], body: ["cerber"] },
  { name: "𝐍𝐢𝐧𝐣𝐚𝐅𝐢𝐫𝐞𝐰𝐚𝐥𝐥", headers: ["x-ninjafirewall"], body: ["ninjafirewall"] },
  { name: "𝐒𝐢𝐭𝐞𝐆𝐫𝐨𝐮𝐧𝐝", headers: ["x-siteground"], body: ["siteground"] },
  { name: "𝐋𝐢𝐭𝐞𝐒𝐩𝐞𝐞𝐝", headers: ["x-litespeed"], body: ["litespeed"] },
  { name: "𝐍𝐠𝐢𝐧𝐱 𝐖𝐀𝐅", headers: ["x-nginx-waf"], body: ["nginx waf"] },
  { name: "𝐎𝐩𝐞𝐧𝐑𝐞𝐬𝐭𝐲 𝐖𝐀𝐅", headers: ["x-openresty"], body: ["openresty"] },
  { name: "𝐊𝐨𝐧𝐠 𝐖𝐀𝐅", headers: ["x-kong"], body: ["kong"] },
  { name: "𝐀𝐩𝐚𝐜𝐡𝐞 𝐖𝐀𝐅", headers: ["x-apache-waf"], body: ["apache"] },
  { name: "𝐈𝐈𝐒 𝐖𝐀𝐅", headers: ["x-iis-waf"], body: ["iis"] },
  { name: "𝐂𝐨𝐦𝐨𝐝𝐨 𝐖𝐀𝐅", headers: ["x-comodo"], body: ["comodo"] },
  { name: "𝐏𝐚𝐥𝐨 𝐀𝐥𝐭𝐨", headers: ["x-paloalto"], body: ["palo alto"] },
  { name: "𝐂𝐡𝐞𝐜𝐤 𝐏𝐨𝐢𝐧𝐭", headers: ["x-checkpoint"], body: ["check point"] },
  { name: "𝐉𝐮𝐧𝐢𝐩𝐞𝐫", headers: ["x-juniper"], body: ["juniper"] },
  { name: "𝐌𝐜𝐀𝐟𝐞𝐞", headers: ["x-mcafee"], body: ["mcafee"] },
  { name: "𝐒𝐲𝐦𝐚𝐧𝐭𝐞𝐜", headers: ["x-symantec"], body: ["symantec"] },
  { name: "𝐓𝐫𝐞𝐧𝐝 𝐌𝐢𝐜𝐫𝐨", headers: ["x-trendmicro"], body: ["trend micro"] },
  { name: "𝐊𝐚𝐬𝐩𝐞𝐫𝐬𝐤𝐲", headers: ["x-kaspersky"], body: ["kaspersky"] },
  { name: "𝐄𝐒𝐄𝐓", headers: ["x-eset"], body: ["eset"] },
  { name: "𝐒𝐨𝐩𝐡𝐨𝐬", headers: ["x-sophos"], body: ["sophos"] },
  { name: "𝐂𝐢𝐬𝐜𝐨", headers: ["x-cisco"], body: ["cisco"] },
  { name: "𝐙𝐬𝐜𝐚𝐥𝐞𝐫", headers: ["x-zscaler"], body: ["zscaler"] },
  { name: "𝐅𝐨𝐫𝐜𝐞𝐩𝐨𝐢𝐧𝐭", headers: ["x-forcepoint"], body: ["forcepoint"] },
  { name: "𝐏𝐫𝐨𝐨𝐟𝐩𝐨𝐢𝐧𝐭", headers: ["x-proofpoint"], body: ["proofpoint"] },
  { name: "𝐌𝐢𝐦𝐞𝐜𝐚𝐬𝐭", headers: ["x-mimecast"], body: ["mimecast"] },
  { name: "𝐁𝐚𝐫𝐫𝐚𝐜𝐮𝐝𝐚 𝐄𝐦𝐚𝐢𝐥", headers: ["x-barracuda-email"], body: ["barracuda email"] },
  { name: "𝐒𝐩𝐚𝐦𝐓𝐢𝐭𝐚𝐧", headers: ["x-spamtitan"], body: ["spamtitan"] },
  { name: "𝐌𝐚𝐢𝐥𝐂𝐥𝐞𝐚𝐧𝐞𝐫", headers: ["x-mailcleaner"], body: ["mailcleaner"] },
  { name: "𝐓𝐫𝐮𝐬𝐭𝐰𝐚𝐯𝐞", headers: ["x-trustwave"], body: ["trustwave"] },
  { name: "𝐀𝐥𝐞𝐫𝐭 𝐋𝐨𝐠𝐢𝐜", headers: ["x-alertlogic"], body: ["alert logic"] },
  { name: "𝐐𝐮𝐚𝐥𝐲𝐬", headers: ["x-qualys"], body: ["qualys"] },
  { name: "𝐑𝐚𝐩𝐢𝐝𝟕", headers: ["x-rapid7"], body: ["rapid7"] },
  { name: "𝐓𝐞𝐧𝐚𝐛𝐥𝐞", headers: ["x-tenable"], body: ["tenable"] },
  { name: "𝐍𝐞𝐬𝐬𝐮𝐬", headers: ["x-nessus"], body: ["nessus"] },
  { name: "𝐎𝐩𝐞𝐧𝐕𝐀𝐒", headers: ["x-openvas"], body: ["openvas"] },
  { name: "𝐒𝐧𝐨𝐫𝐭", headers: ["x-snort"], body: ["snort"] },
  { name: "𝐒𝐮𝐫𝐢𝐜𝐚𝐭𝐚", headers: ["x-suricata"], body: ["suricata"] },
  { name: "𝐙𝐞𝐞𝐤", headers: ["x-zeek"], body: ["zeek"] },
  { name: "𝐎𝐒𝐒𝐄𝐂", headers: ["x-ossec"], body: ["ossec"] },
  { name: "𝐖𝐚𝐳𝐮𝐡", headers: ["x-wazuh"], body: ["wazuh"] },
  { name: "𝐄𝐥𝐚𝐬𝐭𝐢𝐜 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-elastic"], body: ["elastic"] },
  { name: "𝐒𝐩𝐥𝐮𝐧𝐤", headers: ["x-splunk"], body: ["splunk"] },
  { name: "𝐈𝐁𝐌 𝐐𝐑𝐚𝐝𝐚𝐫", headers: ["x-qradar"], body: ["qradar"] },
  { name: "𝐋𝐨𝐠𝐑𝐡𝐲𝐭𝐡𝐦", headers: ["x-logrhythm"], body: ["logrhythm"] },
  { name: "𝐒𝐨𝐥𝐚𝐫𝐖𝐢𝐧𝐝𝐬", headers: ["x-solarwinds"], body: ["solarwinds"] },
  { name: "𝐌𝐚𝐧𝐚𝐠𝐞𝐄𝐧𝐠𝐢𝐧𝐞", headers: ["x-manageengine"], body: ["manageengine"] },
  { name: "𝐃𝐚𝐭𝐚𝐝𝐨𝐠", headers: ["x-datadog"], body: ["datadog"] },
  { name: "𝐍𝐞𝐰 𝐑𝐞𝐥𝐢𝐜", headers: ["x-newrelic"], body: ["new relic"] },
  { name: "𝐃𝐲𝐧𝐚𝐭𝐫𝐚𝐜𝐞", headers: ["x-dynatrace"], body: ["dynatrace"] },
  { name: "𝐀𝐩𝐩𝐃𝐲𝐧𝐚𝐦𝐢𝐜𝐬", headers: ["x-appdynamics"], body: ["appdynamics"] },
  { name: "𝐒𝐢𝐠𝐧𝐚𝐥𝐅𝐱", headers: ["x-signalfx"], body: ["signalfx"] },
  { name: "𝐋𝐚𝐜𝐞𝐰𝐨𝐫𝐤", headers: ["x-lacework"], body: ["lacework"] },
  { name: "𝐏𝐚𝐠𝐞𝐫𝐃𝐮𝐭𝐲", headers: ["x-pagerduty"], body: ["pagerduty"] },
  { name: "𝐎𝐩𝐬𝐠𝐞𝐧𝐢𝐞", headers: ["x-opsgenie"], body: ["opsgenie"] },
  { name: "𝐕𝐢𝐜𝐭𝐨𝐫𝐎𝐩𝐬", headers: ["x-victorops"], body: ["victorops"] },
  { name: "𝐁𝐢𝐠𝐏𝐚𝐧𝐝𝐚", headers: ["x-bigpanda"], body: ["bigpanda"] },
  { name: "𝐌𝐨𝐨𝐠𝐬𝐨𝐟𝐭", headers: ["x-moogsoft"], body: ["moogsoft"] },
  { name: "𝐒𝐭𝐚𝐜𝐤𝐑𝐨𝐱", headers: ["x-stackrox"], body: ["stackrox"] },
  { name: "𝐀𝐪𝐮𝐚 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲", headers: ["x-aqua"], body: ["aqua"] },
  { name: "𝐓𝐰𝐢𝐬𝐭𝐥𝐨𝐜𝐤", headers: ["x-twistlock"], body: ["twistlock"] },
  { name: "𝐒𝐲𝐬𝐝𝐢𝐠", headers: ["x-sysdig"], body: ["sysdig"] },
  { name: "𝐅𝐚𝐥𝐜𝐨", headers: ["x-falco"], body: ["falco"] },
  { name: "𝐂𝐚𝐥𝐢𝐜𝐨", headers: ["x-calico"], body: ["calico"] },
  { name: "𝐂𝐢𝐥𝐢𝐮𝐦", headers: ["x-cilium"], body: ["cilium"] },
  { name: "𝐈𝐬𝐭𝐢𝐨", headers: ["x-istio"], body: ["istio"] },
  { name: "𝐄𝐧𝐯𝐨𝐲", headers: ["x-envoy"], body: ["envoy"] },
  { name: "𝐋𝐢𝐧𝐤𝐞𝐫𝐝", headers: ["x-linkerd"], body: ["linkerd"] },
  { name: "𝐂𝐨𝐧𝐬𝐮𝐥", headers: ["x-consul"], body: ["consul"] },
  { name: "𝐓𝐫𝐚𝐞𝐟𝐢𝐤", headers: ["x-traefik"], body: ["traefik"] },
  { name: "𝐇𝐀𝐏𝐫𝐨𝐱𝐲", headers: ["x-haproxy"], body: ["haproxy"] },
  { name: "𝐍𝐠𝐢𝐧𝐱", headers: ["x-nginx"], body: ["nginx"] },
  { name: "𝐀𝐩𝐚𝐜𝐡𝐞", headers: ["x-apache"], body: ["apache"] },
  { name: "𝐈𝐈𝐒", headers: ["x-iis"], body: ["iis"] },
  { name: "𝐓𝐨𝐦𝐜𝐚𝐭", headers: ["x-tomcat"], body: ["tomcat"] },
  { name: "𝐉𝐞𝐭𝐭𝐲", headers: ["x-jetty"], body: ["jetty"] },
  { name: "𝐖𝐢𝐥𝐝𝐅𝐥𝐲", headers: ["x-wildfly"], body: ["wildfly"] },
  { name: "𝐖𝐞𝐛𝐋𝐨𝐠𝐢𝐜", headers: ["x-weblogic"], body: ["weblogic"] },
  { name: "𝐖𝐞𝐛𝐒𝐩𝐡𝐞𝐫𝐞", headers: ["x-websphere"], body: ["websphere"] },
  { name: "𝐆𝐥𝐚𝐬𝐬𝐅𝐢𝐬𝐡", headers: ["x-glassfish"], body: ["glassfish"] },
  { name: "𝐏𝐚𝐲𝐚𝐫𝐚", headers: ["x-payara"], body: ["payara"] },
  { name: "𝐋𝐢𝐛𝐞𝐫𝐭𝐲", headers: ["x-liberty"], body: ["liberty"] },
  { name: "𝐔𝐧𝐝𝐞𝐫𝐭𝐨𝐰", headers: ["x-undertow"], body: ["undertow"] },
  { name: "𝐆𝐮𝐧𝐢𝐜𝐨𝐫𝐧", headers: ["x-gunicorn"], body: ["gunicorn"] },
  { name: "𝐮𝐖𝐒𝐆𝐈", headers: ["x-uwsgi"], body: ["uwsgi"] },
  { name: "𝐖𝐚𝐢𝐭𝐫𝐞𝐬𝐬", headers: ["x-waitress"], body: ["waitress"] },
  { name: "𝐂𝐡𝐞𝐫𝐫𝐲𝐏𝐲", headers: ["x-cherrypy"], body: ["cherrypy"] },
  { name: "𝐓𝐨𝐫𝐧𝐚𝐝𝐨", headers: ["x-tornado"], body: ["tornado"] },
  { name: "𝐅𝐥𝐚𝐬𝐤", headers: ["x-flask"], body: ["flask"] },
  { name: "𝐃𝐣𝐚𝐧𝐠𝐨", headers: ["x-django"], body: ["django"] },
  { name: "𝐄𝐱𝐩𝐫𝐞𝐬𝐬", headers: ["x-express"], body: ["express"] },
  { name: "𝐊𝐨𝐚", headers: ["x-koa"], body: ["koa"] },
  { name: "𝐅𝐚𝐬𝐭𝐢𝐟𝐲", headers: ["x-fastify"], body: ["fastify"] },
  { name: "𝐍𝐞𝐬𝐭𝐉𝐒", headers: ["x-nestjs"], body: ["nestjs"] },
  { name: "𝐒𝐩𝐫𝐢𝐧𝐠 𝐁𝐨𝐨𝐭", headers: ["x-spring"], body: ["spring"] },
  { name: "𝐐𝐮𝐚𝐫𝐤𝐮𝐬", headers: ["x-quarkus"], body: ["quarkus"] },
  { name: "𝐌𝐢𝐜𝐫𝐨𝐧𝐚𝐮𝐭", headers: ["x-micronaut"], body: ["micronaut"] },
  { name: "𝐕𝐞𝐫𝐭.𝐱", headers: ["x-vertx"], body: ["vertx"] },
  { name: "𝐏𝐥𝐚𝐲 𝐅𝐫𝐚𝐦𝐞𝐰𝐨𝐫𝐤", headers: ["x-play"], body: ["play framework"] },
  { name: "𝐋𝐚𝐫𝐚𝐯𝐞𝐥", headers: ["x-laravel"], body: ["laravel"] },
  { name: "𝐒𝐲𝐦𝐟𝐨𝐧𝐲", headers: ["x-symfony"], body: ["symfony"] },
  { name: "𝐂𝐨𝐝𝐞𝐈𝐠𝐧𝐢𝐭𝐞𝐫", headers: ["x-codeigniter"], body: ["codeigniter"] },
  { name: "𝐂𝐚𝐤𝐞𝐏𝐇𝐏", headers: ["x-cakephp"], body: ["cakephp"] },
  { name: "𝐘𝐢𝐢", headers: ["x-yii"], body: ["yii"] },
  { name: "𝐙𝐞𝐧𝐝", headers: ["x-zend"], body: ["zend"] },
  { name: "𝐏𝐡𝐚𝐥𝐜𝐨𝐧", headers: ["x-phalcon"], body: ["phalcon"] },
  { name: "𝐒𝐥𝐢𝐦", headers: ["x-slim"], body: ["slim"] },
  { name: "𝐅𝐮𝐞𝐥𝐏𝐇𝐏", headers: ["x-fuelphp"], body: ["fuelphp"] }
];

async function fingerprintWAF(headers, html) {
  const detected = [];
  const full = html.toLowerCase();
  for (const waf of WAF_SIGNATURES) {
    let found = false;
    for (const h of waf.headers) if (headers[h] || headers[h.toLowerCase()]) { found = true; break; }
    if (!found && waf.body.length) for (const b of waf.body) if (full.includes(b)) { found = true; break; }
    if (found) detected.push(waf.name);
  }
  return detected.length ? [...new Set(detected)] : ["𝐓𝐢𝐝𝐚𝐤 𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢"];
}

const CDN_SIGNATURES = [
  { name: "𝐂𝐥𝐨𝐮𝐝𝐟𝐥𝐚𝐫𝐞", via: "cloudflare", headers: ["cf-ray"] },
  { name: "𝐀𝐤𝐚𝐦𝐚𝐢", via: "akamai", headers: ["x-akamai"] },
  { name: "𝐅𝐚𝐬𝐭𝐥𝐲", via: "fastly", headers: ["x-served-by","x-cache"] },
  { name: "𝐀𝐰𝐬 𝐂𝐥𝐨𝐮𝐝𝐅𝐫𝐨𝐧𝐭", via: "cloudfront", headers: ["x-amz-cf-id"] },
  { name: "𝐆𝐨𝐨𝐠𝐥𝐞 𝐂𝐥𝐨𝐮𝐝 𝐂𝐝𝐧", via: "google", headers: ["x-cache"] },
  { name: "𝐊𝐞𝐲𝐂𝐝𝐧", via: "keycdn", headers: [] },
  { name: "𝐒𝐭𝐚𝐜𝐤𝐏𝐚𝐭𝐡", via: "stackpath", headers: ["x-stackpath"] },
  { name: "𝐈𝐦𝐩𝐞𝐫𝐯𝐚", via: "incapsula", headers: ["x-iinfo"] },
  { name: "𝐒𝐮𝐜𝐮𝐫𝐢", via: "sucuri", headers: ["x-sucuri"] },
  { name: "𝐀𝐳𝐮𝐫𝐞 𝐂𝐝𝐧", via: "azure", headers: ["x-azure-ref"] },
  { name: "𝐀𝐥𝐢𝐛𝐚𝐛𝐚 𝐂𝐝𝐧", via: "alibaba", headers: ["x-alibaba"] },
  { name: "𝐁𝐮𝐧𝐧𝐲𝐂𝐝𝐧", via: "bunny", headers: ["x-bunny"] },
  { name: "𝐂𝐝𝐧𝟕𝟕", via: "cdn77", headers: ["x-cdn77"] },
  { name: "𝐆-𝐂𝐨𝐫𝐞 𝐋𝐚𝐛𝐬", via: "gcore", headers: ["x-gcore"] },
  { name: "𝐋𝐞𝐚𝐬𝐞𝐰𝐞𝐛 𝐂𝐝𝐧", via: "leaseweb", headers: ["x-lw-cache"] },
  { name: "𝐄𝐝𝐠𝐞𝐜𝐚𝐬𝐭", via: "edgecast", headers: ["x-ec-cache"] },
  { name: "𝐋𝐢𝐦𝐞𝐥𝐢𝐠𝐡𝐭", via: "limelight", headers: ["x-llnw-cache"] },
  { name: "𝐂𝐚𝐜𝐡𝐞𝐅𝐥𝐲", via: "cachefly", headers: ["x-cf1"] },
  { name: "𝐐𝐮𝐚𝐧𝐭𝐢𝐥", via: "quantil", headers: ["x-q-cache"] },
  { name: "𝐂𝐡𝐢𝐧𝐚𝐂𝐚𝐜𝐡𝐞", via: "chinacache", headers: ["x-cc-cache"] },
  { name: "𝐖𝐚𝐧𝐠𝐬𝐮", via: "wangsu", headers: ["x-ws-cache"] }
];

async function detectCDN(headers, domain) {
  const detected = [];
  for (const cdn of CDN_SIGNATURES) {
    let found = false;
    if (headers["via"] && headers["via"].toLowerCase().includes(cdn.via)) found = true;
    if (headers["server"] && headers["server"].toLowerCase().includes(cdn.via)) found = true;
    for (const h of cdn.headers) if (headers[h] || headers[h.toLowerCase()]) { found = true; break; }
    if (found) detected.push(cdn.name);
  }
  if (!detected.length) {
    try {
      const dnsIps = await dns.resolve4(domain);
      const realIp = headers["x-forwarded-for"] || headers["cf-connecting-ip"];
      if (dnsIps.length && realIp && !dnsIps.includes(realIp)) detected.push("𝐑𝐞𝐯𝐞𝐫𝐬𝐞 𝐏𝐫𝐨𝐱𝐲 (𝐂𝐃𝐍)");
    } catch(e) {}
  }
  return detected;
}

async function detectDDoSProvider(headers, html) {
  const providers = [
    { name: "𝐂𝐥𝐨𝐮𝐝𝐟𝐥𝐚𝐫𝐞", sigs: ["cf-ray","__cf_bm","cf_clearance"] },
    { name: "𝐀𝐤𝐚𝐦𝐚𝐢 𝐏𝐫𝐨𝐥𝐞𝐱𝐢𝐜", sigs: ["akamai","prolexic"] },
    { name: "𝐀𝐰𝐬 𝐒𝐡𝐢𝐞𝐥𝐝", sigs: ["aws","shield","x-amzn"] },
    { name: "𝐆𝐨𝐨𝐠𝐥𝐞 𝐂𝐥𝐨𝐮𝐝 𝐀𝐫𝐦𝐨𝐫", sigs: ["google","cloud-armor"] },
    { name: "𝐅𝐚𝐬𝐭𝐥𝐲 𝐃𝐃𝐨𝐒", sigs: ["fastly"] },
    { name: "𝐈𝐦𝐩𝐞𝐫𝐯𝐚 𝐃𝐃𝐨𝐒", sigs: ["incapsula","imperva"] },
    { name: "𝐑𝐚𝐝𝐰𝐚𝐫𝐞", sigs: ["radware","defensepro"] },
    { name: "𝐀𝐫𝐛𝐨𝐫 𝐍𝐞𝐭𝐰𝐨𝐫𝐤𝐬", sigs: ["arbor","peakflow"] },
    { name: "𝐍𝐞𝐱𝐮𝐬𝐠𝐮𝐚𝐫𝐝", sigs: ["nexusguard"] },
    { name: "𝐕𝐞𝐫𝐢𝐬𝐢𝐠𝐧", sigs: ["verisign"] },
    { name: "𝐃𝐃𝐨𝐒-𝐆𝐮𝐚𝐫𝐝", sigs: ["ddos-guard"] },
    { name: "𝐕𝐨𝐱𝐢𝐥𝐢𝐭𝐲", sigs: ["voxility"] },
    { name: "𝐅5 𝐒𝐢𝐥𝐯𝐞𝐫𝐥𝐢𝐧𝐞", sigs: ["silverline"] }
  ];
  const full = html.toLowerCase() + JSON.stringify(headers).toLowerCase();
  const detected = [];
  for (const p of providers) for (const sig of p.sigs) if (full.includes(sig)) { detected.push(p.name); break; }
  return detected.length ? [...new Set(detected)] : ["𝐓𝐢𝐝𝐚𝐤 𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢"];
}

async function testRateLimitAggressive(url, concurrency=40, duration=4) {
  const start = Date.now();
  let total=0, codes={200:0,403:0,429:0,503:0,other:0};
  const makeReq = async () => {
    try {
      const res = await axios.get(url, { headers:{'User-Agent':randomUA()}, timeout:5000, validateStatus:()=>true });
      codes[res.status] = (codes[res.status]||0)+1;
      total++;
    } catch(e) { codes.other++; total++; }
  };
  while (Date.now()-start < duration*1000) {
    const promises = [];
    for (let i=0; i<concurrency; i++) promises.push(makeReq());
    await Promise.all(promises);
    await sleep(20);
  }
  const blocked = codes[403]+codes[429]+codes[503]+codes.other;
  const limited = blocked > total*0.25;
  return { limited, total, blocked, percent: ((blocked/total)*100).toFixed(1) };
}

async function testAdaptiveRateLimit(url) {
  const ips = ["192.168.1.1","10.0.0.1","172.16.0.1","8.8.8.8","1.1.1.1"];
  let blocked=0;
  for (const ip of ips) {
    try {
      const res = await axios.get(url, { headers:{'User-Agent':randomUA(),'X-Forwarded-For':ip,'X-Real-IP':ip}, timeout:5000, validateStatus:()=>true });
      if ([403,429,503].includes(res.status)) blocked++;
    } catch(e) { blocked++; }
    await sleep(150);
  }
  const ipBased = blocked > ips.length*0.5;
  return { ipBased, note: ipBased ? "𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢" : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
}

async function testSlowloris(url, concurrency=60, duration=4) {
  const start = Date.now();
  let success=0;
  const agent = new https.Agent({ keepAlive:true, maxSockets:concurrency });
  for (let i=0; i<concurrency && Date.now()-start<duration*1000; i++) {
    axios.get(url, { headers:{'User-Agent':randomUA(),'X-Slow':'A'.repeat(8000)}, timeout:10000, httpAgent:agent, httpsAgent:agent }).then(()=>success++).catch(()=>{});
    await sleep(80);
  }
  const vulnerable = success < concurrency*0.6;
  return { vulnerable, note: vulnerable ? "𝐑𝐞𝐧𝐭𝐚𝐧" : "𝐀𝐦𝐚𝐧" };
}

async function detectCaptchaAndChallenge(page) {
  const html = await page.content();
  const result = { captcha:false, captchaType:null, jsChallenge:false, challengeType:null };
  const indicators = [
    { type:"𝐫𝐞𝐂𝐚𝐩𝐭𝐜𝐡𝐚 𝐯2", patterns:["g-recaptcha","recaptcha-checkbox"] },
    { type:"𝐫𝐞𝐂𝐚𝐩𝐭𝐜𝐡𝐚 𝐯3", patterns:["recaptcha/api2","grecaptcha.execute"] },
    { type:"𝐡𝐂𝐚𝐩𝐭𝐜𝐡𝐚", patterns:["h-captcha","hcaptcha-challenge"] },
    { type:"𝐂𝐅 𝐓𝐮𝐫𝐧𝐬𝐭𝐢𝐥𝐞", patterns:["turnstile","cf-turnstile"] },
    { type:"𝐓𝐞𝐱𝐭 𝐂𝐚𝐩𝐭𝐜𝐡𝐚", patterns:["captcha code","type the letters"] }
  ];
  for (const ind of indicators) for (const pat of ind.patterns) if (html.toLowerCase().includes(pat)) { result.captcha=true; result.captchaType=ind.type; break; }
  if (html.includes("__cf_chl") || html.includes("cf_chl_prog") || html.includes("Just a moment")) { result.jsChallenge=true; result.challengeType="𝐂𝐅 𝐈'𝐚𝐦 𝐔𝐧𝐝𝐞𝐫 𝐀𝐭𝐭𝐚𝐜𝐤"; }
  if (html.includes("ddos_guard") || html.includes("dg_challenge")) { result.jsChallenge=true; result.challengeType="𝐃𝐃𝐨𝐒-𝐆𝐮𝐚𝐫𝐝 𝐂𝐡𝐚𝐥𝐥𝐞𝐧𝐠𝐞"; }
  return result;
}

async function testHttp2RapidReset(url) {
  return new Promise(async (resolve) => {
    let client = null;
    try {
      const http2 = require('http2');
      const urlObj = new URL(url);
      if (urlObj.protocol !== 'https:') return resolve({ vulnerable: false, note: "𝐇𝐓𝐓𝐏/𝟐 𝐭𝐢𝐝𝐚𝐤 𝐭𝐞𝐫𝐬𝐞𝐝𝐢𝐚" });
      client = http2.connect(urlObj.origin, { timeout: 5000, rejectUnauthorized: false });
      client.on('error', () => { if(client && !client.destroyed) client.destroy(); resolve({ vulnerable: false, note: "𝐀𝐦𝐚𝐧" }); });
      await new Promise((res,rej) => {
        const t = setTimeout(() => rej(new Error('timeout')), 5000);
        client.once('connect', () => { clearTimeout(t); res(); });
        client.once('error', (e) => { clearTimeout(t); rej(e); });
      });
      for (let i=0; i<CONFIG.RAPID_RESET_STREAMS; i++) {
        const req = client.request({ ':path': urlObj.pathname });
        req.on('response',()=>{});
        req.on('error',()=>{});
        req.close();
        await new Promise(r=>setTimeout(r,5));
      }
      await new Promise(r=>setTimeout(r,100));
      client.destroy();
      resolve({ vulnerable: true, note: "𝐑𝐞𝐧𝐭𝐚𝐧" });
    } catch(e) {
      if(client && !client.destroyed) client.destroy();
      resolve({ vulnerable: false, note: "𝐀𝐦𝐚𝐧" });
    }
  });
}

async function testWebSocketProtection(url) {
  const WebSocket = require('ws');
  const host = new URL(url).hostname;
  const wsUrl = `wss://${host}`;
  let protected = false;
  try {
    const ws = new WebSocket(wsUrl, { timeout: CONFIG.WEBSOCKET_TEST_TIMEOUT });
    ws.on('error', (err) => { if(err.message.includes('401')||err.message.includes('403')) protected=true; ws.close(); });
    ws.on('open', () => { ws.send('ping'); setTimeout(()=>ws.close(),500); });
    await new Promise(r=>setTimeout(r,3000));
    return { protected, note: protected ? "𝐓𝐞𝐫𝐩𝐫𝐨𝐭𝐞𝐤𝐬𝐢" : "𝐓𝐢𝐝𝐚𝐤 𝐓𝐞𝐫𝐩𝐫𝐨𝐭𝐞𝐤𝐬𝐢" };
  } catch(e) { return { protected:false, note:"𝐖𝐞𝐛𝐒𝐨𝐜𝐤𝐞𝐭 𝐭𝐢𝐝𝐚𝐤 𝐭𝐞𝐫𝐬𝐞𝐝𝐢𝐚" }; }
}

async function testDnsReflection(domain) {
  let openResolver = false;
  try {
    const dnsPacket = require('dns-packet');
    const dgram = require('dgram');
    const client = dgram.createSocket('udp4');
    const query = dnsPacket.encode({ type:'query', id:Math.floor(Math.random()*65535), flags:dnsPacket.RECURSION_DESIRED, questions:[{name:domain,type:'A',class:'IN'}] });
    await new Promise((resolve) => {
      client.send(query, 53, '8.8.8.8', (err) => { if(err) openResolver=false; resolve(); });
      client.on('message', () => { openResolver=true; resolve(); });
      setTimeout(() => resolve(), 2000);
    });
    client.close();
  } catch(e) {}
  return { openResolver, note: openResolver ? "𝐑𝐞𝐧𝐭𝐚𝐧 (𝐃𝐍𝐒 𝐚𝐦𝐩𝐥𝐢𝐟𝐢𝐤𝐚𝐬𝐢)" : "𝐀𝐦𝐚𝐧" };
}

async function detectAnycast(domain) {
  let ips = [];
  try { ips = await dns.resolve4(domain); } catch(e) {}
  const anycast = ips.length > 2;
  let traceroute = "";
  try {
    const out = execSync(`traceroute -n -m 5 ${domain} 2>/dev/null || tracepath -n ${domain} 2>/dev/null`, { encoding:'utf8', timeout:10000 });
    traceroute = out.split('\n').slice(0,5).join(' ').substring(0,150);
  } catch(e) {}
  return { anycast, ipCount: ips.length, traceroute: traceroute || "𝐓𝐢𝐝𝐚𝐤 𝐭𝐞𝐫𝐬𝐞𝐝𝐢𝐚" };
}

async function testLoadDegradation(url) {
  let baseline = 0;
  try {
    const start = Date.now();
    await axios.get(url, { timeout: 10000 });
    baseline = Date.now() - start;
  } catch(e) { baseline = 5000; }
  const startLoad = Date.now();
  let totalResp=0, success=0;
  while (Date.now()-startLoad < CONFIG.LOAD_TEST_DURATION*1000) {
    const promises = [];
    for (let i=0; i<CONFIG.LOAD_TEST_CONCURRENCY; i++) {
      promises.push((async () => {
        try {
          const s = Date.now();
          await axios.get(url, { timeout: 5000 });
          totalResp += Date.now()-s;
          success++;
        } catch(e) {}
      })());
    }
    await Promise.all(promises);
    await sleep(50);
  }
  const avgLoad = totalResp / (success||1);
  const degradation = ((avgLoad - baseline)/baseline)*100;
  const severe = degradation > 150;
  return { baseline, avgLoad: avgLoad.toFixed(0), degradation: degradation.toFixed(1), severe };
}

async function testTrafficAnomaly(url) {
  const start = Date.now();
  let total=0, blocked=0;
  while (Date.now()-start < 2000) {
    const promises = [];
    for (let i=0; i<20; i++) {
      promises.push(axios.get(url, { headers:{'User-Agent':randomUA()}, timeout:3000, validateStatus:()=>true }).then(res => { if(res.status>=429) blocked++; total++; }).catch(()=>{ blocked++; total++; }));
    }
    await Promise.all(promises);
    await sleep(10);
  }
  const blockRate = (blocked/total)*100;
  const aggressive = blockRate > 60;
  return { aggressive, blockRate: blockRate.toFixed(1) };
}

async function threatIntel(domain, ip) {
  let score=0, reports=[];
  if (CONFIG.THREAT_INTEL_APIS.VIRUSTOTAL) {
    try {
      const res = await axios.get(`https://www.virustotal.com/api/v3/domains/${domain}`, { headers:{'x-apikey':CONFIG.THREAT_INTEL_APIS.VIRUSTOTAL}, timeout:5000 });
      const mal = res.data.data.attributes.last_analysis_stats.malicious || 0;
      if (mal>0) score+=30; if (mal>2) score+=20;
      reports.push(`VirusTotal: ${mal} malicious`);
    } catch(e) {}
  }
  if (CONFIG.THREAT_INTEL_APIS.ABUSEIPDB && ip) {
    try {
      const res = await axios.get(`https://api.abuseipdb.com/api/v2/check?ipAddress=${ip}`, { headers:{'Key':CONFIG.THREAT_INTEL_APIS.ABUSEIPDB,'Accept':'application/json'}, timeout:5000 });
      const abuse = res.data.data.abuseConfidenceScore || 0;
      if (abuse>50) score+=25;
      reports.push(`AbuseIPDB: confidence ${abuse}`);
    } catch(e) {}
  }
  try {
    const res = await axios.get(`https://otx.alienvault.com/api/v1/indicators/domain/${domain}/general`, { timeout:5000 });
    const pulses = res.data.pulse_count || 0;
    if (pulses>0) score+=20;
    reports.push(`AlienVault: ${pulses} pulses`);
  } catch(e) {}
  const level = score>=50 ? "𝐓𝐢𝐧𝐠𝐠𝐢" : (score>=20 ? "𝐒𝐞𝐝𝐚𝐧𝐠" : "𝐑𝐞𝐧𝐝𝐚𝐡");
  return { threatScore: score, level, reports };
}

function analyzeSecurityHeaders(headers) {
  const list = {
    "strict-transport-security":"𝐇𝐒𝐓𝐒","content-security-policy":"𝐂𝐒𝐏","x-frame-options":"𝐗𝐅𝐎",
    "x-content-type-options":"𝐗𝐂𝐓𝐎","referrer-policy":"𝐑𝐞𝐟𝐞𝐫𝐫𝐞𝐫","permissions-policy":"𝐏𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬",
    "cross-origin-opener-policy":"𝐂𝐎𝐎𝐏","cross-origin-embedder-policy":"𝐂𝐎𝐄𝐏","cross-origin-resource-policy":"𝐂𝐎𝐑𝐏",
    "x-xss-protection":"𝐗𝐒𝐒","expect-ct":"𝐄𝐱𝐩𝐞𝐜𝐭-𝐂𝐓","feature-policy":"𝐅𝐞𝐚𝐭𝐮𝐫𝐞","report-to":"𝐑𝐞𝐩𝐨𝐫𝐭-𝐓𝐨",
    "nel":"𝐍𝐄𝐋","access-control-allow-origin":"𝐂𝐎𝐑𝐒"
  };
  let present=[], missing=[];
  for (const [h,name] of Object.entries(list)) {
    if (headers[h]) present.push(name);
    else missing.push(name);
  }
  return { present, missing };
}

async function detectTechStack(page, headers, html) {
  const techs = new Set();
  if (headers.server) techs.add(`𝐒𝐞𝐫𝐯𝐞𝐫: ${headers.server}`);
  if (headers['x-powered-by']) techs.add(`𝐗-𝐏𝐨𝐰𝐞𝐫𝐞𝐝-𝐁𝐲: ${headers['x-powered-by']}`);
  if (html.includes('wp-content')) techs.add("𝐖𝐨𝐫𝐝𝐏𝐫𝐞𝐬𝐬");
  if (html.includes('drupal')) techs.add("𝐃𝐫𝐮𝐩𝐚𝐥");
  if (html.includes('joomla')) techs.add("𝐉𝐨𝐨𝐦𝐥𝐚");
  if (html.includes('react') || html.includes('_next')) techs.add("𝐑𝐞𝐚𝐜𝐭/𝐍𝐞𝐱𝐭.𝐣𝐬");
  if (html.includes('vue')) techs.add("𝐕𝐮𝐞.𝐣𝐬");
  if (html.includes('angular')) techs.add("𝐀𝐧𝐠𝐮𝐥𝐚𝐫");
  if (html.includes('jquery')) techs.add("𝐣𝐐𝐮𝐞𝐫𝐲");
  if (html.includes('bootstrap')) techs.add("𝐁𝐨𝐨𝐭𝐬𝐭𝐫𝐚𝐩");
  if (html.includes('tailwind')) techs.add("𝐓𝐚𝐢𝐥𝐰𝐢𝐧𝐝 𝐂𝐒𝐒");
  if (html.includes('laravel')) techs.add("𝐋𝐚𝐫𝐚𝐯𝐞𝐥");
  if (html.includes('symfony')) techs.add("𝐒𝐲𝐦𝐟𝐨𝐧𝐲");
  if (html.includes('codeigniter')) techs.add("𝐂𝐨𝐝𝐞𝐈𝐠𝐧𝐢𝐭𝐞𝐫");
  if (html.includes('express')) techs.add("𝐄𝐱𝐩𝐫𝐞𝐬𝐬.𝐣𝐬");
  if (html.includes('django')) techs.add("𝐃𝐣𝐚𝐧𝐠𝐨");
  if (html.includes('flask')) techs.add("𝐅𝐥𝐚𝐬𝐤");
  if (html.includes('ruby on rails')) techs.add("𝐑𝐮𝐛𝐲 𝐨𝐧 𝐑𝐚𝐢𝐥𝐬");
  if (html.includes('asp.net') || headers['x-aspnet-version']) techs.add("𝐀𝐒𝐏.𝐍𝐄𝐓");
  if (html.includes('php') && headers['x-powered-by']?.includes('PHP')) techs.add("𝐏𝐇𝐏");
  if (html.includes('shopify')) techs.add("𝐒𝐡𝐨𝐩𝐢𝐟𝐲");
  if (html.includes('magento')) techs.add("𝐌𝐚𝐠𝐞𝐧𝐭𝐨");
  if (html.includes('prestashop')) techs.add("𝐏𝐫𝐞𝐬𝐭𝐚𝐒𝐡𝐨𝐩");
  if (html.includes('woocommerce')) techs.add("𝐖𝐨𝐨𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞");
  if (html.includes('graphql')) techs.add("𝐆𝐫𝐚𝐩𝐡𝐐𝐋");
  if (html.includes('swagger')) techs.add("𝐒𝐰𝐚𝐠𝐠𝐞𝐫 𝐔𝐈");
  return [...techs];
}

async function detectBrowserFingerprint(page) {
  const fp = await page.evaluate(() => ({
    userAgent: navigator.userAgent,
    languages: navigator.languages,
    platform: navigator.platform,
    webgl: !!document.createElement('canvas').getContext('webgl')
  }));
  const html = await page.content();
  const detection = html.includes('fingerprint') || html.includes('clientjs') || html.includes('fp_collect');
  return { fingerprinting: detection, details: fp };
}

async function scanOpenPorts(domain) {
  const ports = [80,443,8080,8443,3000,5000,8000,8888,9000];
  const open = [];
  for (const port of ports) {
    const proto = (port===443||port===8443) ? 'https' : 'http';
    try {
      const res = await axios.get(`${proto}://${domain}:${port}`, { timeout: 2000, validateStatus:()=>true });
      if (res.status < 500) open.push(`${port} (${proto.toUpperCase()})`);
    } catch(e) {}
    await sleep(50);
  }
  return open;
}

async function testCorsAndCsrf(url) {
  let corsVuln = false;
  let csrfToken = false;
  try {
    const res = await axios.get(url, { headers:{'Origin':'https://evil.com'}, timeout:5000 });
    const acao = res.headers['access-control-allow-origin'];
    if (acao === '*' || acao === 'https://evil.com') corsVuln = true;
  } catch(e) {}
  const html = await axios.get(url).then(r=>r.data).catch(()=>'');
  if (html.includes('csrf') || html.includes('_token') || html.includes('X-CSRF')) csrfToken = true;
  return { corsVuln, csrfToken };
}

async function getTLSDetails(host) {
  return new Promise((resolve) => {
    const socket = tls.connect({ host, port:443, servername:host, rejectUnauthorized:false }, () => {
      const cert = socket.getPeerCertificate(true);
      const info = {
        version: socket.getProtocol(),
        cipher: `${socket.getCipher().name} (${socket.getCipher().version})`,
        alpn: socket.alpnProtocol,
        validFrom: cert.valid_from,
        validTo: cert.valid_to,
        issuer: cert.issuer?.O || cert.issuer?.CN,
        subject: cert.subject?.CN
      };
      socket.end();
      resolve(info);
    });
    socket.setTimeout(5000);
    socket.on('error', () => resolve(null));
    socket.on('timeout', () => { socket.destroy(); resolve(null); });
  });
}

function analyzeCookies(headers) {
  const setCookie = headers['set-cookie'];
  if (!setCookie) return { secure: false, httpOnly: false, sameSite: false };
  const cookies = Array.isArray(setCookie) ? setCookie : [setCookie];
  let secure=false, httpOnly=false, sameSite=false;
  for (const c of cookies) {
    if (c.toLowerCase().includes('secure')) secure=true;
    if (c.toLowerCase().includes('httponly')) httpOnly=true;
    if (c.toLowerCase().includes('samesite')) sameSite=true;
  }
  return { secure, httpOnly, sameSite };
}

async function testSqlInjection(url) {
  const payloads = ["'", "\"", "1' OR '1'='1", "1 AND 1=1"];
  let vulnerable = false;
  for (const payload of payloads) {
    try {
      const testUrl = `${url}?id=${encodeURIComponent(payload)}&page=1`;
      const res = await axios.get(testUrl, { timeout: 5000, validateStatus: () => true });
      const body = res.data.toLowerCase();
      if (body.includes("sql") || body.includes("mysql") || body.includes("syntax error")) {
        vulnerable = true;
        break;
      }
    } catch(e) {}
    await sleep(200);
  }
  return { vulnerable, note: vulnerable ? "𝐑𝐞𝐧𝐭𝐚𝐧 (𝐒𝐐𝐋𝐢)" : "𝐀𝐦𝐚𝐧" };
}

async function testXssReflected(url) {
  const payload = "<script>alert(1)</script>";
  let vulnerable = false;
  try {
    const testUrl = `${url}?q=${encodeURIComponent(payload)}`;
    const res = await axios.get(testUrl, { timeout: 5000 });
    if (res.data.includes(payload)) vulnerable = true;
  } catch(e) {}
  return { vulnerable, note: vulnerable ? "𝐑𝐞𝐧𝐭𝐚𝐧 (𝐗𝐒𝐒)" : "𝐀𝐦𝐚𝐧" };
}

async function checkDirectoryListing(url) {
  let vulnerable = false;
  try {
    const testUrl = url.replace(/\/$/, "") + "/images/";
    const res = await axios.get(testUrl, { timeout: 5000 });
    if (res.data.includes("Index of /") || (res.headers["content-type"]?.includes("text/html") && (res.data.includes("<title>Index of") || res.data.includes("Directory listing")))) {
      vulnerable = true;
    }
  } catch(e) {}
  return { vulnerable, note: vulnerable ? "𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢" : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
}

async function checkBackupFiles(url) {
  const backups = [".git/config", ".env", "backup.zip", "backup.sql", "config.php.bak", ".htaccess.bak", "wp-config.php.bak"];
  let found = [];
  for (const file of backups) {
    try {
      const testUrl = url.replace(/\/$/, "") + "/" + file;
      const res = await axios.get(testUrl, { timeout: 3000, validateStatus: () => true });
      if (res.status === 200 && res.data.length > 0) found.push(file);
    } catch(e) {}
  }
  return { found, note: found.length ? `𝐃𝐢𝐭𝐞𝐦𝐮𝐤𝐚𝐧: ${found.join(", ")}` : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
}

async function checkAdminPanels(url) {
  const panels = ["/admin", "/administrator", "/wp-admin", "/login", "/cpanel", "/dashboard", "/admin/login", "/panel"];
  let found = [];
  for (const panel of panels) {
    try {
      const testUrl = url.replace(/\/$/, "") + panel;
      const res = await axios.get(testUrl, { timeout: 3000, validateStatus: () => true });
      if (res.status === 200 && (res.data.toLowerCase().includes("login") || res.data.toLowerCase().includes("admin"))) {
        found.push(panel);
      }
    } catch(e) {}
  }
  return { found, note: found.length ? `𝐃𝐢𝐭𝐞𝐦𝐮𝐤𝐚𝐧: ${found.join(", ")}` : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
}

async function checkOpenRedirect(url) {
  const redirectUrl = "https://evil.com";
  let vulnerable = false;
  try {
    const testUrl = `${url}?redirect=${encodeURIComponent(redirectUrl)}&next=${encodeURIComponent(redirectUrl)}`;
    const res = await axios.get(testUrl, { maxRedirects: 0, validateStatus: () => true });
    if (res.headers.location && (res.headers.location.includes("evil.com") || res.headers.location === redirectUrl)) {
      vulnerable = true;
    }
  } catch(e) {}
  return { vulnerable, note: vulnerable ? "𝐑𝐞𝐧𝐭𝐚𝐧" : "𝐀𝐦𝐚𝐧" };
}

function extractEmails(html) {
  const regex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const emails = html.match(regex) || [];
  return [...new Set(emails)].slice(0,5);
}

function checkInternalIpDisclosure(html) {
  const internalIps = ["10.0.0.", "172.16.", "192.168.", "127.0.0.1", "localhost"];
  let found = [];
  for (const ip of internalIps) {
    if (html.includes(ip)) found.push(ip);
  }
  return { found, note: found.length ? "𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢" : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
}

function checkCspWeaknesses(headers) {
  const csp = headers["content-security-policy"];
  if (!csp) return { weak: true, note: "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚 (𝐂𝐒𝐏 𝐦𝐢𝐬𝐬𝐢𝐧𝐠)" };
  const weak = csp.includes("unsafe-inline") || csp.includes("unsafe-eval") || csp.includes("*");
  return { weak, note: weak ? "𝐋𝐞𝐦𝐚𝐡" : "𝐂𝐮𝐤𝐮𝐩 𝐊𝐮𝐚𝐭" };
}

async function checkSubdomainTakeover(domain) {
  const subdomains = ["test", "dev", "staging", "cdn", "mail", "ftp", "admin", "blog", "shop"];
  let vulnerable = [];
  for (const sub of subdomains) {
    try {
      const full = `${sub}.${domain}`;
      const cname = await dns.resolveCname(full).catch(() => []);
      if (cname.length && (cname[0].includes("github.io") || cname[0].includes("herokuapp.com") || cname[0].includes("netlify.app") || cname[0].includes("azurewebsites.net"))) {
        vulnerable.push(full);
      }
    } catch(e) {}
  }
  return { vulnerable, note: vulnerable.length ? `𝐑𝐞𝐧𝐭𝐚𝐧: ${vulnerable.join(", ")}` : "𝐀𝐦𝐚𝐧" };
}

function checkHstsPreload(headers) {
  const hsts = headers["strict-transport-security"];
  if (!hsts) return { preload: false, note: "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚" };
  const preload = hsts.toLowerCase().includes("preload");
  return { preload, note: preload ? "𝐀𝐤𝐭𝐢𝐟" : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐤𝐭𝐢𝐟" };
}

function rateSslTls(tlsInfo) {
  if (!tlsInfo) return { rating: "𝐓𝐢𝐝𝐚𝐤 𝐓𝐞𝐫𝐬𝐞𝐝𝐢𝐚", score: 0 };
  let score = 0;
  if (tlsInfo.version === "TLSv1.3") score = 100;
  else if (tlsInfo.version === "TLSv1.2") score = 80;
  else if (tlsInfo.version === "TLSv1.1") score = 40;
  else if (tlsInfo.version === "TLSv1.0") score = 20;
  else score = 10;
  const rating = score >= 80 ? "𝐁𝐚𝐢𝐤" : (score >= 50 ? "𝐒𝐞𝐝𝐚𝐧𝐠" : "𝐋𝐞𝐦𝐚𝐡");
  return { rating, score };
}

async function tryClickChallenge(page) {
  await sleep(2000);
  const frames = page.frames();
  for (const frame of frames) {
    try {
      const recaptchaCheckbox = await frame.$('#recaptcha-anchor, .recaptcha-checkbox-border, .recaptcha-checkbox');
      if (recaptchaCheckbox) {
        await recaptchaCheckbox.click();
        return true;
      }
    } catch(e) {}
  }
  const selectors = [
    'button:has-text("Verifikasi")', 'button:has-text("Verify")', 'button:has-text("I am not a robot")',
    'button:has-text("Lanjutkan")', 'button:has-text("Continue")', '#challenge-form button',
    '.challenge-button', '.verify-button', 'input[type="submit"]', 'button[type="submit"]',
    'a[class*="verify"]', 'div[class*="checkbox"]', 'span[role="checkbox"]'
  ];
  for (const selector of selectors) {
    try {
      const btn = await page.$(selector);
      if (btn) {
        await btn.click();
        return true;
      }
    } catch(e) {}
  }
  try {
    await page.evaluate(() => {
      const forms = document.querySelectorAll('form');
      for (const form of forms) {
        const submit = form.querySelector('button, input[type="submit"]');
        if (submit) submit.click();
      }
    });
    return true;
  } catch(e) {}
  return false;
}

async function takeScreenshot(url) {
  let browser;
  try {
    const executablePath = findChromium();
    browser = await puppeteer.launch({
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-gpu",
        "--disable-blink-features=AutomationControlled",
        "--disable-web-security",
        "--disable-features=IsolateOrigins,site-per-process",
        "--lang=id"
      ],
      executablePath
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 720 });
    await page.setUserAgent(randomUA());
    await page.setExtraHTTPHeaders({
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'Accept-Encoding': 'gzip, deflate, br',
      'DNT': '1'
    });

    let response;
    try {
      response = await page.goto(url, { waitUntil: 'networkidle2', timeout: 120000 });
    } catch (e) {
      response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 120000 }).catch(() => null);
    }

    await tryClickChallenge(page);
    await page.waitForFunction(
      () => {
        const bodyText = document.body.innerText || '';
        const hasChallenge = 
          bodyText.includes('Just a moment') ||
          bodyText.includes('Checking your browser') ||
          bodyText.includes('DDoS protection') ||
          bodyText.includes('Melakukan verifikasi keamanan') ||
          bodyText.includes('Situs web menggunakan layanan keamanan') ||
          bodyText.includes('verifikasi') ||
          bodyText.includes('security check') ||
          document.querySelector('#challenge-form') !== null ||
          document.querySelector('.cf-browser-verification') !== null ||
          document.querySelector('.challenge-container') !== null;
        if (hasChallenge) return false;
        return document.body && document.body.innerText.length > 200;
      },
      { timeout: 15000, polling: 1000 }
    ).catch(() => {});

    await sleep(3000);

    const headers = response ? await response.headers() : {};
    const html = await page.content();
    const screenshot = await page.screenshot({ fullPage: false });
    const domain = parseDomain(url);
    const tlsInfo = domain ? await getTLSDetails(domain) : null;

    const [
      waf, cdn, ddosProvider, rateLimit, adaptive, slowloris, captcha, http2,
      websocket, dnsReflection, anycast, load, anomaly, secHeaders, tech,
      fingerprint, openPorts, cors, threat, cookies,
      sql, xss, dirListing, backups, adminPanels, openRedirect,
      emails, internalIp, cspWeak, subTakeover, hstsPreload, sslRating
    ] = await Promise.all([
      fingerprintWAF(headers, html),
      detectCDN(headers, domain),
      detectDDoSProvider(headers, html),
      testRateLimitAggressive(url),
      testAdaptiveRateLimit(url),
      testSlowloris(url),
      detectCaptchaAndChallenge(page),
      testHttp2RapidReset(url),
      testWebSocketProtection(url),
      testDnsReflection(domain),
      detectAnycast(domain),
      testLoadDegradation(url),
      testTrafficAnomaly(url),
      analyzeSecurityHeaders(headers),
      detectTechStack(page, headers, html),
      detectBrowserFingerprint(page),
      scanOpenPorts(domain),
      testCorsAndCsrf(url),
      threatIntel(domain, headers['cf-connecting-ip']),
      analyzeCookies(headers),
      testSqlInjection(url),
      testXssReflected(url),
      checkDirectoryListing(url),
      checkBackupFiles(url),
      checkAdminPanels(url),
      checkOpenRedirect(url),
      Promise.resolve(extractEmails(html)),
      Promise.resolve(checkInternalIpDisclosure(html)),
      Promise.resolve(checkCspWeaknesses(headers)),
      checkSubdomainTakeover(domain),
      Promise.resolve(checkHstsPreload(headers)),
      Promise.resolve(rateSslTls(tlsInfo))
    ]);

    let ddosScore = 0;
    if (ddosProvider[0] !== "𝐓𝐢𝐝𝐚𝐤 𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢") ddosScore += 20;
    if (captcha.jsChallenge) ddosScore += 15;
    if (rateLimit.limited) ddosScore += 10;
    if (adaptive.ipBased) ddosScore += 10;
    if (anomaly.aggressive) ddosScore += 10;
    if (!slowloris.vulnerable) ddosScore += 5;
    if (!load.severe) ddosScore += 10;
    if (secHeaders.present.length >= 5) ddosScore += 10;
    if (!cors.corsVuln) ddosScore += 5;
    if (threat.threatScore < 20) ddosScore += 5;
    const ddosLevel = ddosScore >= 70 ? "𝐓𝐢𝐧𝐠𝐠𝐢" : (ddosScore >= 40 ? "𝐒𝐞𝐝𝐚𝐧𝐠" : "𝐑𝐞𝐧𝐝𝐚𝐡");

    const report = {
      waf: waf.join(", "),
      cdn: cdn.join(", "),
      ddosProvider: ddosProvider.join(", "),
      rateLimit: rateLimit.limited ? `𝐁𝐥𝐨𝐤𝐢𝐫 ${rateLimit.percent}%` : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      adaptiveRate: adaptive.note,
      slowloris: slowloris.note,
      captcha: captcha.captcha ? captcha.captchaType : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      jsChallenge: captcha.jsChallenge ? captcha.challengeType : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      http2RapidReset: http2.note,
      websocketProtection: websocket.note,
      dnsReflection: dnsReflection.note,
      anycast: anycast.anycast ? "𝐘𝐚" : "𝐓𝐢𝐝𝐚𝐤",
      loadDegradation: load.severe ? `𝐁𝐞𝐫𝐚𝐭 (+${load.degradation}%)` : `𝐍𝐨𝐫𝐦𝐚𝐥 (+${load.degradation}%)`,
      trafficAnomaly: anomaly.aggressive ? `𝐓𝐞𝐫𝐝𝐞𝐭𝐞𝐤𝐬𝐢 (${anomaly.blockRate}% 𝐛𝐥𝐨𝐤𝐢𝐫)` : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      securityHeaders: secHeaders,
      techStack: tech,
      browserFingerprinting: fingerprint.fingerprinting ? "𝐘𝐚" : "𝐓𝐢𝐝𝐚𝐤",
      openPorts: openPorts.length ? openPorts.join(", ") : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      cors: cors.corsVuln ? "𝐑𝐞𝐧𝐭𝐚𝐧" : "𝐀𝐦𝐚𝐧",
      csrfToken: cors.csrfToken ? "𝐀𝐝𝐚" : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      threatIntel: threat,
      cookieSecurity: cookies,
      tls: tlsInfo || { version: "𝐓𝐢𝐝𝐚𝐤 𝐭𝐞𝐫𝐬𝐞𝐝𝐢𝐚", cipher: "𝐓𝐢𝐝𝐚𝐤 𝐭𝐞𝐫𝐬𝐞𝐝𝐢𝐚" },
      ddosScore: ddosScore,
      ddosLevel: ddosLevel,
      sqlInjection: sql.note,
      xssReflected: xss.note,
      directoryListing: dirListing.note,
      backupFiles: backups.note,
      adminPanels: adminPanels.note,
      openRedirect: openRedirect.note,
      emailsFound: emails.length ? emails.join(", ") : "𝐓𝐢𝐝𝐚𝐤 𝐀𝐝𝐚",
      internalIpDisclosure: internalIp.note,
      cspWeakness: cspWeak.note,
      subdomainTakeover: subTakeover.note,
      hstsPreload: hstsPreload.note,
      sslRating: sslRating.rating
    };
    return { screenshotBuffer: screenshot, headers, report };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = { takeScreenshot };