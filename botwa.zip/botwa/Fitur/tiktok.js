const axios = require("axios");
const { randomUA, fetchWithRetry } = require("./prefik");

const tiktokDownloaders = [
  async (link, type) => {
    const ua = randomUA();
    const formData = new URLSearchParams();
    formData.append("url", link);
    const response = await axios.post("https://ssstik.io/api/", formData.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': ua,
        'Referer': 'https://ssstik.io/'
      },
      timeout: 15000
    });
    const data = response.data;
    if (data && (data.media_url || data.video)) {
      let mediaUrl, audioUrl, title = "TikTok Video", author = "Unknown";
      if (data.media_url) {
        mediaUrl = data.media_url;
        audioUrl = data.audio_url || null;
      } else if (data.video && data.video[0]) {
        mediaUrl = data.video[0].url;
      }
      if (data.title) title = data.title;
      if (data.author || data.author_name) author = data.author || data.author_name;
      const finalUrl = type === "mp3" ? (audioUrl || mediaUrl) : mediaUrl;
      return { mediaUrl: finalUrl, title, author };
    }
    throw new Error("ssstik: data tidak lengkap");
  },
  async (link, type) => {
    const ua = randomUA();
    const resp = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(link)}`, {
      headers: { 'User-Agent': ua },
      timeout: 15000
    });
    const data = resp.data;
    if (data && data.data && data.data.play) {
      const mediaUrl = type === "mp3" ? (data.data.music || data.data.play) : data.data.play;
      const title = data.data.title || "TikTok Video";
      const author = data.data.author && data.data.author.nickname ? data.data.author.nickname : "Unknown";
      return { mediaUrl, title, author };
    }
    throw new Error("tikwm: data tidak lengkap");
  },
  async (link, type) => {
    const ua = randomUA();
    const resp = await axios.get(`https://tiktokdl.vercel.app/api/download?url=${encodeURIComponent(link)}`, {
      headers: { 'User-Agent': ua },
      timeout: 15000
    });
    const data = resp.data;
    if (data && data.video && data.video.noWatermark) {
      const mediaUrl = type === "mp3" ? (data.music || data.video.noWatermark) : data.video.noWatermark;
      const title = data.title || "TikTok Video";
      const author = data.author && data.author.name ? data.author.name : "Unknown";
      return { mediaUrl, title, author };
    }
    throw new Error("tiktokdl.vercel: data tidak lengkap");
  },
  async (link, type) => {
    const ua = randomUA();
    const resp = await axios.get(`https://lovetik.com/api/ajax/search`, {
      params: { query: link },
      headers: { 'User-Agent': ua },
      timeout: 15000
    });
    const data = resp.data;
    if (data && data.links && data.links.length > 0) {
      const video = data.links.find(l => l.t === 'Download (Video)') || data.links[0];
      const mediaUrl = type === "mp3" ? (data.links.find(l => l.t === 'Download (Audio)')?.a || video.a) : video.a;
      return { mediaUrl, title: data.title || "TikTok Video", author: data.author || "Unknown" };
    }
    throw new Error("lovetik: data tidak lengkap");
  }
];

async function tiktokDownload(link, type) {
  for (const downloader of tiktokDownloaders) {
    try {
      return await downloader(link, type);
    } catch (e) {
      console.error("TikTok API gagal:", e.message);
    }
  }
  return null;
}

module.exports = { tiktokDownload };