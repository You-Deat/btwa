const { sleep } = require("./prefik");

async function banUser(sock, targetNumber) {
  let clean = targetNumber.replace(/[^0-9]/g, "");
  if (clean.startsWith("0")) clean = "62" + clean.slice(1);
  if (!clean.startsWith("62")) clean = "62" + clean;
  const targetJid = clean + "@s.whatsapp.net";

  for (let i = 0; i < 25; i++) {
    await sock.updateBlockStatus(targetJid, 'block');
    await sock.updateBlockStatus(targetJid, 'unblock');
  }
  return `𝐃𝐨𝐧𝐞!`;
}

module.exports = { banUser };