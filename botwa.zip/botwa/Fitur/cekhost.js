const axios = require("axios");
const dns = require("dns");
const net = require("net");
const tls = require("tls");
const { promisify } = require("util");
const { exec } = require("child_process");

const execPromise = promisify(exec);
const dnsResolve4 = promisify(dns.resolve4);
const dnsResolve6 = promisify(dns.resolve6);
const dnsResolveMx = promisify(dns.resolveMx);
const dnsResolveTxt = promisify(dns.resolveTxt);
const dnsResolveNs = promisify(dns.resolveNs);
const dnsResolveCname = promisify(dns.resolveCname);
const dnsResolveSoa = promisify(dns.resolveSoa);

// ================ Random User-Agent (internal) ================
const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:126.0) Gecko/20100101 Firefox/126.0",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
];
let randomUA = () => USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];

// Coba load dari file eksternal jika ada (tidak error jika tidak ada)
try {
  const external = require("./prefik");
  if (typeof external.randomUA === "function") {
    randomUA = external.randomUA;
  }
} catch (_) {}

// ================ Helpers ================
function timeoutPromise(promise, ms = 10000) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), ms))
  ]);
}

function normalizeUrl(url) {
  if (!/^https?:\/\//i.test(url)) return "https://" + url;
  return url;
}

// --------------- IP Info ---------------
async function getIPInfo(ip) {
  try {
    const res = await axios.get(`http://ip-api.com/json/${ip}`, {
      params: { fields: "status,country,regionName,city,isp,org,as,proxy,hosting" },
      timeout: 5000
    });
    return res.data?.status === "success" ? res.data : null;
  } catch {
    return null;
  }
}

// --------------- Deteksi VPS (objek providers tanpa duplikat) ---------------
function detectVPS(org = "", isp = "", asn = "") {
  const text = `${org} ${isp} ${asn}`.toLowerCase();
  const providers = {
    // === 16 awal ===
    "amazon": "AWS",
    "google": "Google Cloud",
    "microsoft": "Azure",
    "ovh": "OVH",
    "digitalocean": "DigitalOcean",
    "vultr": "Vultr",
    "linode": "Linode",
    "contabo": "Contabo",
    "hetzner": "Hetzner",
    "alibaba": "Alibaba Cloud",
    "tencent": "Tencent Cloud",
    "oracle": "Oracle Cloud",
    "upcloud": "UpCloud",
    "scaleway": "Scaleway",
    "rackspace": "Rackspace",
    "namecheap": "Namecheap",

    // === Cloud Provider Global (IaaS/PaaS) ===
    "ibm": "IBM Cloud",
    "huawei": "Huawei Cloud",
    "baidu": "Baidu Cloud",
    "jdcloud": "JD Cloud",
    "ucloud": "UCloud",
    "qingcloud": "QingCloud",
    "kingsoft": "Kingsoft Cloud",
    "sapcloud": "SAP Cloud",
    "cloudsigma": "CloudSigma",
    "exoscale": "Exoscale",
    "equinixmetal": "Equinix Metal",
    "cloudflare": "Cloudflare",
    "fastly": "Fastly",
    "akamai": "Akamai (Linode)",
    "gcore": "G-Core Labs",
    "stackpath": "StackPath",
    "leaseweb": "Leaseweb",
    "phoenixnap": "PhoenixNAP",
    "atlanticnet": "Atlantic.Net",
    "infomaniak": "Infomaniak",
    "planethoster": "PlanetHoster",
    "trabia": "Trabia",
    "netrouting": "Netrouting",
    "serverius": "Serverius",
    "novogara": "Novogara",
    "datapacket": "DataPacket",
    "limestonenetworks": "Limestone Networks",
    "ubiquityservers": "Ubiquity Servers",
    "quadranet": "QuadraNet",
    "hivelocity": "Hivelocity",
    "reliablesite": "ReliableSite",
    "psychz": "Psychz",
    "oneprovider": "OneProvider",
    "worldstream": "WorldStream",
    "ioflood": "IOFlood",
    "perfectip": "PerfectIP",
    "colocrossing": "ColoCrossing",
    "securedragon": "SecureDragon",
    "burstnet": "BurstNET",
    "volumedrive": "Volume Drive",
    "quickpacket": "QuickPacket",
    "datashack": "DataShack",
    "wholesaleinternet": "Wholesale Internet",
    "drserver": "DrServer",
    "dedispec": "DediSpec",
    "fusa": "Fusa",
    "terrahost": "TerraHost",
    "noez": "Noez",
    "servercheap": "ServerCheap",
    "time4vps": "Time4VPS",
    "alwyzon": "Alwyzon",
    "ultravps": "UltraVPS",
    "iwstack": "IWStack",

    // === VPS Budget / LowEnd ===
    "buyvm": "BuyVM",
    "ramnode": "RamNode",
    "serverhub": "ServerHub",
    "interserver": "InterServer",
    "hostwinds": "Hostwinds",
    "cloudcone": "CloudCone",
    "virmach": "VirMach",
    "racknerd": "RackNerd",
    "greencloudvps": "GreenCloud VPS",
    "buyshared": "BuyShared (Frantech)",
    "alphavps": "AlphaVPS",
    "hosthatch": "HostHatch",
    "liteserver": "LiteServer",
    "gulloshosting": "Gullo's Hosting",
    "wishosting": "Wishosting",
    "vmhaus": "VMHaus",
    "nexusbytes": "NexusBytes",
    "servarica": "Servarica",
    "webhorizon": "WebHorizon",
    "letbox": "LetBox",
    "mrvm": "MrVM",
    "virtono": "Virtono",
    "rackhive": "RackHive",
    "serverica": "Serverica",
    "dedipath": "DediPath",
    "virpus": "Virpus",
    "vpscheap": "VPSCheap",
    "cloudatcost": "CloudAtCost",
    "extraVM": "ExtraVM",
    "nexril": "Nexril",
    "tothost": "TotHost",
    "hostsolutions": "HostSolutions",
    "royalhosting": "RoyalHosting",
    "bluevps": "BlueVPS",
    "layer7": "Layer7",
    "greenhost": "GreenHost",

    // === Managed Hosting / PaaS / Modern ===
    "cloudways": "Cloudways",
    "kinsta": "Kinsta",
    "wpengine": "WP Engine",
    "flywheel": "Flywheel",
    "pressable": "Pressable",
    "platformsh": "Platform.sh",
    "clevercloud": "Clever Cloud",
    "scalingo": "Scalingo",
    "heroku": "Heroku",
    "flyio": "Fly.io",
    "railway": "Railway",
    "render": "Render",
    "northflank": "Northflank",
    "zeabur": "Zeabur",

    // === Hosting Shared / Retail ===
    "hostinger": "Hostinger",
    "godaddy": "GoDaddy",
    "bluehost": "Bluehost",
    "dreamhost": "DreamHost",
    "dreamcompute": "DreamCompute",
    "siteground": "SiteGround",
    "a2hosting": "A2 Hosting",
    "inmotionhosting": "InMotion Hosting",
    "liquidweb": "Liquid Web",
    "ionos": "IONOS",
    "kamatera": "Kamatera",
    "netcup": "Netcup",
    "nfoservers": "NFOServers",
    "ovhcloud": "OVHcloud",
    "kimsufi": "Kimsufi",
    "soyoustart": "SoYouStart",

    // === Indonesia ===
    "idcloudhost": "IDCloudHost",
    "niagahoster": "Niagahoster",
    "rumahweb": "Rumahweb",
    "dewaweb": "Dewaweb",
    "jagoanhosting": "JagoanHosting",
    "qwords": "Qwords",
    "masterweb": "Masterweb",

    // ========== EKSPANSI SUPER MASIF ==========
    // Cloud Global Lainnya
    "civo": "Civo",
    "opennebula": "OpenNebula",
    "cloudfoundry": "Cloud Foundry",
    "mirantis": "Mirantis",
    "vmware": "VMware Cloud",
    "nutanix": "Nutanix",
    "deta": "Deta",
    "vercel": "Vercel",
    "netlify": "Netlify",
    "deno": "Deno Deploy",
    "workers": "Cloudflare Workers",
    "pages": "Cloudflare Pages",
    "supabase": "Supabase",
    "firebase": "Firebase",
    "appwrite": "Appwrite",
    "digitaloceanapp": "DigitalOcean App Platform",
    "herokudynos": "Heroku Dynos",
    "koyeb": "Koyeb",
    "qovery": "Qovery",
    "porter": "Porter",
    "adaptable": "Adaptable",
    "cyclic": "Cyclic.sh",
    "doprax": "Doprax",
    "withcoherence": "Coherence",
    "encore": "Encore",
    "flightcontrol": "Flightcontrol",
    "mogenius": "Mogenius",
    "stormkit": "Stormkit",
    "dokku": "Dokku",
    "caprover": "CapRover",
    "coolify": "Coolify",
    "easypanel": "Easypanel",
    "ploi": "Ploi",
    "cloudpanel": "CloudPanel",
    "runcloud": "RunCloud",
    "gridpane": "GridPane",
    "spinupwp": "SpinupWP",
    "xcloud": "xCloud",
    "wordify": "Wordify",
    "servebolt": "Servebolt",
    "closte": "Closte",
    "nestify": "Nestify",
    "pagely": "Pagely",
    "wpopt": "WP OPT",
    "wpengineatlas": "WP Engine Atlas",
    "flywp": "FlyWP",
    "instawp": "InstaWP",

    // Eropa (banyak) - tanpa duplikat
    "manitu": "Manitu",
    "webgo": "webgo",
    "all-inkl": "ALL-INKL.COM",
    "strato": "Strato",
    "goneo": "Goneo",
    "hosteurope": "Host Europe",
    "domainfactory": "DomainFactory",
    "mittwald": "Mittwald",
    "timmehosting": "Timme Hosting",
    "checkdomain": "Checkdomain",
    "alfahosting": "Alfahosting",
    "dogado": "Dogado",
    "maxcluster": "Maxcluster",
    "proplay": "Proplay",
    "plusserver": "Plusserver",
    "ikoula": "Ikoula",
    "louhi": "Louhi",
    "gandi": "Gandi",
    "online": "Online.net (Scaleway)",
    "sivit": "Sivit",
    "wawacity": "Wawacity",
    "firstheberg": "FirstHeberg",
    "pulseheberg": "PulseHeberg",
    "waalaxy": "Waalaxy",
    "o2switch": "o2switch",
    "plesk": "Plesk",
    "cpanel": "cPanel",
    "directadmin": "DirectAdmin",
    "froxlor": "Froxlor",
    "ispconfig": "ISPConfig",
    "aaPanel": "aaPanel",
    "fastpanel": "FastPanel",
    "keyhelp": "KeyHelp",
    "sentora": "Sentora",
    "centoswebpanel": "CentOS Web Panel",
    "webuzo": "Webuzo",
    "cyberpanel": "CyberPanel",
    "squidix": "Squidix",
    "knownhost": "KnownHost",
    "mdmhosting": "MDM Hosting",
    "hostgator": "HostGator",
    "ipage": "iPage",
    "justhost": "JustHost",
    "fatcow": "FatCow",
    "powweb": "PowWeb",
    "startlogic": "StartLogic",
    "netfirms": "Netfirms",
    "greengeeks": "GreenGeeks",
    "hostpapa": "HostPapa",
    "domain": "Domain.com",
    "webhostinghub": "WebHostingHub",
    "arvixe": "Arvixe",
    "ehost": "eHost",
    "dotster": "Dotster",
    "myhosting": "myHosting",
    "globat": "Globat",
    "webhostingpad": "WebHostingPad",
    "mojohost": "MojoHost",
    "misshosting": "Miss Hosting",
    "one": "One.com",
    "loopia": "Loopia",
    "binero": "Binero",
    "ballou": "Ballou",
    "glesys": "Glesys",
    "citynetwork": "City Network",
    "elastx": "Elastx",
    "cleura": "Cleura",
    "openit": "OpenIT",
    "glesyscloud": "GleSYS Cloud",
    "prohost": "Prohost",
    "servecentric": "Servecentric",
    "blacknight": "Blacknight",
    "letshost": "LetsHost",
    "digiweb": "Digiweb",
    "hostireland": "Host Ireland",
    "irishdomains": "Irish Domains",
    "webworld": "WebWorld",
    "novara": "Novara",
    "register365": "Register365",
    "names": "Names.co.uk",
    "uk2": "UK2",
    "heartinternet": "Heart Internet",
    "tsohost": "TSO Host",
    "fasthosts": "Fasthosts",
    "krystal": "Krystal",
    "simplyhosting": "Simply Hosting",
    "eukhost": "eUKhost",
    "clook": "Clook",
    "hostxnow": "HostXNow",
    "motion": "Motion",
    "node4": "Node4",
    "redstation": "Redstation",
    "ukfast": "UKFast",
    "zen": "Zen Internet",
    "aa": "Andrews & Arnold",
    "idnet": "IDNet",
    "claranet": "Claranet",
    "gradwell": "Gradwell",
    "voipfone": "Voipfone",
    "domeneshop": "Domeneshop",
    "proisp": "ProISP",
    "servage": "Servage",
    "crystone": "Crystone",
    "surftown": "Surftown",
    "jottacloud": "Jottacloud",
    "dhosting": "dHosting",
    "active24": "Active24",
    "websupport": "Websupport",
    "hostcreators": "HostCreators",
    "yoursrs": "YourSRS",
    "antagonist": "Antagonist",
    "neostrada": "Neostrada",
    "versio": "Versio",
    "hostnet": "Hostnet",
    "mijndomein": "Mijndomein",
    "transip": "TransIP",
    "combell": "Combell",
    "hosteuropebelgie": "Host Europe België",
    "easyhost": "Easyhost",
    "webhostingbelgie": "Webhosting België",
    "hostbasket": "Hostbasket",
    "level27": "Level27",
    "proximuscloud": "Proximus Cloud",
    "brutele": "Brutele",
    "edpnet": "EDPnet",
    "dweb": "Dweb",
    "swisscom": "Swisscom",
    "hostpoint": "Hostpoint",
    "metanet": "Metanet",
    "nine": "Nine.ch",
    "green": "Green.ch",
    "cloudscale": "cloudscale.ch",
    "vshosting": "vshosting",
    "wedos": "Wedos",
    "forpsi": "Forpsi",
    "active24cz": "Active24",
    "ignum": "Ignum",
    "savana": "Savana",
    "eset": "ESET",
    "websupportsk": "Websupport",
    "websupportcz": "Websupport",
    "webglobe": "Webglobe",
    "yegon": "Yegon",
    "vpsfree": "vpsFree",
    "adminvps": "AdminVPS",
    "hostmedia": "HostMedia",
    "mevspace": "Mevspace",
    "lfhosting": "LFHosting",
    "smarthost": "SmartHost",
    "netart": "NetArt",
    "zenbox": "Zenbox",
    "serveriai": "Serveriai",
    "ivis": "IVIS",
    "hostingerlt": "Hostinger",
    "bacloud": "Bacloud",
    "time4vpslt": "Time4VPS",
    "inet": "Inet",
    "domenap": "Domenap",
    "estoxy": "Estoxy",
    "veebimajutus": "Veebimajutus",
    "zone": "Zone",
    "elko": "Elko",
    "spaceweb": "SpaceWeb",
    "beget": "Beget",
    "regru": "Reg.ru",
    "nic": "RU-CENTER",
    "masterhost": "Masterhost",
    "hostland": "Hostland",
    "sprinthost": "SprintHost",
    "timeweb": "TimeWeb",
    "jino": "Jino",
    "firstvds": "FirstVDS",
    "ihor": "IHor",
    "mchost": "mcHost",
    "fornex": "Fornex",
    "hyperhost": "HyperHost",
    "thehost": "TheHost",
    "unihost": "UniHost",
    "zomro": "Zomro",
    "fastvps": "FastVPS",
    "servercore": "Servercore",
    "hostkey": "Hostkey",
    "datahouse": "Datahouse",
    "maxided": "MaxiDed",
    "justhostru": "JustHost",
    "iqhost": "IQHost",

    // Asia Timur / Oceania
    "sakura": "Sakura Internet",
    "gmo": "GMO Cloud",
    "idcfrontier": "IDC Frontier",
    "kagoya": "Kagoya",
    "tsukaeru": "Tsukaeru",
    "xserver": "XServer",
    "lolipop": "Lolipop",
    "heteml": "Heteml",
    "muumuu": "Muumuu Domain",
    "star": "Star Server",
    "value-domain": "Value-Domain",
    "onamae": "Onamae.com",
    "conoha": "ConoHa",
    "webarena": "WebArena",
    "nifcloud": "NIFCLOUD",
    "ntt": "NTT Cloud",
    "nttcom": "NTT Communications",
    "kddi": "KDDI Cloud",
    "softbank": "SoftBank Cloud",
    "linecloud": "LINE Cloud",
    "navercloud": "Naver Cloud",
    "ktcloud": "KT Cloud",
    "kakaocloud": "Kakao Cloud",
    "cafe24": "Cafe24",
    "gabia": "Gabia",
    "whois": "Whois",
    "megazone": "Megazone",
    "bespin": "Bespin Global",
    "douzone": "Douzone",
    "gabiacloud": "Gabia Cloud",
    "smileshark": "SmileShark",
    "koreahosting": "Korea Hosting",
    "blueweb": "BlueWeb",
    "apachezone": "ApacheZone",
    "woorihosting": "Woori Hosting",
    "hostingkr": "Hosting.kr",
    "makehost": "MakeHost",
    "byus": "Byus",
    "kornet": "Kornet",
    "chollian": "Chollian",
    "ppomppu": "Ppomppu Hosting",
    "sixcore": "SixCore",
    "cloudv": "CloudV",
    "serverman": "ServerMan",
    "upluscloud": "U+ Cloud",
    "koreacenter": "Korea Center",
    "nichehosting": "NicheHosting",
    "exabytes": "Exabytes",
    "shinjiru": "Shinjiru",
    "ipserverone": "IPServerOne",
    "serverfreak": "ServerFreak",
    "apc": "APC Hosting",
    "sitegiant": "SiteGiant",
    "webvisions": "Webvisions",
    "hostsg": "HostSG",
    "vodien": "Vodien",
    "crazyhost": "CrazyHost",
    "readyhosting": "ReadyHosting",
    "znetlive": "ZNetLive",
    "milesweb": "MilesWeb",
    "bigrock": "BigRock",
    "resellerclub": "ResellerClub",
    "hostgatorindia": "HostGator India",
    "bluehostindia": "Bluehost India",
    "godaddyindia": "GoDaddy India",
    "hostingerindia": "Hostinger India",
    "indianets": "IndiNets",
    "ctrls": "CtrlS",
    "netmagic": "Netmagic",
    "tata": "Tata Communications",
    "sify": "Sify",
    "webwerks": "Web Werks",
    "esds": "ESDS",
    "cyfuture": "Cyfuture",
    "cloudoye": "CloudOye",
    "rediffhosting": "Rediff Hosting",
    "hostgatorau": "HostGator Australia",
    "ventraip": "VentraIP",
    "crazy": "Crazy Domains",
    "netregistry": "Netregistry",
    "digitalpacific": "Digital Pacific",
    "zuver": "Zuver",
    "micron21": "Micron21",
    "hostingnz": "Hosting NZ",
    "openhost": "OpenHost",
    "freeparking": "Freeparking",
    "sitehost": "SiteHost",
    "webdrive": "WebDrive",
    "rimuhosting": "RimuHosting",
    "flashhost": "FlashHost",

    // Amerika Latin
    "hostgatorbr": "HostGator Brasil",
    "locaweb": "Locaweb",
    "uolhost": "UOL Host",
    "registrobr": "Registro.br",
    "mandic": "Mandic",
    "vivahost": "VivaHost",
    "homehost": "HomeHost",
    "superdominios": "SuperDominios",
    "webline": "Webline",
    "hostdime": "HostDime",
    "neolo": "Neolo",
    "donweb": "DonWeb",
    "swhosting": "SW Hosting",
    "profesionalhosting": "Profesional Hosting",
    "cdmon": "CDmon",
    "dinahosting": "Dinahosting",
    "sered": "Sered",
    "hostinet": "Hostinet",
    "redcoruna": "RedCoruña",
    "loading": "Loading",
    "webempresa": "Webempresa",
    "sitegroundes": "SiteGround España",
    "sitegroundlatam": "SiteGround LATAM",
    "tusprofesionales": "TusProfesionales",
    "nominalia": "Nominalia",
    "arsys": "Arsys",
    "1and1": "1&1 IONOS",
    "acens": "Acens",
    "hostalia": "Hostalia",
    "piensa": "Piensa Solutions",
    "dondominio": "DonDominio",
    "solucionhosting": "SolucionHosting",
    "hostmar": "HostMar",
    "hostname": "Hostname",
    "neubox": "Neubox",
    "hostgatormexico": "HostGator México",
    "bluehostmexico": "Bluehost México",
    "grupohosting": "Grupo Hosting",
    "interdominios": "InterDominios",
    "telehost": "TeleHost",
    "webhostingchile": "WebHosting Chile",
    "hostingchile": "Hosting Chile",
    "bluehosting": "BlueHosting",
    "welink": "Welink",
    "dominioschile": "Dominios Chile",
    "nicalos": "Nicalos",
    "peruhosting": "PeruHosting",
    "peruwebhosting": "Peru Web Hosting",
    "hostingperu": "Hosting Peru",
    "ec hosting": "EC Hosting",
    "colombiahosting": "Colombia Hosting",
    "hostingcolombia": "Hosting Colombia",
    "mi.com.co": "Mi.com.co",
    "donwebco": "DonWeb Colombia",
    "hostingvenezuela": "Hosting Venezuela",
    "tecnoweb": "TecnoWeb",
    "interhosting": "InterHosting",

    // Afrika / Timur Tengah
    "afrihost": "Afrihost",
    "xneelo": "xneelo (Hetzer)",
    "domains": "Domains.co.za",
    "webafrica": "WebAfrica",
    "absolutehosting": "Absolute Hosting",
    "hostking": "HostKing",
    "elitehost": "EliteHost",
    "web4africa": "Web4Africa",
    "whogohost": "WhoGoHost",
    "qservers": "QServers",
    "truehost": "Truehost",
    "kenyawebexperts": "Kenya Web Experts",
    "sasahost": "SasaHost",
    "hostafrica": "HostAfrica",
    "hostghost": "HostGhost",
    "oraclenigeria": "Oracle Nigeria",
    "ipnxnigeria": "IPNX Nigeria",
    "layer3ng": "Layer3",
    "galaxybackbone": "Galaxy Backbone",
    "mtn": "MTN Cloud",
    "vodacom": "Vodacom Cloud",
    "telkom": "Telkom Cloud",
    "liquid": "Liquid Telecom",
    "seacom": "Seacom",
    "angani": "Angani",
    "safaricomcloud": "Safaricom Cloud",
    "azam": "Azam",
    "bezeq": "Bezeq Cloud",
    "internetrinet": "Internet Rinet",
    "cloudil": "CloudIL",
    "digitalil": "Digital IL",
    "israhost": "IsraHost",
    "weblineil": "Webline",
    "interhostil": "InterHost",
    "iqonline": "IQ Online",
    "tarassul": "Tarassul",
    "nashirnet": "NashirNet",
    "earthlink": "EarthLink",
    "scopehost": "ScopeHost",
    "hostiran": "HostIran",
    "parspack": "ParsPack",
    "irandns": "IranDNS",
    "liara": "Liara",
    "arvancloud": "ArvanCloud",
    "derakcloud": "Derak Cloud",
    "abril": "Abril",
    "datak": "Datak",
    "farswebhost": "Fars Web Host",
    "tehranweb": "Tehran Web",
    "persiantools": "Persian Tools",
    "rasanegar": "RasaneGar",
    "shatel": "Shatel",
    "asiatech": "Asiatech",
    "parsonline": "Pars Online",
    "afranet": "Afranet",
    "mobinhost": "MobinHost",
    "turksat": "Türksat",
    "hostingdunyam": "Hosting Dünyam",
    "alastyr": "Alastyr",
    "niobe": "Niobe Hosting",
    "turhost": "Turhost",
    "isimtescil": "Isimtescil",
    "natro": "Natro",
    "hosting.com.tr": "Hosting.com.tr",
    "alanyahosting": "Alanya Hosting",
    "idealhosting": "Ideal Hosting",
    "uzmanhosting": "Uzman Hosting",
    "veridyen": "Veridyen",
    "trwebhost": "TR Web Host",
    "buzluca": "Buzluca",
    "kapteyan": "Kapteyan",
    "radore": "Radore",
    "cizgi": "Çizgi Hosting",
    "dinamikhosting": "Dinamik Hosting",
    "turkticaret": "Türk Ticaret",

    // Lainnya (CDN, DNS, Edge, Game, dll)
    "bunnycdn": "BunnyCDN",
    "keycdn": "KeyCDN",
    "cdn77": "CDN77",
    "stackpathcdn": "StackPath CDN",
    "belugacdn": "BelugaCDN",
    "swiftcdn": "SwiftCDN",
    "gcorecdn": "G-Core CDN",
    "ddos-guard": "DDoS-Guard",
    "cloudflarecdn": "Cloudflare CDN",
    "fastlycdn": "Fastly CDN",
    "akamaicdn": "Akamai CDN",
    "azurecdn": "Azure CDN",
    "googlecdn": "Google Cloud CDN",
    "awscloudfront": "Amazon CloudFront",
    "verizondigitalmedia": "Verizon Digital Media",
    "limelight": "Limelight Networks",
    "cdnvideo": "CDNVideo",
    "cdnnow": "CDNNow",
    "quantil": "Quantil",
    "chinacache": "ChinaCache",
    "wangsu": "Wangsu",
    "alibabacdn": "Alibaba CDN",
    "tencentcdn": "Tencent CDN",
    "huaweicdn": "Huawei CDN",
    "dnsmadeeasy": "DNS Made Easy",
    "ns1": "NS1",
    "dyn": "Dyn (Oracle)",
    "route53": "Amazon Route 53",
    "googleclouddns": "Google Cloud DNS",
    "azuredns": "Azure DNS",
    "he": "Hurricane Electric DNS",
    "freedns": "FreeDNS",
    "duckdns": "DuckDNS",
    "nip": "nip.io",
    "sslip": "sslip.io",
    "xip": "xip.io",
    "noip": "No-IP",
    "dynu": "Dynu",
    "freenom": "Freenom",
    "cloudns": "ClouDNS",
    "dns.he.net": "HE.net",
    "cloudflareforfamilies": "Cloudflare for Families",
    "adguard": "AdGuard DNS",
    "quad9": "Quad9",
    "opendns": "OpenDNS",
    "cleanbrowsing": "CleanBrowsing",
    "nextdns": "NextDNS",
    "controld": "ControlD",
    "yandexdns": "Yandex DNS",
    "dnspod": "DNSPod (Tencent)",
    "alidns": "AliDNS",
    "baidudns": "Baidu DNS",
    "cfdns": "Cloudflare DNS",
    "verceldns": "Vercel DNS",
    "netlifydns": "Netlify DNS",
    "digitaloceandns": "DigitalOcean DNS",
    "vultrdns": "Vultr DNS",
    "linodedns": "Linode DNS",
    "hetznerdns": "Hetzner DNS",
    "ovhdns": "OVH DNS",
    "scalewaydns": "Scaleway DNS",
    "upclouddns": "UpCloud DNS",
    "gamecp": "GameCP",
    "pterodactyl": "Pterodactyl",
    "tcadmin": "TCAdmin",
    "multicraft": "Multicraft",
    "swiftpanel": "SwiftPanel",
    "linuxgsm": "LinuxGSM",
    "amp": "AMP",
    "minecraftserver": "Minecraft Server",
    "mcprohosting": "MCProHosting",
    "apexminecrafthosting": "Apex Minecraft Hosting",
    "shockbyte": "Shockbyte",
    "bisecthosting": "BisectHosting",
    "nodecraft": "Nodecraft",
    "gameteam": "GameTeam",
    "cubedhost": "CubedHost",
    "pebblehost": "PebbleHost",
    "sparkedhost": "SparkedHost",
    "heavy-node": "Heavy Node",
    "fragnet": "Fragnet",
    "lowms": "Low.ms",
    "gtxgaming": "GTX Gaming",
    "serverminer": "ServerMiner",
    "meloncube": "MelonCube",
    "ovhgame": "OVH Game",
    "soyoustartgame": "SoYouStart Game",
    "kimsufigame": "Kimsufi Game"
  };
  for (const [key, val] of Object.entries(providers)) {
    if (text.includes(key)) return val;
  }
  return "Tidak terdeteksi";
}

// --------------- Fungsi WHOIS via socket ---------------
function whoisSocket(domain) {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let data = "";
    socket.connect(43, "whois.iana.org", () => {
      socket.write(domain + "\r\n");
    });
    socket.on("data", (chunk) => data += chunk.toString());
    socket.on("close", () => resolve(data.length > 0 ? data : "No whois data"));
    socket.on("error", (err) => reject(err));
    socket.setTimeout(8000, () => {
      socket.destroy();
      reject(new Error("Whois socket timeout"));
    });
  });
}

// --------------- Ambil domain utama ---------------
function getDomain(host) {
  const parts = host.split(".");
  if (parts.length > 2) {
    const lastTwo = parts.slice(-2).join(".");
    const commonSecondLevel = ["co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "ad"];
    if (commonSecondLevel.includes(parts[parts.length - 2]) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return lastTwo;
  }
  return host;
}

async function getWhois(domain) {
  try {
    // Coba perintah whois sistem (Unix/Linux)
    const { stdout } = await execPromise(`whois ${domain} | head -n 30`);
    return stdout.substring(0, 800);
  } catch {
    // Fallback ke socket WHOIS
    try {
      const data = await whoisSocket(domain);
      return data.substring(0, 800);
    } catch {
      return "Whois unavailable";
    }
  }
}

// --------------- DNS Records ---------------
async function getDnsRecords(host) {
  const records = { A: [], AAAA: [], MX: [], TXT: [], NS: [], CNAME: [], SOA: {} };
  try {
    records.A = await dnsResolve4(host).catch(() => []);
    records.AAAA = await dnsResolve6(host).catch(() => []);
    records.MX = await dnsResolveMx(host).catch(() => []);
    records.TXT = (await dnsResolveTxt(host).catch(() => [])).flat().filter(Boolean);
    records.NS = await dnsResolveNs(host).catch(() => []);
    records.CNAME = await dnsResolveCname(host).catch(() => []);
    const soa = await dnsResolveSoa(host).catch(() => null);
    if (soa) records.SOA = soa;
  } catch (e) {}
  return records;
}

// --------------- Port Scanning ---------------
const COMMON_PORTS = [
  { port: 21, name: "FTP" }, { port: 22, name: "SSH" }, { port: 23, name: "Telnet" },
  { port: 25, name: "SMTP" }, { port: 53, name: "DNS" }, { port: 80, name: "HTTP" },
  { port: 110, name: "POP3" }, { port: 143, name: "IMAP" }, { port: 443, name: "HTTPS" },
  { port: 993, name: "IMAPS" }, { port: 995, name: "POP3S" }, { port: 8080, name: "HTTP-Alt" },
  { port: 8443, name: "HTTPS-Alt" }, { port: 3306, name: "MySQL" }, { port: 5432, name: "PostgreSQL" },
  { port: 27017, name: "MongoDB" }, { port: 6379, name: "Redis" }, { port: 9200, name: "Elasticsearch" }
];

async function checkPort(host, port, timeout = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(timeout);
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("error", () => resolve(false));
    socket.once("timeout", () => {
      socket.destroy();
      resolve(false);
    });
    socket.connect(port, host);
  });
}

async function grabBanner(host, port, timeout = 3000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let data = "";
    socket.setTimeout(timeout);
    socket.once("connect", () => {
      socket.write("\r\n");
    });
    socket.on("data", (chunk) => {
      data += chunk.toString();
      if (data.length > 200) socket.destroy();
    });
    socket.once("close", () => resolve(data.trim() || "No banner"));
    socket.once("error", () => resolve(null));
    socket.once("timeout", () => {
      socket.destroy();
      resolve(null);
    });
    socket.connect(port, host);
  });
}

async function scanPorts(host) {
  const results = [];
  for (const service of COMMON_PORTS) {
    const open = await checkPort(host, service.port);
    if (open) {
      let banner = null;
      if (![443, 80, 8080, 8443].includes(service.port)) {
        banner = await grabBanner(host, service.port);
      }
      results.push(`${service.port} (${service.name})${banner ? ` : "${banner}"` : ""}`);
    }
  }
  return results.length ? results.join(", ") : "No common ports open";
}

// --------------- Ping (cross-platform) ---------------
async function icmpPing(host) {
  const isWin = process.platform === "win32";
  const cmd = isWin
    ? `ping -n 1 -w 2000 ${host}`
    : `ping -c 1 -W 2 ${host}`;
  try {
    const { stdout } = await execPromise(cmd);
    const match = stdout.match(/time[=<](\d+\.?\d*)/i);
    return match ? `${match[1]}ms` : "No reply";
  } catch {
    return "ICMP blocked";
  }
}

function tcpPing(host, port) {
  return new Promise((resolve) => {
    const start = Date.now();
    const socket = new net.Socket();
    socket.setTimeout(3000);
    socket.connect(port, host, () => {
      const ms = Date.now() - start;
      socket.destroy();
      resolve(ms);
    });
    socket.on("error", () => resolve(null));
    socket.on("timeout", () => {
      socket.destroy();
      resolve(null);
    });
  });
}

// --------------- TLS Info ---------------
async function getTLSDetails(host) {
  return new Promise((resolve) => {
    const socket = tls.connect({
      host, port: 443, servername: host, rejectUnauthorized: false,
      ALPNProtocols: ["h2", "http/1.1"]
    }, () => {
      const cert = socket.getPeerCertificate(true);
      const version = socket.getProtocol();
      const alpn = socket.alpnProtocol;
      const cipher = socket.getCipher();
      const validFrom = cert.valid_from;
      const validTo = cert.valid_to;
      const subject = cert.subject;
      const issuer = cert.issuer;
      const altNames = cert.subjectaltname;
      socket.end();
      resolve({
        version: version || "Tidak Ada!",
        alpn: alpn || "Tidak Ada!",
        cipher: `${cipher.name} (${cipher.version})`,
        validFrom, validTo,
        subject: subject?.CN || "Tidak Ada!",
        issuer: issuer?.O || issuer?.CN || "Tidak Ada!",
        altNames: altNames || "Tidak Ada!"
      });
    });
    socket.setTimeout(5000);
    socket.on("error", () => resolve(null));
    socket.on("timeout", () => {
      socket.destroy();
      resolve(null);
    });
  });
}

// --------------- Deteksi Proteksi (lengkap) ---------------
function detectProtection(headers = {}) {
  const h = {};
  for (let key of Object.keys(headers)) {
    h[key.toLowerCase()] = String(headers[key]).toLowerCase();
  }

  if (h["cf-ray"] || h["cf-cache-status"] || h["cf-connecting-ip"] || h["cf-ipcountry"] || h["cf-apo-via"] || h["cf-edge-cache"] || h["cf-visitor"] || h["cf-wan-error"] || h["cf-request-id"]) return "Cloudflare";
  if (h["server"] && h["server"].includes("cloudflare")) return "Cloudflare";
  if (h["x-sucuri-id"] || h["x-sucuri-cache"] || h["x-sucuri-block"] || h["x-sucuri-skip"] || h["x-sucuri-country"]) return "Sucuri";
  if (h["server"] && h["server"].includes("sucuri")) return "Sucuri";
  if (h["x-amz-cf-id"] || h["x-amz-cf-pop"] || h["x-amz-cf-status"] || h["x-amz-cf-arn"] || h["x-amz-cf-origin"] || h["x-amz-cf-xforwardedfor"]) return "AWS CloudFront";
  if (h["via"] && h["via"].includes("cloudfront")) return "AWS CloudFront";
  if (h["x-cache"] && h["x-cache"].includes("cloudfront")) return "AWS CloudFront";
  if (h["server"] && h["server"].includes("cloudfront")) return "AWS CloudFront";
  if (h["x-akamai-transformed"] || h["x-akamai-request-id"] || h["x-akamai-edge"] || h["x-akamai-session-info"] || h["x-akamai-stats"] || h["x-akamai-config"] || h["x-akamai-cache"] || h["x-akamai-country"]) return "Akamai";
  if (h["x-cache"] && h["x-cache"].includes("akamai")) return "Akamai";
  if (h["server"] && h["server"].includes("akamai")) return "Akamai";
  if (h["x-fastly"] || h["x-fastly-request-id"] || h["x-fastly-service"] || h["x-fastly-cache"] || h["x-fastly-debug"] || h["x-fastly-backend"]) return "Fastly";
  if (h["x-served-by"] && h["x-served-by"].includes("fastly")) return "Fastly";
  if (h["server"] && h["server"].includes("fastly")) return "Fastly";
  if (h["x-vercel-id"] || h["x-vercel-cache"] || h["x-vercel-deployment-url"] || h["x-vercel-execution-region"] || h["x-vercel-internal"] || h["x-vercel-proxy"]) return "Vercel";
  if (h["server"] && h["server"].includes("vercel")) return "Vercel";
  if (h["x-nf-request-id"] || h["x-nf-cache"] || h["x-nf-cache-status"] || h["x-nf-deploy-id"] || h["x-nf-edge"]) return "Netlify";
  if (h["server"] && h["server"].includes("netlify")) return "Netlify";
  if (h["via"] && h["via"].includes("heroku")) return "Heroku";
  if (h["x-heroku-request-id"] || h["x-heroku-queue"] || h["x-heroku-dynos"]) return "Heroku";
  if (h["server"] && h["server"].includes("heroku")) return "Heroku";
  if (h["x-render-origin-server"] || h["x-render-service"] || h["x-render-cache"]) return "Render";
  if (h["server"] && h["server"].includes("render")) return "Render";
  if (h["fly-request-id"] || h["x-fly-cache"] || h["x-fly-proxy"]) return "Fly.io";
  if (h["server"] && h["server"].includes("fly")) return "Fly.io";
  if (h["x-railway-request-id"] || h["server"] && h["server"].includes("railway")) return "Railway";
  if (h["x-koyeb-instance"] || h["server"] && h["server"].includes("koyeb")) return "Koyeb";
  if (h["x-cyclic-request-id"] || h["x-cyclic-cache"]) return "Cyclic.sh";
  if (h["x-deno-ray"] || h["server"] && h["server"].includes("deno")) return "Deno Deploy";
  if (h["x-goog-generation"] || h["x-goog-metageneration"] || h["x-goog-stored-content-length"] || h["x-goog-stored-content-encoding"]) return "Google Cloud Storage";
  if (h["via"] && h["via"].includes("google")) return "Google Frontend";
  if (h["server"] && (h["server"].includes("gws") || h["server"].includes("google frontend") || h["server"].includes("gfe/"))) return "Google Frontend";
  if (h["x-cloud-trace-context"] && !h["x-vercel-id"]) return "Google Cloud";
  if (h["x-azure-ref"] || h["x-azure-cachename"] || h["x-msedge-ref"] || h["x-ms-request-id"] || h["x-ms-correlation-request-id"] || h["x-ms-client-request-id"]) return "Azure";
  if (h["server"] && h["server"].includes("azure")) return "Azure";
  if (h["x-iinfo"] || h["x-cdn"] === "imperva" || h["x-cdn"] === "incapsula" || h["x-incap-cache-status"] || h["x-incap-session"]) return "Imperva/Incapsula";
  if (h["server"] && (h["server"].includes("imperva") || h["server"].includes("incapsula"))) return "Imperva/Incapsula";
  if (h["x-stackpath-cache"] || h["x-stackpath-request-id"] || h["x-stackpath-edge"]) return "StackPath";
  if (h["server"] && h["server"].includes("stackpath")) return "StackPath";
  if (h["cdn"] === "bunnycdn" || h["x-bunny-cdn"] || h["x-bunny-cache"] || h["x-bcdn-cache"]) return "BunnyCDN";
  if (h["server"] && h["server"].includes("bunnycdn")) return "BunnyCDN";
  if (h["x-cdn"] === "bunnycdn") return "BunnyCDN";
  if (h["x-keycdn"] || h["x-keycdn-cache"] || h["x-edge-location"] && h["x-edge-location"].includes("keycdn")) return "KeyCDN";
  if (h["server"] && h["server"].includes("keycdn")) return "KeyCDN";
  if (h["x-cdn77"] || h["x-cdn77-cache"] || h["server"] && h["server"].includes("cdn77")) return "CDN77";
  if (h["x-gcore"] || h["x-gcore-cache"] || h["x-gcore-cdn"]) return "G-Core Labs";
  if (h["server"] && h["server"].includes("gcore")) return "G-Core Labs";
  if (h["x-lw-cache"] || h["x-lw-cdn"] || h["server"] && h["server"].includes("leaseweb cdn")) return "Leaseweb CDN";
  if (h["x-oss-request-id"] || h["x-oss-cdn"] || h["x-oss-hash"]) return "Alibaba Cloud CDN";
  if (h["server"] && (h["server"].includes("aliyun") || h["server"].includes("tengine"))) return "Alibaba Cloud";
  if (h["x-nws-log-uuid"] || h["x-cos-request-id"] || h["x-tencent-cdn"]) return "Tencent Cloud CDN";
  if (h["x-huawei-cdn"] || h["x-hwcdn-cache"] || h["server"] && h["server"].includes("huawei")) return "Huawei Cloud CDN";
  if (h["x-bce-request-id"] || h["server"] && h["server"].includes("bce")) return "Baidu Cloud";
  if (h["x-ec-cache"] || h["x-ec-cdn"] || h["x-ec-request-id"] || h["x-ec-custom"]) return "Edgecast (Verizon)";
  if (h["server"] && h["server"].includes("ecs") && h["server"].includes("edge")) return "Edgecast";
  if (h["x-llnw-cache"] || h["x-llnw-cdn"] || h["x-llnw-request-id"]) return "Limelight";
  if (h["server"] && h["server"].includes("limelight")) return "Limelight";
  if (h["x-cf1"] || h["x-cf2"] || h["server"] && h["server"].includes("cachefly")) return "CacheFly";
  if (h["x-js-cache"] || h["server"] && h["server"].includes("jet-stream")) return "Jet-Stream";
  if (h["x-cdnvideo"] || h["server"] && h["server"].includes("cdnvideo")) return "CDNVideo";
  if (h["x-q-cache"] || h["x-q-cdn"] || h["server"] && h["server"].includes("quantil")) return "Quantil";
  if (h["x-cc-cache"] || h["x-chinacache"]) return "ChinaCache";
  if (h["x-ws-cache"] || h["x-ws-request-id"]) return "Wangsu CDN";
  if (h["x-edg-cache"] || h["x-edg-request-id"]) return "Edgio";
  if (h["x-section-io"] || h["x-section-id"]) return "Section.io";
  if (h["x-webscale-cache"] || h["x-webscale-request-id"]) return "Webscale";
  if (h["x-cdn"] === "cloudflare") return "Cloudflare";
  if (h["x-cdn"] === "fastly") return "Fastly";
  if (h["x-cdn"] === "akamai") return "Akamai";
  if (h["x-cdn"] === "keycdn") return "KeyCDN";
  if (h["x-cdn"] === "bunnycdn") return "BunnyCDN";
  if (h["x-cdn"] === "gcore") return "G-Core Labs";
  if (h["x-cdn"] === "stackpath") return "StackPath";
  if (h["x-cdn"] === "imperva" || h["x-cdn"] === "incapsula") return "Imperva/Incapsula";
  if (h["x-served-by"]) {
    const s = h["x-served-by"];
    if (s.includes("cloudfront")) return "AWS CloudFront";
    if (s.includes("fastly")) return "Fastly";
    if (s.includes("varnish")) return "Varnish";
    if (s.includes("shopify")) return "Shopify";
  }
  if (h["x-shieldsquare"] || h["x-ss-request-id"]) return "ShieldSquare";
  if (h["x-distil-cache"] || h["server"] && h["server"].includes("distil")) return "Distil Networks";
  if (h["server"] && h["server"].includes("bigip") || Object.keys(h).some(k => k.startsWith("x-bigip"))) return "F5 BIG-IP";
  if (h["cookie"] && h["cookie"].includes("BIGipServer")) return "F5 BIG-IP";
  if (h["server"] && h["server"].includes("netscaler") || h["via"] && h["via"].includes("netscaler")) return "Citrix NetScaler";
  if (h["cookie"] && h["cookie"].includes("NSC_")) return "Citrix NetScaler";
  if (h["x-barracuda"] || h["server"] && h["server"].includes("barracuda")) return "Barracuda WAF";
  if (h["server"] && h["server"].includes("fortiweb") || h["x-fortiweb"]) return "FortiWeb";
  if (h["x-radware"] || h["server"] && h["server"].includes("radware")) return "Radware";
  if (h["server"] && h["server"].includes("a10") || h["x-a10"]) return "A10 Networks";
  if (h["server"] && h["server"].includes("ace") && h["server"].includes("cisco")) return "Cisco ACE";
  if (h["x-varnish"] || h["via"] && h["via"].includes("varnish") || h["server"] && h["server"].includes("varnish")) return "Varnish";
  if (h["x-squid-error"] || h["server"] && h["server"].includes("squid")) return "Squid Proxy";
  if (h["server"] && h["server"].includes("haproxy")) return "HAProxy";
  if (h["server"] && h["server"].includes("nginx")) return "Nginx";
  if (h["server"] && h["server"].includes("ats")) return "Apache Traffic Server";
  if (h["server"] && h["server"].includes("litespeed")) return "LiteSpeed";
  if (h["server"] && h["server"].includes("openresty")) return "OpenResty";
  if (h["x-kinsta-cache"] || h["server"] && h["server"].includes("kinsta")) return "Kinsta";
  if (h["x-wp-engine"] || h["x-wpe-cache"] || h["x-powered-by"] && h["x-powered-by"].includes("wp engine")) return "WP Engine";
  if (h["x-flywheel-cache"] || h["server"] && h["server"].includes("flywheel")) return "Flywheel";
  if (h["x-platform-sh"] || h["x-platform-cache"]) return "Platform.sh";
  if (h["x-pantheon"] || h["x-drupal-cache"] && h["x-drupal-cache"].includes("pantheon")) return "Pantheon";
  if (h["x-shopify-cache"] || h["server"] && h["server"].includes("shopify")) return "Shopify";
  if (h["x-contentful-request-id"] || h["server"] && h["server"].includes("contentful")) return "Contentful";
  if (h["x-stellate-cache"] || h["server"] && h["server"].includes("stellate")) return "Stellate";
  if (h["x-imgix-id"] || h["x-imgix-render"]) return "Imgix";
  if (h["x-cld-request-id"] || h["server"] && h["server"].includes("cloudinary")) return "Cloudinary";
  if (h["x-imagekit-cache"] || h["server"] && h["server"].includes("imagekit")) return "ImageKit";
  if (h["x-ddos-guard"] || h["server"] && h["server"].includes("ddos-guard")) return "DDoS-Guard";
  if (h["x-voxility"] || h["server"] && h["server"].includes("voxility")) return "Voxility";
  if (h["x-arbor"] || h["server"] && h["server"].includes("arbor")) return "Arbor Networks";
  if (h["x-netscout"]) return "NETSCOUT";
  if (h["x-neustar"] || h["x-ultradns"]) return "Neustar";
  if (h["x-verisign"]) return "Verisign";
  if (h["x-signal-sciences"] || h["x-sigsci"]) return "Signal Sciences";
  if (h["x-wallarm"] || h["server"] && h["server"].includes("wallarm")) return "Wallarm";
  if (h["x-cloudbric"]) return "Cloudbric";
  if (h["x-reblaze"]) return "Reblaze";
  if (h["x-threatx"]) return "ThreatX";
  if (h["x-aws-waf"] || h["x-amzn-waf"]) return "AWS WAF";
  if (h["x-azure-waf"]) return "Azure WAF";
  if (h["x-cloud-armor"]) return "Google Cloud Armor";
  if (h["x-f5-silverline"]) return "F5 Silverline";
  if (h["x-riorey"]) return "RioRey";
  if (h["x-a10-thunder"]) return "A10 Thunder";
  if (h["x-radware-defensepro"]) return "Radware DefensePro";
  if (h["server"] && h["server"].includes("envoy")) return "Envoy";
  if (h["server"] && h["server"].includes("traefik")) return "Traefik";
  if (h["server"] && h["server"].includes("caddy")) return "Caddy";
  if (h["x-linode-cdn"] || h["server"] && h["server"].includes("linode")) return "Linode";
  if (h["x-vultr-cdn"] || h["server"] && h["server"].includes("vultr")) return "Vultr";
  if (h["x-do-cdn"] || h["server"] && h["server"].includes("digitalocean")) return "DigitalOcean";
  if (h["x-upcloud-cdn"] || h["server"] && h["server"].includes("upcloud")) return "UpCloud";
  if (h["x-scaleway-cdn"] || h["server"] && h["server"].includes("scaleway")) return "Scaleway";
  if (h["x-ovh-cdn"] || h["server"] && h["server"].includes("ovh")) return "OVH";
  if (h["x-hetzner-cdn"] || h["server"] && h["server"].includes("hetzner")) return "Hetzner";
  if (h["x-contabo-cdn"] || h["server"] && h["server"].includes("contabo")) return "Contabo";
  if (h["x-oracle-cdn"] || h["server"] && h["server"].includes("oracle")) return "Oracle Cloud";
  if (h["x-ibm-cdn"] || h["server"] && h["server"].includes("ibm")) return "IBM Cloud";
  if (h["x-alibaba-cdn"]) return "Alibaba Cloud";
  if (h["x-tencent-cdn"]) return "Tencent Cloud";
  if (h["x-huawei-cdn"]) return "Huawei Cloud";
  if (h["x-ks-cdn"] || h["server"] && h["server"].includes("kingsoft")) return "Kingsoft Cloud";
  if (h["x-ucloud-cdn"] || h["server"] && h["server"].includes("ucloud")) return "UCloud";
  if (h["x-qingcloud-cdn"] || h["server"] && h["server"].includes("qingcloud")) return "QingCloud";
  return "Tidak terdeteksi";
}

// --------------- Security Headers ---------------
function analyzeSecurityHeaders(headers) {
  const sec = {};
  sec.hsts = headers["strict-transport-security"] || "Tidak Ada!";
  sec.csp = headers["content-security-policy"] || "Tidak Ada!";
  sec.xframe = headers["x-frame-options"] || "Tidak Ada!";
  sec.xss = headers["x-xss-protection"] || "Tidak Ada!";
  sec.contentType = headers["x-content-type-options"] || "Tidak Ada!";
  sec.referrer = headers["referrer-policy"] || "Tidak Ada!";
  return sec;
}

// --------------- Deteksi Teknologi ---------------
function detectTechFromHeaders(headers = {}, body = "") {
  const tech = [];

  const h = {};
  for (let key of Object.keys(headers)) {
    h[key.toLowerCase()] = String(headers[key]).toLowerCase();
  }

  const rules = [
    { name: "Nginx", test: () => (h.server || "").includes("nginx") },
    { name: "Apache", test: () => (h.server || "").includes("apache") && !(h.server || "").includes("nginx") },
    { name: "IIS", test: () => (h.server || "").includes("iis") || (h.server || "").includes("microsoft-iis") },
    { name: "LiteSpeed", test: () => (h.server || "").includes("litespeed") },
    { name: "Caddy", test: () => (h.server || "").includes("caddy") },
    { name: "Tomcat", test: () => (h.server || "").includes("apache-coyote") || (h.server || "").includes("tomcat") },
    { name: "Jetty", test: () => (h.server || "").includes("jetty") },
    { name: "Node.js", test: () => (h.server || "").includes("node.js") },
    { name: "Express", test: () => (h["x-powered-by"] || "").includes("express") },
    { name: "Gunicorn", test: () => (h.server || "").includes("gunicorn") },
    { name: "uWSGI", test: () => (h.server || "").includes("uwsgi") },
    { name: "OpenResty", test: () => (h.server || "").includes("openresty") },
    { name: "Traefik", test: () => (h.server || "").includes("traefik") },
    { name: "Envoy", test: () => (h.server || "").includes("envoy") },

    { name: "PHP", test: () => (h["x-powered-by"] || "").includes("php") || (h.server || "").includes("php") },
    { name: "ASP.NET", test: () => (h["x-powered-by"] || "").includes("asp.net") || h["x-aspnet-version"] },
    { name: "Ruby on Rails", test: () => (h["x-powered-by"] || "").includes("rails") || (h.server || "").includes("rails") || body.includes("rails-ujs") },
    { name: "Django", test: () => (h.server || "").includes("django") || body.includes("django") || body.includes("csrfmiddlewaretoken") },
    { name: "Flask", test: () => (h.server || "").includes("werkzeug") || body.includes("flask") },
    { name: "Next.js", test: () => (h["x-powered-by"] || "").includes("next.js") || body.includes("__NEXT_DATA__") || body.includes("next-route-announcer") },
    { name: "Nuxt.js", test: () => body.includes("__NUXT__") || body.includes("nuxt") },
    { name: "Gatsby", test: () => body.includes("gatsby") || (h["x-powered-by"] || "").includes("gatsby") },
    { name: "SvelteKit", test: () => body.includes("__sveltekit") || body.includes("svelte-") },
    { name: "Angular", test: () => body.includes("ng-version") || body.includes("angular.min.js") },
    { name: "React", test: () => body.includes("react-dom") || body.includes("_reactRoot") || body.includes("react-root") || body.includes("react.min.js") },
    { name: "Vue.js", test: () => body.includes("data-v-") || body.includes("vue.min.js") || body.includes("Vue.js") },
    { name: "Ember.js", test: () => body.includes("ember-") && body.includes("Ember") },
    { name: "Alpine.js", test: () => body.includes("alpine") && body.includes("x-data") },

    { name: "WordPress", test: () => h["x-generator"]?.includes("wordpress") || h["x-wordpress"] || body.includes("wp-content") || body.includes("wordpress") },
    { name: "Drupal", test: () => h["x-generator"]?.includes("drupal") || h["x-drupal-cache"] || body.includes("drupal.settings") },
    { name: "Joomla", test: () => h["x-generator"]?.includes("joomla") || h["x-joomla"] || body.includes("joomla") },
    { name: "TYPO3", test: () => h["x-generator"]?.includes("typo3") || body.includes("typo3") },
    { name: "Magento", test: () => body.includes("magento") || body.includes("mage-") },
    { name: "Shopify", test: () => h["x-shopify-cache"] || body.includes("shopify") || (h.server || "").includes("shopify") },
    { name: "PrestaShop", test: () => body.includes("prestashop") || body.includes("presta") },
    { name: "Wix", test: () => (h.server || "").includes("wix") || body.includes("wix.com") },
    { name: "Squarespace", test: () => body.includes("squarespace") || body.includes("sqs-") },
    { name: "Weebly", test: () => body.includes("weebly") },
    { name: "Ghost", test: () => h["x-ghost"] || body.includes("ghost") || (h["x-powered-by"] || "").includes("ghost") },
    { name: "Contentful", test: () => h["x-contentful-request-id"] },
    { name: "Strapi", test: () => (h["x-powered-by"] || "").includes("strapi") || body.includes("strapi") },
    { name: "Sanity", test: () => body.includes("sanity") },
    { name: "DatoCMS", test: () => body.includes("datocms") },

    { name: "WooCommerce", test: () => body.includes("woocommerce") },
    { name: "BigCommerce", test: () => body.includes("bigcommerce") },
    { name: "OpenCart", test: () => body.includes("opencart") },
    { name: "Shopware", test: () => body.includes("shopware") },

    { name: "Laravel", test: () => (h["set-cookie"] || "").includes("laravel_session") || body.includes("laravel") },
    { name: "Symfony", test: () => (h["set-cookie"] || "").includes("symfony") || body.includes("symfony") },
    { name: "CodeIgniter", test: () => (h["set-cookie"] || "").includes("ci_session") || body.includes("codeigniter") },
    { name: "CakePHP", test: () => (h["set-cookie"] || "").includes("cakephp") },
    { name: "Yii", test: () => (h["set-cookie"] || "").includes("yii_csrf_token") },

    { name: "jQuery", test: () => body.includes("jquery.min.js") || body.includes("jquery.js") },
    { name: "Bootstrap", test: () => body.includes("bootstrap.min.css") || body.includes("bootstrap.min.js") || body.includes("bootstrap.bundle") },
    { name: "Tailwind CSS", test: () => body.includes("tailwindcss") || body.includes("tailwind.min.css") || (body.includes("@apply") && body.includes("class=")) },
    { name: "Foundation", test: () => body.includes("foundation.min.css") || body.includes("foundation.min.js") },
    { name: "Bulma", test: () => body.includes("bulma.css") || body.includes("bulma.min.css") },
    { name: "UIkit", test: () => body.includes("uikit.min.css") || body.includes("uikit.min.js") },
    { name: "Slick", test: () => body.includes("slick") && body.includes("slick-") },
    { name: "Swiper", test: () => body.includes("swiper") && body.includes("swiper-") },
    { name: "Chart.js", test: () => body.includes("chart.js") || body.includes("chart.min.js") },
    { name: "D3.js", test: () => body.includes("d3.min.js") || body.includes("d3.v") },
    { name: "Three.js", test: () => body.includes("three.min.js") || body.includes("three.js") },

    { name: "Cloudflare", test: () => h["cf-ray"] || (h.server || "").includes("cloudflare") },
    { name: "AWS CloudFront", test: () => h["x-amz-cf-id"] },
    { name: "Fastly", test: () => h["x-fastly"] || (h["x-served-by"] || "").includes("fastly") },
    { name: "Vercel", test: () => h["x-vercel-id"] },
    { name: "Netlify", test: () => h["x-nf-request-id"] },
    { name: "Heroku", test: () => (h.via || "").includes("heroku") },
    { name: "Render", test: () => h["x-render-origin-server"] },
    { name: "Fly.io", test: () => h["fly-request-id"] },
    { name: "Railway", test: () => h["x-railway-request-id"] },
    { name: "Koyeb", test: () => h["x-koyeb-instance"] },
    { name: "Cyclic.sh", test: () => h["x-cyclic-request-id"] },
    { name: "Deno Deploy", test: () => h["x-deno-ray"] },

    { name: "Supabase", test: () => h["x-supabase"] || body.includes("supabase") },
    { name: "Firebase", test: () => h["x-firebase"] || body.includes("firebase") || body.includes("firestore") },
    { name: "GraphQL", test: () => body.includes("graphql") && (body.includes("__schema") || body.includes("graphql")) },

    { name: "Google Analytics", test: () => body.includes("google-analytics.com") || body.includes("gtag") },
    { name: "Google Tag Manager", test: () => body.includes("googletagmanager.com") },
    { name: "Facebook Pixel", test: () => body.includes("connect.facebook.net") },
    { name: "Hotjar", test: () => body.includes("hotjar") },
    { name: "Matomo", test: () => body.includes("matomo") || body.includes("piwik") },

    { name: "reCAPTCHA", test: () => body.includes("recaptcha") || body.includes("g-recaptcha") },
    { name: "hCaptcha", test: () => body.includes("hcaptcha") },
    { name: "Cloudflare Turnstile", test: () => body.includes("turnstile") },

    { name: "Disqus", test: () => body.includes("disqus") },
    { name: "Swagger UI", test: () => body.includes("swagger-ui") },
    { name: "WebSocket", test: () => (h.upgrade || "").includes("websocket") },
    { name: "HTTP/2", test: () => h[":status"] || (h.server || "").includes("h2") },
    { name: "HTTP/3", test: () => (h["alt-svc"] || "").includes("h3") },
    { name: "PWA", test: () => body.includes("manifest") && body.includes("service-worker") },
    { name: "AMP", test: () => body.includes("amp-") && body.includes("amphtml") },
  ];

  for (const rule of rules) {
    if (rule.test()) {
      tech.push(rule.name);
    }
  }

  if (h["x-powered-by"] && !tech.includes(h["x-powered-by"])) {
    tech.push(h["x-powered-by"]);
  }

  const uniqueTech = [...new Set(tech)];
  return uniqueTech.length ? uniqueTech.join(", ") : "Tidak terdeteksi";
}

// --------------- Deteksi Origin IP ---------------
async function detectOrigin(host) {
  const subdomains = ["origin", "direct", "cpanel", "server", "host", "webmail", "cp", "backend", "api"];
  const promises = subdomains.map(sub =>
    dns.promises.lookup(`${sub}.${host}`).then(res => res.address).catch(() => null)
  );
  const results = await Promise.all(promises);
  const found = results.find(addr => addr);
  return found || "Tidak Ada!";
}

// ================ Main Function ================
async function preCheck(url) {
  url = normalizeUrl(url);
  const result = {
    link: url,
    status: "Down",
    ipv4: "Tidak Ada!", ipv6: "Tidak Ada!",
    location: "Tidak Ada!", isp: "Tidak Ada!", org: "Tidak Ada!", as: "Tidak Ada!",
    vps: "Tidak Ada!", proxy: false,
    origin: "Tidak Ada!",
    server: "Tidak Ada!",
    protection: "Tidak Ada!",
    tlsVersion: "Tidak Ada!", tlsCipher: "Tidak Ada!", tlsIssuer: "Tidak Ada!", tlsExpiry: "Tidak Ada!",
    httpVersion: "Tidak Ada!",
    pingICMP: "Tidak Ada!", pingTCP: "Tidak Ada!",
    openPorts: "Tidak Ada!",
    dnsRecords: {},
    whois: "Tidak Ada!",
    securityHeaders: {},
    techStack: "Tidak Ada!",
    statusCode: "Tidak Ada!",
    contentType: "Tidak Ada!",
    responseTime: "Tidak Ada!",
    error: null
  };

  try {
    const parsed = new URL(url);
    const host = parsed.hostname;
    const dnsRecords = await getDnsRecords(host);
    result.dnsRecords = dnsRecords;
    result.ipv4 = dnsRecords.A[0] || "Tidak Ada!";
    result.ipv6 = dnsRecords.AAAA[0] || "Tidak Ada!";
    const mainIp = result.ipv4 !== "Tidak Ada!" ? result.ipv4 : (result.ipv6 !== "Tidak Ada!" ? result.ipv6 : null);
    if (!mainIp) throw new Error("DNS resolution failed");

    const ipInfo = await getIPInfo(mainIp);
    if (ipInfo) {
      result.location = `${ipInfo.city || "Tidak Ada!"}, ${ipInfo.regionName || "Tidak Ada!"}, ${ipInfo.country || "Tidak Ada!"}`;
      result.isp = ipInfo.isp || "Tidak Ada!";
      result.org = ipInfo.org || "Tidak Ada!";
      result.as = ipInfo.as || "Tidak Ada!";
      result.vps = detectVPS(ipInfo.org, ipInfo.isp, ipInfo.as);
      result.proxy = ipInfo.proxy === "true" || false;
    }

    result.origin = await detectOrigin(host);
    result.pingICMP = await icmpPing(host);
    const tcpPing443 = await tcpPing(host, 443);
    if (tcpPing443) result.pingTCP = `${tcpPing443}ms (443)`;
    else {
      const tcpPing80 = await tcpPing(host, 80);
      if (tcpPing80) result.pingTCP = `${tcpPing80}ms (80)`;
      else result.pingTCP = "Timeout";
    }
    result.openPorts = await scanPorts(host);
    const domain = getDomain(host);
    result.whois = await getWhois(domain);
    if (await checkPort(host, 443, 1000)) {
      const tlsInfo = await getTLSDetails(host);
      if (tlsInfo) {
        result.tlsVersion = tlsInfo.version;
        result.tlsCipher = tlsInfo.cipher;
        result.tlsIssuer = tlsInfo.issuer;
        result.tlsExpiry = tlsInfo.validTo;
        result.httpVersion = tlsInfo.alpn === "h2" ? "HTTP/2" : "HTTP/1.1";
      }
    }

    const start = Date.now();
    const res = await timeoutPromise(
      axios.get(url, {
        headers: { "User-Agent": randomUA() },
        timeout: 10000,
        validateStatus: () => true,
        maxRedirects: 0
      }),
      12000
    );
    result.responseTime = `${Date.now() - start}ms`;
    result.statusCode = res.status;
    result.server = res.headers.server || "Tidak Ada!";
    result.contentType = res.headers["content-type"] || "Tidak Ada!";
    result.protection = detectProtection(res.headers);
    result.securityHeaders = analyzeSecurityHeaders(res.headers);
    const bodySample = typeof res.data === "string" ? res.data.substring(0, 10000) : "";
    result.techStack = detectTechFromHeaders(res.headers, bodySample);
    if (res.headers["alt-svc"]?.includes("h3")) result.httpVersion += "+HTTP/3";
    if (res.status >= 200 && res.status < 400) result.status = "Online";
  } catch (err) {
    result.error = err.message;
  }
  return result;
}

// ================ Output Formatter ================
async function cekHost(host) {
  const d = await preCheck(host);
  return `┌────[『 𝐂𝐡𝐞𝐜𝐤 𝐇𝐨𝐬𝐭 』
│⎋.𝐋𝐢𝐧𝐤 : ${d.link}
│⎋.𝐒𝐭𝐚𝐭𝐮𝐬 : ${d.status}
│⎋.𝐈𝐏𝐯4 : ${d.ipv4}
│⎋.𝐈𝐏𝐯6 : ${d.ipv6}
│⎋.𝐋𝐨𝐤𝐚𝐬𝐢 : ${d.location}
│⎋.𝐈𝐬𝐩 : ${d.isp}
│⎋.𝐎𝐫𝐠 : ${d.org}
│⎋.𝐀𝐬𝐧 : ${d.as}
│⎋.𝐕𝐩𝐬 𝐇𝐨𝐬𝐭𝐢𝐧𝐠 : ${d.vps}
│⎋.𝐏𝐫𝐨𝐱𝐲 : ${d.proxy ? "Yes" : "Tidak Ada!"}
│⎋.𝐎𝐫𝐢𝐠𝐢𝐧 𝐈𝐩 : ${d.origin}
│⎋.𝐈𝐜𝐦𝐩 : ${d.pingICMP}
│⎋.𝐓𝐜𝐩 : ${d.pingTCP}
│⎋.𝐎𝐩𝐞𝐧 𝐏𝐨𝐫𝐭 : ${d.openPorts}
│⎋.𝐒𝐞𝐫𝐯𝐞𝐫 : ${d.server}
│⎋.𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 : ${d.protection}
│⎋.𝐇𝐭𝐭𝐩 : ${d.httpVersion}
│⎋.𝐓𝐥𝐬 : ${d.tlsVersion}
│⎋.𝐂𝐢𝐩𝐡𝐞𝐫 : ${d.tlsCipher}
│⎋.𝐈𝐬𝐬𝐮𝐞𝐫 : ${d.tlsIssuer}
│⎋.𝐄𝐱𝐩𝐢𝐫𝐲 : ${d.tlsExpiry}
│⎋.𝐖𝐡𝐨𝐢𝐬 : ${d.whois ? d.whois.substring(0, 100) : "Tidak Ada!"}
│⎋.𝐓𝐞𝐜𝐡 𝐒𝐭𝐚𝐜𝐤 : ${d.techStack}
│⎋.𝐇𝐬𝐭𝐬 : ${d.securityHeaders.hsts}
│⎋.𝐂𝐬𝐩 : ${d.securityHeaders.csp}
│⎋.𝐗-𝐅𝐫𝐚𝐦𝐞 : ${d.securityHeaders.xframe}
│⎋.𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 : ${d.responseTime}
│⎋.𝐂𝐨𝐝𝐞 : ${d.statusCode}
│⎋.𝐓𝐲𝐩𝐞 : ${d.contentType}
└───────────────────>
${d.error ? `𝐄𝐫𝐫𝐨𝐫 : ${d.error}` : ""}`;
}

module.exports = { cekHost, preCheck };