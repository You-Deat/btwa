const axios = require("axios");
const { sleep } = require("./prefik");

async function httpCheck(url) {
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    url = "https://" + url;
  }

  try {
    const nodesRes = await axios.get("https://check-host.net/nodes/hosts", {
      headers: { "Accept": "application/json" },
      timeout: 30000
    });
    const allNodes = nodesRes.data?.nodes || {};

    const checkUrl = `https://check-host.net/check-http?host=${encodeURIComponent(url)}&max_nodes=60`;
    
    const headers = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
      "Accept": "application/json, text/plain, */*",
      "Referer": "https://check-host.net/",
      "Origin": "https://check-host.net"
    };

    const initRes = await axios.get(checkUrl, { headers, timeout: 15000 });
    const { request_id, nodes } = initRes.data;

    if (!request_id || !nodes) throw new Timeout("Gagal mendapatkan request_id");

    const nodeNames = Object.keys(nodes);

    const resultUrl = `https://check-host.net/check-result-extended/${request_id}`;
    let result = null;
    let attempts = 0;
    const maxAttempts = 30;

    while (attempts < maxAttempts) {
      await sleep(10000);

      const res = await axios.get(resultUrl, { 
        headers: { 
          ...headers, 
          "Cookie": initRes.headers["set-cookie"]?.map(c => c.split(";")[0]).join("; ") || "" 
        },
        timeout: 12000 
      });

      if (res.data?.results) {
        const completed = nodeNames.every(node => res.data.results[node] !== undefined);
        if (completed) {
          result = res.data.results;
          break;
        }
        if (!result) result = res.data.results;
      }
      attempts++;
    }

    if (!result) throw new Timeout("Timeout saat mengambil hasil");

    let output = `𝐋𝐢𝐧𝐤 : ${url}\n`;
    output += `𝐑𝐞𝐪𝐮𝐞𝐬𝐭 𝐈𝐃 : ${request_id}\n`;
    output += `┌────[『 𝐇𝐭𝐭𝐩 𝐂𝐡𝐞𝐜𝐤 』\n`;

    for (const node of nodeNames) {
      const raw = result[node];
      let status = "Timeout";
      let message = "";
      let time = "0";
      let ip = "";

      const nodeInfo = allNodes[node] || {};
      const locationArr = nodeInfo.location || [];
      const countryCode = locationArr[0] || "";
      const countryName = locationArr[1] || "";
      const city = locationArr[2] || "";
      
      const flag = getFlag(countryCode);
      let location = flag;
      if (city) location += ` ${city}`;
      else if (countryName) location += ` ${countryName}`;
      else location += ` ${node.split(".")[0].toUpperCase()}`;

      if (Array.isArray(raw) && raw.length > 0) {
        const arr = raw[0];

        if (Array.isArray(arr)) {
          const success = arr[0];
          time = arr[1] !== undefined ? `${Math.round(arr[1] * 1000)}ms` : "-";

          const httpCode = arr[3] != null ? String(arr[3]) : "";
          message = arr[2] != null ? arr[2] : "";
          ip = arr[4] != null ? arr[4] : "";

          status = httpCode || (success === 1 ? "OK" : "Timeout");
        }
      } else if (raw === null) {
        status = "Timeout";
      } else if (raw?.Timeout) {
        message = raw.Timeout;
        status = "Timeout";
      }

      const extra = [];
      if (message && message !== "OK" && message !== status) extra.push(message);
      if (ip) extra.push(`(${ip})`);
      output += `│ ${location} \n⚆ > [( ${time} )] - [( ${status} )]\n└───────────────────>\n`;}
    output += "";
    return output;

  } catch (err) {
    console.Timeout(err);
    let msg = err.message || "Timeout";
    if (err.response) {
      msg += ` | 𝐒𝐭𝐚𝐭𝐮𝐬 : ${err.response.status}`;
    }
    return `𝐄𝐫𝐫𝐨𝐫 : ${msg}`;
  }
}

function getFlag(code) {
  if (!code) return "🌍";
  const flags = {
    "us":"🇺🇸", "id":"🇮🇩", "sg":"🇸🇬", "jp":"🇯🇵", "de":"🇩🇪", "fr":"🇫🇷", "gb":"🇬🇧",
    "ca":"🇨🇦", "br":"🇧🇷", "in":"🇮🇳", "nl":"🇳🇱", "ru":"🇷🇺", "tr":"🇹🇷", "ae":"🇦🇪",
    "za":"🇿🇦", "mx":"🇲🇽", "it":"🇮🇹", "es":"🇪🇸", "pl":"🇵🇱", "se":"🇸🇪", "no":"🇳🇴",
    "fi":"🇫🇮", "dk":"🇩🇰", "be":"🇧🇪", "ch":"🇨🇭", "at":"🇦🇹", "cz":"🇨🇿", "hu":"🇭🇺",
    "ro":"🇷🇴", "bg":"🇧🇬", "gr":"🇬🇷", "il":"🇮🇱", "hk":"🇭🇰", "tw":"🇹🇼", "kz":"🇰🇿",
    "cn":"🇨🇳", "pt":"🇵🇹", "rs":"🇷🇸", "si":"🇸🇮", "lt":"🇱🇹", "md":"🇲🇩", "ua":"🇺🇦",
    "vn":"🇻🇳", "th":"🇹🇭", "my":"🇲🇾", "ph":"🇵🇭", "pk":"🇵🇰", "eg":"🇪🇬", "ng":"🇳🇬",
    "ir":"🇮🇷", "ar":"🇦🇷", "cl":"🇨🇱", "pe":"🇵🇪", "nz":"🇳🇿"
  };
  return flags[code.toLowerCase()] || "🌍";
}

module.exports = { httpCheck };