const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
let sharp;
try { sharp = require("sharp"); } catch (e) { sharp = null; }

async function createSticker(quotedMsg, downloadContentFromMessage) {
  const isImage = !!quotedMsg.imageMessage;
  const isVideo = !!quotedMsg.videoMessage;
  if (!isImage && !isVideo) {
    throw new Error("Hanya bisa untuk gambar/video!");
  }
  const mediaMessage = isImage ? quotedMsg.imageMessage : quotedMsg.videoMessage;
  const stream = await downloadContentFromMessage(mediaMessage, isImage ? 'image' : 'video');
  let buffer = Buffer.from([]);
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
  
  const sampahDir = path.join(__dirname, '..', 'sampah');
  if (!fs.existsSync(sampahDir)) fs.mkdirSync(sampahDir, { recursive: true });
  const tmpInput = path.join(sampahDir, `temp_${Date.now()}.${isImage ? 'jpg' : 'mp4'}`);
  const tmpOutput = path.join(sampahDir, `temp_${Date.now()}.webp`);
  
  fs.writeFileSync(tmpInput, buffer);
  let stickerBuffer;
  if (isImage) {
    if (sharp) {
      stickerBuffer = await sharp(tmpInput).resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp().toBuffer();
    } else {
      execSync(`ffmpeg -i "${tmpInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -c:v libwebp -q:v 80 "${tmpOutput}"`, { stdio: "ignore" });
      stickerBuffer = fs.readFileSync(tmpOutput);
    }
  } else {
    execSync(`ffmpeg -i "${tmpInput}" -vframes 1 -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -c:v libwebp -lossless 0 -q:v 80 "${tmpOutput}"`, { stdio: "ignore" });
    stickerBuffer = fs.readFileSync(tmpOutput);
  }
  if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput);
  if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput);
  return stickerBuffer;
}

module.exports = { createSticker };